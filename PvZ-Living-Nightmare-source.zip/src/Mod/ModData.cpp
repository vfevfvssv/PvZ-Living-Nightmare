// PvZ Living Nightmare - static content tables.
#include "ModData.h"

const ModAbilityInfo gModAbilityInfo[NUM_MOD_ABILITIES] = {
	{ "Armor",        "Takes 40% less damage from shots and bites." },
	{ "Sprint",       "Sprints at double speed for short bursts." },
	{ "Explosive",    "Explodes on death, damaging plants around it." },
	{ "Regeneration", "Slowly regenerates its health." },
	{ "Protector",    "Nearby zombies take 30% less damage." },
	{ "Toxic",        "Bites poison plants for 10 seconds." },
	{ "Freezer",      "Freezes the plant in front of it for 3 seconds." },
	{ "Summoner",     "Summons small zombies (max 3)." },
	{ "Vampire",      "Heals itself whenever it bites." },
	{ "Berserker",    "Below 40% health: much faster and bites harder." },
	{ "Invisible",    "Turns invisible and cannot be targeted." },
	{ "Divisible",    "Splits into two small zombies when defeated." },
	{ "Electric",     "Chain lightning hits up to 3 plants ahead." },
	{ "Constructor",  "Digs craters that block planting." },
	{ "Underground",  "Travels underground until the middle of the lawn." },
	{ "Mimic",        "Copies an ability from a nearby special zombie." },
	{ "Energy Shield","Shield absorbs damage and recharges." },
	{ "Leaper",       "Leaps over the first plant blocking it." },
	{ "Healer",       "Heals nearby zombies." },
	{ "Rage",         "Gets faster every time it is hit." },
	{ "Rally",        "Nearby zombies move 25% faster." },
	{ "Saboteur",     "Disables plants around it for 4 seconds." },
	{ "Artillery",    "Lobs basketballs at plants from range." },
	{ "Necromancy",   "Raises zombies from the ground ahead of it." },
	{ "Ice Immune",   "Cannot be chilled or frozen." },
	{ "Fire Immune",  "Survives fire attacks that would burn others." },
	{ "Frost Death",  "Freezes nearby plants when it dies." },
	{ "Stomp",        "Shockwave damages plants in front of it." },
	{ "Sun Thief",    "Steals sun with every bite; drops it on death." },
	{ "Evasive",      "Dodges 30% of projectiles." },
	{ "Lane Hopper",  "Jumps to a neighbouring lane." },
	{ "Growth",       "Grows bigger and tougher over time." },
};

// Each original zombie type has at least two variants. Tier: 0 always, 1 after 50 kills, 2 after 200 kills.
const ModVariantDef gModVariants[] = {
	// ---- Basic zombie (extra variants: it is the most common enemy)
	{ ZOMBIE_NORMAL, "Brute",            AB_ARMOR,                 2.0f, 0.80f, 1.5f, 1.15f, 150,160,190, 0, "Thick-skinned zombie that soaks up peas.", "Explosions ignore its armor." },
	{ ZOMBIE_NORMAL, "Sprinter",         AB_SPRINT,                0.8f, 1.60f, 1.0f, 0.95f, 255,240,120, 0, "Runs in fast bursts.", "Slow it with Snow Pea; low health." },
	{ ZOMBIE_NORMAL, "Bomber",           AB_EXPLODE,               1.0f, 1.00f, 1.0f, 1.00f, 255,120,100, 1, "Explodes when defeated.", "Kill it far from your plants (Cattail, Starfruit)." },
	{ ZOMBIE_NORMAL, "Vampire",          AB_VAMPIRE | AB_REGEN,    1.3f, 1.05f, 1.2f, 1.00f, 190,110,220, 1, "Drinks plant sap to heal.", "Burst damage: Cherry Bomb, Melon-pult." },
	{ ZOMBIE_NORMAL, "Splitter",         AB_SPLIT,                 1.2f, 0.95f, 1.0f, 1.10f, 120,230,200, 1, "Splits into two minis when defeated.", "Splash damage handles the minis." },
	{ ZOMBIE_NORMAL, "Ghost",            AB_INVIS,                 1.0f, 1.00f, 1.0f, 1.00f, 220,230,255, 2, "Fades out of sight and cannot be targeted.", "Plantern reveals it; Spikeweed still hits." },
	{ ZOMBIE_NORMAL, "Tunneler",         AB_TUNNEL,                1.1f, 1.10f, 1.0f, 1.00f, 180,140,100, 2, "Moves underground past your front line.", "Back-row defense, Spikeweed, Potato Mine." },
	// ---- Flag
	{ ZOMBIE_FLAG, "Warlord",            AB_HASTE_AURA | AB_PROTECT, 1.8f, 1.0f, 1.0f, 1.10f, 255,90,90, 0, "Rallies the horde: allies move faster and resist damage.", "Focus it first; its aura ends on death." },
	{ ZOMBIE_FLAG, "Necro Banner",       AB_NECRO,                 1.5f, 0.95f, 1.0f, 1.05f, 140,100,200, 1, "Raises zombies from the ground.", "Kill quickly before it raises an army." },
	// ---- Conehead
	{ ZOMBIE_TRAFFIC_CONE, "Toxic Cone", AB_TOXIC,                 1.2f, 1.0f, 1.0f, 1.0f, 140,255,120, 0, "Poisonous bite damages plants over time.", "Keep it away with Wall-nuts in front of shooters." },
	{ ZOMBIE_TRAFFIC_CONE, "Mimic Cone", AB_MIMIC | AB_REGEN,      1.3f, 1.0f, 1.0f, 1.0f, 255,200,255, 1, "Copies abilities of special zombies nearby.", "Kill the special zombies around it first." },
	// ---- Pole vaulter
	{ ZOMBIE_POLEVAULTER, "Electro Vaulter", AB_ELECTRIC,          1.2f, 1.0f, 1.0f, 1.0f, 120,200,255, 0, "Shocks plants with chain lightning.", "Spread plants out; Tall-nut stops the vault." },
	{ ZOMBIE_POLEVAULTER, "Phantom Vaulter", AB_INVIS | AB_SPRINT, 1.0f, 1.1f, 1.0f, 1.0f, 230,230,255, 1, "Invisible sprinting vaulter.", "Plantern and Spikeweed." },
	// ---- Buckethead
	{ ZOMBIE_PAIL, "Iron Bucket",        AB_ARMOR | AB_BUBBLE,     1.5f, 0.85f, 1.0f, 1.05f, 170,170,200, 0, "Armored bucket with an energy shield.", "Magnet-shroom pulls the bucket; Fume-shroom." },
	{ ZOMBIE_PAIL, "Regenerator",        AB_REGEN | AB_GROW,       1.3f, 1.0f, 1.0f, 1.0f, 120,255,160, 1, "Heals constantly and grows.", "High burst damage before it regenerates." },
	// ---- Newspaper
	{ ZOMBIE_NEWSPAPER, "Berserker Reader", AB_BERSERK | AB_RAGE,  1.3f, 1.0f, 1.2f, 1.0f, 255,80,60, 0, "Gets furious and faster with every hit.", "Freeze it with Ice-shroom before it rages." },
	{ ZOMBIE_NEWSPAPER, "Frost Reader",  AB_FREEZER | AB_ICE_IMMUNE, 1.2f, 1.0f, 1.0f, 1.0f, 150,220,255, 1, "Freezes plants, immune to cold.", "Fire peas (Torchwood) and Jalapeno." },
	// ---- Screen door
	{ ZOMBIE_DOOR, "Constructor",        AB_BUILDER,               1.3f, 0.95f, 1.0f, 1.0f, 230,190,120, 0, "Digs craters where you want to plant.", "Kill it before it reaches your back rows." },
	{ ZOMBIE_DOOR, "Bastion",            AB_PROTECT | AB_ARMOR,    1.4f, 0.9f, 1.0f, 1.05f, 160,160,220, 1, "Shields its allies.", "Lobbed shots (Cabbage, Melon) ignore its door." },
	// ---- Football
	{ ZOMBIE_FOOTBALL, "Linebacker",     AB_STOMP,                 1.3f, 1.0f, 1.2f, 1.1f, 255,170,90, 0, "Stomps the ground to damage plants.", "Squash and Chomper." },
	{ ZOMBIE_FOOTBALL, "Blitz",          AB_SPRINT | AB_JUMP,      1.0f, 1.2f, 1.0f, 1.0f, 255,255,140, 1, "Sprints and leaps over the first plant.", "Tall-nut blocks the leap." },
	// ---- Dancer
	{ ZOMBIE_DANCER, "Necro Dancer",     AB_NECRO,                 1.3f, 1.0f, 1.0f, 1.0f, 180,120,255, 0, "Raises extra zombies while dancing.", "Kill it quickly with Jalapeno or Squash." },
	{ ZOMBIE_DANCER, "Disco Inferno",    AB_FIRE_IMMUNE | AB_EXPLODE, 1.3f, 1.0f, 1.0f, 1.0f, 255,140,60, 1, "Fire-proof dancer that explodes.", "Ice and Snow Pea; fire does nothing." },
	// ---- Backup dancer
	{ ZOMBIE_BACKUP_DANCER, "Healer Backup", AB_HEALER,            1.2f, 1.0f, 1.0f, 1.0f, 140,255,180, 0, "Heals the dance crew.", "Splash damage hits the whole crew." },
	{ ZOMBIE_BACKUP_DANCER, "Shadow Backup", AB_INVIS,             1.0f, 1.0f, 1.0f, 1.0f, 200,200,255, 1, "Fades from sight.", "Plantern." },
	// ---- Ducky tube
	{ ZOMBIE_DUCKY_TUBE, "Toxic Tube",   AB_TOXIC | AB_REGEN,      1.2f, 1.0f, 1.0f, 1.0f, 140,255,120, 0, "Poisonous swimmer.", "Tangle Kelp." },
	{ ZOMBIE_DUCKY_TUBE, "Splitter Tube",AB_SPLIT,                 1.2f, 1.0f, 1.0f, 1.05f, 120,230,220, 1, "Splits in two when defeated.", "Splash damage." },
	// ---- Snorkel
	{ ZOMBIE_SNORKEL, "Electro Diver",   AB_ELECTRIC,              1.2f, 1.0f, 1.0f, 1.0f, 120,200,255, 0, "Electrocutes plants from the water.", "Tangle Kelp drags it under." },
	{ ZOMBIE_SNORKEL, "Leech Diver",     AB_VAMPIRE,               1.3f, 1.0f, 1.2f, 1.0f, 190,110,220, 1, "Heals by biting lily pads.", "Burst damage." },
	// ---- Zomboni
	{ ZOMBIE_ZAMBONI, "Glacier Zamboni", AB_FREEZER | AB_ICE_IMMUNE | AB_ARMOR, 1.4f, 0.9f, 1.0f, 1.0f, 150,220,255, 0, "Freezes plants in its path.", "Spikeweed pops its tires." },
	{ ZOMBIE_ZAMBONI, "Bomb Zamboni",    AB_EXPLODE | AB_ARMOR,    1.3f, 1.0f, 1.0f, 1.0f, 255,120,100, 1, "Explodes when destroyed.", "Spikeweed/Spikerock far from your lines." },
	// ---- Bobsled
	{ ZOMBIE_BOBSLED, "Turbo Sled",      AB_SPRINT,                1.0f, 1.2f, 1.0f, 1.0f, 255,240,120, 0, "Extremely fast sled team.", "Spikeweed destroys the sled." },
	{ ZOMBIE_BOBSLED, "Frost Sled",      AB_ICE_IMMUNE | AB_DEATH_FREEZE, 1.2f, 1.0f, 1.0f, 1.0f, 160,220,255, 1, "Freezes plants when defeated.", "Kill it far from your plants." },
	// ---- Dolphin rider
	{ ZOMBIE_DOLPHIN_RIDER, "Shark Rider", AB_BERSERK | AB_VAMPIRE, 1.2f, 1.0f, 1.2f, 1.0f, 120,140,200, 0, "Gets vicious when hurt.", "Tall-nut stops the jump." },
	{ ZOMBIE_DOLPHIN_RIDER, "Storm Rider", AB_ELECTRIC | AB_LANE_HOP, 1.1f, 1.0f, 1.0f, 1.0f, 120,200,255, 1, "Shocks plants and changes lanes.", "Cover every pool lane." },
	// ---- Jack-in-the-box
	{ ZOMBIE_JACK_IN_THE_BOX, "Surprise Box", AB_SPLIT | AB_EXPLODE, 1.0f, 1.0f, 1.0f, 1.0f, 255,150,200, 0, "Explodes and leaves minis behind.", "Magnet-shroom steals the box." },
	{ ZOMBIE_JACK_IN_THE_BOX, "Shock Box",   AB_ELECTRIC | AB_DODGE, 1.0f, 1.0f, 1.0f, 1.0f, 120,200,255, 1, "Dodges shots and zaps plants.", "Splash damage cannot be dodged." },
	// ---- Balloon
	{ ZOMBIE_BALLOON, "Sky Artillery",   AB_ARTILLERY,             1.2f, 1.0f, 1.0f, 1.0f, 255,200,120, 0, "Drops basketballs while flying.", "Cactus and Blover." },
	{ ZOMBIE_BALLOON, "Stealth Balloon", AB_INVIS | AB_DODGE,      1.0f, 1.0f, 1.0f, 1.0f, 220,220,255, 1, "Invisible and evasive.", "Blover blows it away even when invisible." },
	// ---- Digger
	{ ZOMBIE_DIGGER, "Saboteur Miner",   AB_SABOTAGE,              1.2f, 1.0f, 1.0f, 1.0f, 200,160,100, 0, "Disables plants around it.", "Split Pea and Starfruit shoot backwards." },
	{ ZOMBIE_DIGGER, "Gem Digger",       AB_SUN_THIEF | AB_REGEN,  1.2f, 1.0f, 1.0f, 1.0f, 255,230,120, 1, "Steals your sun.", "Kill it to get the sun back." },
	// ---- Pogo
	{ ZOMBIE_POGO, "Hopper",             AB_LANE_HOP | AB_SPRINT,  1.0f, 1.1f, 1.0f, 1.0f, 200,255,140, 0, "Bounces between lanes.", "Tall-nuts in every lane." },
	{ ZOMBIE_POGO, "Spring Bomber",      AB_EXPLODE | AB_DODGE,    1.0f, 1.0f, 1.0f, 1.0f, 255,120,100, 1, "Evasive and explosive.", "Magnet-shroom removes the pogo." },
	// ---- Yeti
	{ ZOMBIE_YETI, "Frost Giant",        AB_DEATH_FREEZE | AB_ICE_IMMUNE | AB_FREEZER, 1.5f, 1.0f, 1.2f, 1.1f, 160,220,255, 0, "Freezes everything around it.", "Fire peas." },
	{ ZOMBIE_YETI, "Snow Summoner",      AB_SUMMON | AB_ICE_IMMUNE,1.4f, 1.0f, 1.0f, 1.05f, 220,240,255, 1, "Summons minis from the snow.", "Kill it quickly; drops 4 diamonds." },
	// ---- Bungee
	{ ZOMBIE_BUNGEE, "Armored Bungee",   AB_ARMOR | AB_BUBBLE,     1.5f, 1.0f, 1.0f, 1.0f, 170,170,210, 0, "Shielded bungee.", "Umbrella Leaf." },
	{ ZOMBIE_BUNGEE, "Bomb Bungee",      AB_EXPLODE | AB_DODGE,    1.0f, 1.0f, 1.0f, 1.0f, 255,120,100, 1, "Explodes when shot down.", "Umbrella Leaf blocks it completely." },
	// ---- Ladder
	{ ZOMBIE_LADDER, "Engineer",         AB_BUILDER | AB_PROTECT,  1.3f, 1.0f, 1.0f, 1.0f, 230,190,120, 0, "Builds obstacles and shields allies.", "Magnet-shroom takes the ladder." },
	{ ZOMBIE_LADDER, "Climber",          AB_JUMP | AB_SPRINT,      1.1f, 1.1f, 1.0f, 1.0f, 255,240,140, 1, "Leaps over your first plant.", "Tall-nut." },
	// ---- Catapult
	{ ZOMBIE_CATAPULT, "Siege Catapult", AB_ARTILLERY | AB_ARMOR,  1.4f, 0.9f, 1.0f, 1.0f, 200,170,140, 0, "Heavily armored, fires extra shots.", "Umbrella Leaf." },
	{ ZOMBIE_CATAPULT, "Toxic Catapult", AB_TOXIC | AB_SABOTAGE,   1.2f, 1.0f, 1.0f, 1.0f, 140,255,120, 1, "Poisons and disables plants.", "Kill it quickly with Jalapeno." },
	// ---- Gargantuar
	{ ZOMBIE_GARGANTUAR, "Titan",        AB_ARMOR | AB_GROW | AB_STOMP, 1.3f, 0.9f, 1.0f, 1.0f, 170,150,140, 1, "A growing armored giant.", "Doom-shroom; Cob Cannon." },
	{ ZOMBIE_GARGANTUAR, "Shaman",       AB_SUMMON | AB_HEALER,    1.2f, 1.0f, 1.0f, 1.0f, 140,255,180, 1, "Summons and heals the horde.", "Kill it before its summons pile up." },
	// ---- Imp
	{ ZOMBIE_IMP, "Speedy Imp",          AB_SPRINT | AB_DODGE,     1.0f, 1.3f, 1.0f, 1.0f, 255,240,120, 0, "Very fast and evasive.", "Spikeweed." },
	{ ZOMBIE_IMP, "Explosive Imp",       AB_EXPLODE,               1.0f, 1.0f, 1.0f, 1.0f, 255,120,100, 0, "Explodes when it dies.", "Kill it before it reaches your plants." },
	// ---- Zombotany heads
	{ ZOMBIE_PEA_HEAD, "Toxic Pea Zombie",   AB_TOXIC | AB_REGEN,  1.2f, 1.0f, 1.0f, 1.0f, 140,255,120, 1, "Poisonous head-shooter.", "Wall-nuts absorb the peas." },
	{ ZOMBIE_PEA_HEAD, "Frost Pea Zombie",   AB_FREEZER | AB_ICE_IMMUNE, 1.2f, 1.0f, 1.0f, 1.0f, 150,220,255, 1, "Freezes plants it reaches.", "Fire peas." },
	{ ZOMBIE_WALLNUT_HEAD, "Iron Nut Zombie",AB_ARMOR | AB_BUBBLE, 1.4f, 0.9f, 1.0f, 1.05f, 170,170,200, 1, "Very hard to crack.", "Chomper eats it in one bite." },
	{ ZOMBIE_WALLNUT_HEAD, "Thorn Nut Zombie",AB_PROTECT | AB_REGEN,1.3f, 1.0f, 1.0f, 1.0f, 140,220,140, 1, "Protects zombies near it.", "Focus fire." },
	{ ZOMBIE_JALAPENO_HEAD, "Inferno Zombie",AB_FIRE_IMMUNE | AB_EXPLODE, 1.2f, 1.0f, 1.0f, 1.0f, 255,120,60, 1, "Explodes in flames.", "Kill it far away." },
	{ ZOMBIE_JALAPENO_HEAD, "Chain Pepper",  AB_SPLIT,             1.2f, 1.0f, 1.0f, 1.0f, 255,170,90, 1, "Splits when defeated.", "Splash damage." },
	{ ZOMBIE_GATLING_HEAD, "Electro Gatling",AB_ELECTRIC,          1.2f, 1.0f, 1.0f, 1.0f, 120,200,255, 1, "Shoots and shocks.", "Spread out your plants." },
	{ ZOMBIE_GATLING_HEAD, "Siege Gatling",  AB_ARTILLERY,         1.2f, 1.0f, 1.0f, 1.0f, 200,170,140, 1, "Adds lobbed shots.", "Umbrella Leaf." },
	{ ZOMBIE_SQUASH_HEAD, "Quake Squash",    AB_STOMP,             1.2f, 1.0f, 1.0f, 1.0f, 255,200,90, 1, "Stomps plants.", "Kill it at range." },
	{ ZOMBIE_SQUASH_HEAD, "Ghost Squash",    AB_INVIS,             1.0f, 1.0f, 1.0f, 1.0f, 220,230,255, 1, "Invisible squasher.", "Plantern." },
	{ ZOMBIE_TALLNUT_HEAD, "Fortress Zombie",AB_ARMOR | AB_PROTECT,1.3f, 0.9f, 1.0f, 1.05f, 170,170,210, 1, "A walking fortress.", "Chomper; Squash." },
	{ ZOMBIE_TALLNUT_HEAD, "Grower Zombie",  AB_GROW | AB_REGEN,   1.2f, 1.0f, 1.0f, 1.0f, 140,255,160, 1, "Grows and heals.", "Burst damage." },
	// ---- Red-eye Gargantuar
	{ ZOMBIE_REDEYE_GARGANTUAR, "Doom Gargantuar",   AB_EXPLODE | AB_BERSERK,    1.2f, 1.0f, 1.0f, 1.0f, 255,80,80, 2, "Rages at low health and explodes.", "Kill it far from your plants." },
	{ ZOMBIE_REDEYE_GARGANTUAR, "Warlord Gargantuar",AB_HASTE_AURA | AB_SUMMON,  1.2f, 1.0f, 1.0f, 1.0f, 255,170,90, 2, "Commands the horde.", "Doom-shroom." },
};
const int NUM_MOD_VARIANTS = sizeof(gModVariants) / sizeof(gModVariants[0]);

const ModClassDef gModClasses[NUM_MOD_CLASSES] = {
	{ "Tank",       "TNK", 1.75f, 0.85f, 1.0f, 0.85f, 0,                         150,150,170, "Lots of health and damage resistance." },
	{ "Assassin",   "ASN", 0.80f, 1.50f, 2.5f, 1.00f, 0,                         120, 60,120, "Fast and deadly bites." },
	{ "Support",    "SUP", 1.00f, 1.00f, 1.0f, 1.00f, AB_HASTE_AURA,             255,220,120, "Speeds up and buffs nearby zombies." },
	{ "Healer",     "HEA", 1.00f, 1.00f, 1.0f, 1.00f, AB_HEALER,                 140,255,170, "Regenerates allies nearby." },
	{ "Summoner",   "SUM", 1.10f, 0.95f, 1.0f, 1.00f, AB_SUMMON,                 190,140,255, "Calls in extra zombies." },
	{ "Destroyer",  "DST", 1.20f, 0.90f, 3.0f, 1.00f, 0,                         255,110, 80, "Huge damage to plants and walls." },
	{ "Saboteur",   "SAB", 1.00f, 1.00f, 1.0f, 1.00f, AB_SABOTAGE,               170,170,170, "Temporarily disables plants." },
	{ "Scout",      "SCT", 0.70f, 1.80f, 1.0f, 1.00f, 0,                         180,255,255, "Fast; finds and buffs the weakest lane." },
	{ "Controller", "CTL", 1.00f, 1.00f, 1.0f, 1.00f, AB_FREEZER,                150,200,255, "Slows and roots plants." },
	{ "Artillery",  "ART", 0.90f, 0.90f, 1.0f, 1.00f, AB_ARTILLERY,              230,180,120, "Attacks plants from range." },
};

const ModMutationDef gModMutations[NUM_MOD_MUTATIONS] = {
	{ "Fast",       "FST", 100, 0,              1.0f, 1.45f, 1.00f, 255,255,120, "+45% speed." },
	{ "Armored",    "ARM", 90,  AB_ARMOR,       1.3f, 1.00f, 1.05f, 170,170,200, "Extra armor." },
	{ "Regenerative","REG",80,  AB_REGEN,       1.0f, 1.00f, 1.00f, 120,255,150, "Regenerates health." },
	{ "Explosive",  "EXP", 60,  AB_EXPLODE,     1.0f, 1.00f, 1.00f, 255,110, 90, "Explodes on death." },
	{ "Toxic",      "TOX", 70,  AB_TOXIC,       1.0f, 1.00f, 1.00f, 140,255,100, "Toxic trail and bites." },
	{ "Electric",   "ELC", 50,  AB_ELECTRIC,    1.0f, 1.00f, 1.00f, 120,200,255, "Electrocutes plants." },
	{ "Giant",      "GNT", 20,  AB_STOMP,       2.5f, 0.85f, 1.35f, 255,180,140, "Rare: huge size and health." },
	{ "Multiplier", "MUL", 25,  AB_SPLIT,       1.0f, 1.00f, 1.00f, 200,140,255, "Rare: divides when defeated." },
	{ "Frozen",     "FRZ", 60,  AB_ICE_IMMUNE,  1.1f, 1.00f, 1.00f, 170,230,255, "Immune to ice attacks." },
	{ "Berserker",  "BSK", 50,  AB_RAGE | AB_BERSERK, 1.0f, 1.00f, 1.00f, 255, 70, 70, "Stronger as it takes damage." },
};

const ModComboDef gModCombos[NUM_MOD_COMBOS] = {
	{ "Frenzy",       MUT_FAST,      MUT_BERSERK,   AB_SPRINT,                1.2f, 1.20f, "Fast + Berserker: relentless charging rage." },
	{ "Colossus",     MUT_GIANT,     MUT_ARMORED,   AB_BUBBLE,                1.5f, 1.00f, "Giant + Armored: a living siege engine." },
	{ "Plague Bomb",  MUT_EXPLOSIVE, MUT_TOXIC,     AB_DEATH_FREEZE,          1.1f, 1.00f, "Explosive + Toxic: poisons every plant in the blast." },
	{ "Dynamo",       MUT_ELECTRIC,  MUT_REGEN,     AB_HASTE_AURA,            1.2f, 1.05f, "Electric + Regenerative: lightning heals it." },
	{ "Glacier",      MUT_FROZEN,    MUT_GIANT,     AB_FREEZER,               1.3f, 1.00f, "Frozen + Giant: freezing aura." },
	{ "Cluster Bomb", MUT_MULTIPLIER,MUT_EXPLOSIVE, 0,                        1.0f, 1.00f, "Multiplier + Explosive: splits into exploding minis." },
};

const ModBossDef gModBosses[NUM_MOD_BOSSES] = {
	{ "Armored Giant", ZOMBIE_GARGANTUAR, 9000,  0.70f, 1.40f, AB_ARMOR | AB_STOMP,               150,150,180, "Covered in steel plates. Phase 1 armor blocks 80% damage.", "1: Steel shell  2: Plates fall, ground slams  3: Rage + imp barrage" },
	{ "Mechanic",      ZOMBIE_ZAMBONI,    7000,  0.70f, 1.25f, AB_ARMOR,                          200,200,120, "A souped-up machine that spits basketballs and imps.", "1: Basketball volleys  2: Deploys imps  3: Overdrive charge" },
	{ "Necromancer",   ZOMBIE_NORMAL,     5000,  0.60f, 1.60f, AB_NECRO | AB_REGEN,               120, 80,180, "Raises the dead and drains your plants.", "1: Raises zombies  2: Graveyard  3: Life drain" },
	{ "Mutant",        ZOMBIE_GARGANTUAR, 8000,  0.80f, 1.35f, AB_REGEN,                          170,255,120, "Unstable mutant that changes mutation each phase.", "1-3: Gains new random mutations, splits at death" },
	{ "Fire Lord",     ZOMBIE_GARGANTUAR, 8000,  0.75f, 1.35f, AB_FIRE_IMMUNE,                    255,120, 50, "Burns rows of plants. Immune to fire.", "1: Flame row  2: Fire rain  3: Inferno aura" },
	{ "Ice Queen",     ZOMBIE_YETI,       7000,  0.80f, 1.50f, AB_ICE_IMMUNE | AB_FREEZER,        150,220,255, "Freezes plants solid. Immune to cold.", "1: Frost bolt  2: Blizzard (all plants slowed)  3: Absolute zero" },
	{ "Storm Titan",   ZOMBIE_GARGANTUAR, 8500,  0.75f, 1.35f, AB_ELECTRIC,                       120,200,255, "Calls lightning and EMP blasts.", "1: Chain lightning  2: EMP column  3: Thunderstorm" },
};

const ModWeatherDef gModWeathers[NUM_MOD_WEATHERS] = {
	{ "Clear",     "No weather effects." },
	{ "Rain",      "Zombies -10% speed, sun production -20%, fire weaker." },
	{ "Storm",     "Rain plus lightning strikes that hit random tiles." },
	{ "Fog",       "Low visibility: zombies far right take 20% less damage." },
	{ "Snow",      "Zombies -20% speed (not ice-immune), plants fire 10% slower." },
	{ "Darkness",  "No sky sun, sun production -30%, mushrooms +20% damage." },
	{ "Wind",      "Lobbed shots drift, balloons fly faster, fog is blown away." },
	{ "Heatwave",  "Sun +25%, ice effects halved, ice-immune zombies take +50% damage." },
};
const ModWeatherDef gModEvents[NUM_MOD_EVENTS] = {
	{ "",               "" },
	{ "Blood Moon",     "Rare: zombies +30% speed, every zombie mutated." },
	{ "Meteor Shower",  "Rare: meteors hit zombies (and sometimes plants)." },
	{ "Aurora",         "Rare: double sun, plants regenerate." },
	{ "Eclipse",        "Rare: total darkness, invisible zombies everywhere." },
};

const ModGameModeDef gModGameModes[NUM_MOD_GAME_MODES] = {
	{ "Off",              "Play the level normally." },
	{ "Endless Survival", "The level never ends; zombies get tougher every cycle." },
	{ "Zombie Rush",      "Waves arrive three times faster." },
	{ "Boss Rush",        "Every flag wave brings a boss." },
	{ "Random Waves",     "Every zombie becomes a random type and variant." },
	{ "Hardcore",         "+50% zombie health, faster zombies, no lawn mowers, pricier plants." },
	{ "No-Sun Challenge", "No sky sun and sun plants are useless. Start with 1500 sun." },
	{ "Single Lane",      "Zombies and plants use only one lane." },
	{ "Zombie Invasion",  "Triple-sized waves full of variants." },
	{ "Random Plants",    "Your seed packets are replaced with random plants." },
	{ "Random Zombies",   "The level uses random zombie types." },
	{ "Custom Waves",     "Waves use the zombies you configured in Custom Waves." },
	{ "Sandbox",          "Infinite sun, no cooldowns, zombies cannot win. Tap to spawn." },
};

const ModTraitDef gModTraits[NUM_MOD_TRAITS] = {
	{ "Swift",    "+30% fire rate" },
	{ "Mighty",   "+35% damage" },
	{ "Sturdy",   "+75% health" },
	{ "Lucky",    "+20% critical chance" },
	{ "Frosty",   "Shots chill zombies" },
	{ "Vampiric", "Heals when dealing damage" },
	{ "Thorny",   "Reflects 30% of bite damage" },
};

const ModPlantAbilityDef gModPlantAbilities[] = {
	{ SEED_PEASHOOTER,  "Peashooter",   "12% chance to fire a piercing pea",              "Sniper: 30% pierce, +20% damage",    "Rapid: +30% fire rate",            300 },
	{ SEED_SUNFLOWER,   "Sunflower",    "10% chance to make an extra sun",                "Solar: 25% extra sun",              "Nurse: heals adjacent plants",     300 },
	{ SEED_CHERRYBOMB,  "Cherry Bomb",  "Bigger blast radius",                           "Mega: even bigger blast",           "Napalm: burns the row behind",    150 },
	{ SEED_WALLNUT,     "Wall-nut",     "Reflects 25% of bite damage",                   "Thorns: reflects 60%",              "Regrowth: regenerates health",     300 },
	{ SEED_POTATOMINE,  "Potato Mine",  "Arms 35% faster",                               "Big Bang: larger explosion",       "Instant: arms almost instantly",   150 },
	{ SEED_SNOWPEA,     "Snow Pea",     "8% chance to freeze a zombie solid",             "Glacier: 18% freeze chance",        "Frostbite: +40% damage",           300 },
	{ SEED_CHOMPER,     "Chomper",      "Swallows small zombies; digests 40% faster",    "Glutton: digests 70% faster",       "Shredder: chews big zombies (400 dmg)", 300 },
	{ SEED_REPEATER,    "Repeater",     "Every 12th volley triggers rapid fire",         "Overdrive: longer rapid fire",      "Heavy peas: +25% damage",          300 },
	{ SEED_PUFFSHROOM,  "Puff-shroom",  "+50% damage at night",                          "Toxic spores: poisons zombies",     "Long puff: +40% damage",          200 },
	{ SEED_SUNSHROOM,   "Sun-shroom",   "Grows up twice as fast",                        "Moon sun: +25% sun",                "Spore heal: heals neighbours",     200 },
	{ SEED_FUMESHROOM,  "Fume-shroom",  "+50% damage against shields",                   "Corrosion: poisons",                "Pressure: +25% damage",            300 },
	{ SEED_GRAVEBUSTER, "Grave Buster", "Gives 50 sun after eating a grave",             "Fast eater",                        "Treasure: drops coins",            100 },
	{ SEED_HYPNOSHROOM, "Hypno-shroom", "Hypnotized zombie gets +100% health",           "Champion: +200% health",            "Berserk: hypnotized zombie is much faster", 150 },
	{ SEED_SCAREDYSHROOM,"Scaredy-shroom","+60% damage",                                  "Brave: +30% fire rate",                 "Sniper: piercing spores",          200 },
	{ SEED_ICESHROOM,   "Ice-shroom",   "Freezes 50% longer and deals 40 damage",        "Permafrost: freezes twice as long", "Shatter: frozen zombies take +25%", 150 },
	{ SEED_DOOMSHROOM,  "Doom-shroom",  "Crater disappears much sooner",                 "Annihilation: bigger blast",        "Clean: no crater",                 150 },
	{ SEED_SQUASH,      "Squash",       "Shockwave damages zombies in neighbouring tiles","Quake: bigger shockwave",          "Double: hits twice",               150 },
	{ SEED_THREEPEATER, "Threepeater",  "10% chance of piercing peas",                   "Spread: +20% damage",               "Gatling: +25% fire rate",          300 },
	{ SEED_JALAPENO,    "Jalapeno",     "Also scorches the neighbouring rows (200 dmg)", "Inferno: full burn on 3 rows",      "Ember: leaves burning ground",     150 },
	{ SEED_SPIKEWEED,   "Spikeweed",    "Spikes poison zombies",                         "Razor: +50% damage",                "Caltrops: slows zombies",          200 },
	{ SEED_TORCHWOOD,   "Torchwood",    "Fire peas deal +25% damage",                    "Blaze: +50% fire damage",           "Warmth: protects plants from ice", 300 },
	{ SEED_TALLNUT,     "Tall-nut",     "Reflects 15% of bite damage",                   "Spiked: reflects 40%",              "Regrowth: regenerates",            300 },
	{ SEED_PLANTERN,    "Plantern",     "Reveals invisible zombies nearby",              "Beacon: reveals the whole lawn",    "Sunlight: produces small sun",     150 },
	{ SEED_CACTUS,      "Cactus",       "Spikes pierce up to 3 zombies",                 "Needles: pierce 5",                 "Barbs: +30% damage",               300 },
	{ SEED_BLOVER,      "Blover",       "Also clears weather for 30 seconds",            "Hurricane: pushes zombies back",    "Breeze: chills zombies",           150 },
	{ SEED_SPLITPEA,    "Split Pea",    "Backward peas deal double damage",              "Guard: +30% fire rate",             "Heavy: +25% damage",               300 },
	{ SEED_STARFRUIT,   "Starfruit",    "15% chance of piercing stars",                  "Nova: +25% damage",                 "Comet: 35% pierce",                300 },
	{ SEED_PUMPKINSHELL,"Pumpkin",      "Reflects 20% of bite damage",                   "Iron shell: +100% health",          "Spiked shell: reflects 50%",       200 },
	{ SEED_MAGNETSHROOM,"Magnet-shroom","Recharges 50% faster",                          "Super magnet: recharges 80% faster","Shrapnel: damages the zombie",     200 },
	{ SEED_CABBAGEPULT, "Cabbage-pult", "15% chance of a heavy cabbage that stuns",      "Heavy: 30% stun chance",            "Splash: hits nearby zombies",      300 },
	{ SEED_KERNELPULT,  "Kernel-pult",  "Butter chance x2; 5% explosive butter",         "Butter bomb: 12% explosive",        "Popcorn: +30% damage",             300 },
	{ SEED_GARLIC,      "Garlic",       "Lasts 50% longer",                              "Stink: poisons biters",             "Fortress: +100% health",           150 },
	{ SEED_MELONPULT,   "Melon-pult",   "+25% splash damage",                            "Watermelon storm: +40% damage",     "Heavy: stuns on hit",              300 },
	{ SEED_GATLINGPEA,  "Gatling Pea",  "Every 10th volley triggers rapid fire",         "Minigun: longer rapid fire",        "Piercing: 15% pierce",             300 },
	{ SEED_TWINSUNFLOWER,"Twin Sunflower","15% chance of an extra sun",                   "Solar farm: 30%",                   "Nurse: heals adjacent plants",     300 },
	{ SEED_GLOOMSHROOM, "Gloom-shroom", "+30% damage",                                    "Miasma: poisons",                   "Pressure: +30% more damage",       300 },
	{ SEED_CATTAIL,     "Cattail",      "15% chance of piercing spikes",                 "Hunter: +25% damage",               "Quick: +25% fire rate",            300 },
	{ SEED_WINTERMELON, "Winter Melon", "10% chance to freeze zombies solid",            "Absolute: 20% freeze",              "Avalanche: +25% damage",           300 },
	{ SEED_SPIKEROCK,   "Spikerock",    "Reflects bites and poisons zombies",            "Obsidian: +100% health",            "Razor: +50% damage",               200 },
	{ SEED_COBCANNON,   "Cob Cannon",   "Reloads 30% faster",                            "Rapid: reloads 50% faster",         "Mega cob: bigger blast",           150 },
};
const int NUM_MOD_PLANT_ABILITIES = sizeof(gModPlantAbilities) / sizeof(gModPlantAbilities[0]);

int ModFindPlantAbility(SeedType theSeed)
{
	for (int i = 0; i < NUM_MOD_PLANT_ABILITIES; i++)
		if (gModPlantAbilities[i].mSeed == theSeed)
			return i;
	return -1;
}

const ModPlantComboDef gModPlantCombos[NUM_MOD_PLANT_COMBOS] = {
	{ "Flame Line",  "Peashooters behind a Torchwood fire 15% faster." },
	{ "Solar Grid",  "Sunflowers next to 2+ sun plants make 10% more sun." },
	{ "Bulwark",     "Nuts in front of a shooter regenerate health." },
	{ "Deep Freeze", "Snow Pea + Winter Melon in a lane: +5% freeze chance." },
	{ "Salad Bar",   "Kernel-pult next to Cabbage-pult: +50% butter chance." },
	{ "Spore Cloud", "Fume/Gloom-shroom next to another shroom: +20% damage." },
	{ "Star Fort",   "Starfruit next to Pumpkin-protected plants: +15% damage." },
};

static const char* const kZombieNames[NUM_ZOMBIE_TYPES] = {
	"Zombie", "Flag Zombie", "Conehead", "Pole Vaulter", "Buckethead", "Newspaper", "Screen Door", "Football",
	"Dancing Zombie", "Backup Dancer", "Ducky Tube", "Snorkel", "Zomboni", "Bobsled Team", "Dolphin Rider",
	"Jack-in-the-Box", "Balloon", "Digger", "Pogo", "Zombie Yeti", "Bungee", "Ladder", "Catapult", "Gargantuar",
	"Imp", "Dr. Zomboss", "Peashooter Zombie", "Wall-nut Zombie", "Jalapeno Zombie", "Gatling Zombie",
	"Squash Zombie", "Tall-nut Zombie", "Giga-gargantuar"
};

const char* ModZombieTypeName(ZombieType theType)
{
	if (theType < 0 || theType >= NUM_ZOMBIE_TYPES)
		return "?";
	return kZombieNames[theType];
}

const ZombieType gModSpawnableZombieTypes[] = {
	ZOMBIE_NORMAL, ZOMBIE_FLAG, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL, ZOMBIE_NEWSPAPER, ZOMBIE_DOOR,
	ZOMBIE_FOOTBALL, ZOMBIE_DANCER, ZOMBIE_DUCKY_TUBE, ZOMBIE_SNORKEL, ZOMBIE_ZAMBONI, ZOMBIE_DOLPHIN_RIDER,
	ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_BALLOON, ZOMBIE_DIGGER, ZOMBIE_POGO, ZOMBIE_YETI, ZOMBIE_BUNGEE, ZOMBIE_LADDER,
	ZOMBIE_CATAPULT, ZOMBIE_GARGANTUAR, ZOMBIE_IMP, ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_JALAPENO_HEAD,
	ZOMBIE_GATLING_HEAD, ZOMBIE_SQUASH_HEAD, ZOMBIE_TALLNUT_HEAD, ZOMBIE_REDEYE_GARGANTUAR
};
const int NUM_MOD_SPAWNABLE_ZOMBIES = sizeof(gModSpawnableZombieTypes) / sizeof(gModSpawnableZombieTypes[0]);
const char* const gModSpawnableZombieNames[] = {
	"Zombie", "Flag Zombie", "Conehead", "Pole Vaulter", "Buckethead", "Newspaper", "Screen Door",
	"Football", "Dancing Zombie", "Ducky Tube", "Snorkel", "Zomboni", "Dolphin Rider",
	"Jack-in-the-Box", "Balloon", "Digger", "Pogo", "Zombie Yeti", "Bungee", "Ladder",
	"Catapult", "Gargantuar", "Imp", "Peashooter Zombie", "Wall-nut Zombie", "Jalapeno Zombie",
	"Gatling Zombie", "Squash Zombie", "Tall-nut Zombie", "Giga-gargantuar"
};
