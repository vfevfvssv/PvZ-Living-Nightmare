// PvZ Living Nightmare - zombie variants, classes, mutations, abilities and bosses.
#include "ModInternal.h"

using namespace ModInt;

namespace
{
	struct SpawnSpec { int mVariant = -1; int mClass = -1; int mBoss = -1; int mMutations = 0; bool mMini = false; };
	bool sSuppressRoll = false;
	bool sShotInProgress = false;

	inline ZombieModState& M(Zombie* z) { return z->mMod; }

	bool IsBossType(Zombie* z) { return z->mZombieType == ZOMBIE_BOSS; }

	// zombies that should never be modified (cutscene / UI / special engine zombies)
	bool Moddable(Zombie* z)
	{
		if (!z->IsOnBoard() || IsBossType(z))
			return false;
		LawnApp* a = gApp;
		if (a->IsIZombieLevel() || a->mGameMode == GAMEMODE_CHALLENGE_ZOMBIQUARIUM || a->IsWhackAZombieLevel() ||
			a->mGameMode == GAMEMODE_CHALLENGE_ZEN_GARDEN || a->mGameMode == GAMEMODE_TREE_OF_WISDOM)
			return false;
		return true;
	}

	float HealthFrac(Zombie* z)
	{
		int aMax = z->mBodyMaxHealth + z->mHelmMaxHealth + z->mShieldMaxHealth + z->mFlyingMaxHealth;
		int aCur = z->mBodyHealth + z->mHelmHealth + z->mShieldHealth + z->mFlyingHealth;
		return aMax > 0 ? std::clamp(static_cast<float>(aCur) / aMax, 0.0f, 1.0f) : 0.0f;
	}

	void ScaleHealth(Zombie* z, float f)
	{
		auto sc = [f](int32_t& v) { if (v > 0) v = std::max(1, static_cast<int>(std::lround(v * f))); };
		sc(z->mBodyHealth); sc(z->mBodyMaxHealth);
		sc(z->mHelmHealth); sc(z->mHelmMaxHealth);
		sc(z->mShieldHealth); sc(z->mShieldMaxHealth);
		sc(z->mFlyingHealth); sc(z->mFlyingMaxHealth);
	}

	void HealZombie(Zombie* z, int theAmount)
	{
		if (theAmount <= 0 || z->IsDeadOrDying()) return;
		z->mBodyHealth = std::min(z->mBodyMaxHealth, z->mBodyHealth + theAmount);
	}

	int PickWeighted(const std::vector<int>& theIdx, const std::vector<float>& theW)
	{
		float aTotal = 0;
		for (float w : theW) aTotal += w;
		if (aTotal <= 0 || theIdx.empty()) return -1;
		float r = RandRangeFloat(0.0f, aTotal);
		for (size_t i = 0; i < theIdx.size(); i++)
		{
			r -= theW[i];
			if (r <= 0) return theIdx[i];
		}
		return theIdx.back();
	}

	int RollVariant(ZombieType theType, bool theForce)
	{
		std::vector<int> aIdx;
		std::vector<float> aW;
		for (int i = 0; i < NUM_MOD_VARIANTS; i++)
		{
			if (gModVariants[i].mBase != theType || !VariantUnlocked(i)) continue;
			aIdx.push_back(i);
			aW.push_back(gModVariants[i].mTier == 0 ? 3.0f : gModVariants[i].mTier == 1 ? 2.0f : 1.0f);
		}
		if (aIdx.empty()) return -1;
		if (!theForce)
		{
			float aChance = Opt(OPT_D_VARIANT_CHANCE) * (1.0f + gW.mAdaptive);
			if (IsMode(MODE_INVASION) || IsMode(MODE_RANDOM_WAVES)) aChance = std::max(aChance, 60.0f);
			if (!Chance(aChance)) return -1;
		}
		return PickWeighted(aIdx, aW);
	}

	int RollClass()
	{
		std::vector<int> aIdx; std::vector<float> aW;
		for (int i = 0; i < NUM_MOD_CLASSES; i++)
			if (On(OPT_CL_ON_0 + i)) { aIdx.push_back(i); aW.push_back(1.0f); }
		return PickWeighted(aIdx, aW);
	}

	int RollMutation(int theExisting)
	{
		std::vector<int> aIdx; std::vector<float> aW;
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
		{
			if (!On(OPT_MUT_ON_0 + i) || (theExisting & (1 << i))) continue;
			float w = Opt(OPT_MUT_W_0 + i);
			if (w <= 0) continue;
			aIdx.push_back(i); aW.push_back(w);
		}
		return PickWeighted(aIdx, aW);
	}

	int RollMutations(bool theForce)
	{
		float aChance = Opt(OPT_MU_CHANCE) * (1.0f + gW.mAdaptive);
		if (EventIs(EVENT_BLOOD_MOON)) theForce = true;
		if (!theForce && !Chance(aChance)) return 0;
		int aMax = std::max(1, OptI(OPT_MU_MAX));
		int aMask = 0;
		int aFirst = RollMutation(0);
		if (aFirst < 0) return 0;
		aMask |= 1 << aFirst;
		for (int n = 1; n < aMax; n++)
		{
			if (!Chance(30.0f)) break;   // each extra mutation is rarer
			int m = RollMutation(aMask);
			if (m < 0) break;
			aMask |= 1 << m;
		}
		return aMask;
	}

	// Recomputes abilities, combo and stat multipliers from variant/class/mutations, applying health scaling.
	void ApplySpec(Zombie* z, const SpawnSpec& s, bool theScaleHealth)
	{
		ZombieModState& m = M(z);
		m.mVariant = static_cast<int16_t>(s.mVariant);
		m.mClass = static_cast<int8_t>(s.mClass);
		m.mMutations = static_cast<uint16_t>(s.mMutations);
		m.mMini = s.mMini;
		m.mCombo = -1;

		uint32_t ab = 0;
		float hp = 1.0f, scale = 1.0f;
		if (s.mVariant >= 0 && s.mVariant < NUM_MOD_VARIANTS)
		{
			const ModVariantDef& v = gModVariants[s.mVariant];
			ab |= v.mAbilities; hp *= v.mHealth; scale *= v.mScale;
			gP.mVariantSeen[s.mVariant]++;
		}
		if (s.mClass >= 0 && s.mClass < NUM_MOD_CLASSES)
		{
			const ModClassDef& c = gModClasses[s.mClass];
			float pw = ClassPower(s.mClass);
			ab |= c.mGrants;
			hp *= 1.0f + (c.mHealth - 1.0f) * pw;
		}
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
		{
			if (!(s.mMutations & (1 << i))) continue;
			const ModMutationDef& mu = gModMutations[i];
			ab |= mu.mGrants; hp *= mu.mHealth; scale *= mu.mScale;
		}
		if (On(OPT_MU_COMBOS))
		{
			for (int i = 0; i < NUM_MOD_COMBOS; i++)
			{
				const ModComboDef& c = gModCombos[i];
				if ((s.mMutations & (1 << c.mMutA)) && (s.mMutations & (1 << c.mMutB)))
				{
					m.mCombo = static_cast<int8_t>(i);
					ab |= c.mGrants; hp *= c.mHealth;
					break;
				}
			}
		}
		if (s.mMini) { hp *= 0.35f; scale *= 0.65f; ab &= ~(AB_SPLIT | AB_SUMMON | AB_NECRO); }
		if (s.mBoss < 0)
		{
			hp *= Opt(OPT_Z_HP);
			scale *= Opt(OPT_Z_SIZE);
			if (IsMode(MODE_HARDCORE)) hp *= 1.5f;
			if (IsMode(MODE_ENDLESS) && gW.mEndlessCycle > 0) hp *= 1.0f + Opt(OPT_M_ENDLESS_SCALE) / 100.0f * gW.mEndlessCycle;
		}
		m.mAbilities = ab;
		if (theScaleHealth && std::fabs(hp - 1.0f) > 0.001f)
			ScaleHealth(z, hp);
		if (std::fabs(scale - 1.0f) > 0.001f)
		{
			z->mScaleZombie *= scale;
			m.mBaseScale = scale;
		}
		if (ab & AB_BUBBLE)
		{
			m.mShieldMax = std::max(150, z->mBodyMaxHealth / 3);
			m.mShieldHP = m.mShieldMax;
		}
		m.mUnderground = (ab & AB_TUNNEL) != 0 && !z->mInPool && z->mZombieHeight == HEIGHT_ZOMBIE_NORMAL;
		if (s.mBoss >= 0) BossInit(z, s.mBoss);
	}

	float SpeedFactor(Zombie* z)
	{
		ZombieModState& m = M(z);
		float f = Opt(OPT_Z_SPEED);
		uint32_t ab = m.mAbilities | m.mTempAbilities;
		if (m.mVariant >= 0) f *= gModVariants[m.mVariant].mSpeed;
		if (m.mClass >= 0) f *= 1.0f + (gModClasses[m.mClass].mSpeed - 1.0f) * ClassPower(m.mClass);
		if (m.mMutations & (1 << MUT_FAST)) f *= gModMutations[MUT_FAST].mSpeed;
		if (m.mMutations & (1 << MUT_GIANT)) f *= gModMutations[MUT_GIANT].mSpeed;
		if (m.mCombo >= 0) f *= gModCombos[m.mCombo].mSpeed;
		if (m.mBoss >= 0) f *= gModBosses[m.mBoss].mSpeed * (m.mBossPhase >= 2 ? 1.35f : 1.0f);
		if ((ab & AB_SPRINT) && ((z->mZombieAge + m.mPhase) % 700) < 180) f *= 2.0f;
		if ((ab & AB_BERSERK) && HealthFrac(z) < 0.4f) f *= 1.8f;
		if (ab & AB_RAGE) f *= 1.0f + 0.03f * m.mRageStacks;
		if (m.mMini) f *= 1.2f;
		f *= m.mAuraSpeed;
		if (!z->mMindControlled)
		{
			if (WeatherIs(WEATHER_RAIN) || WeatherIs(WEATHER_STORM)) f *= 1.0f - 0.10f * std::min(1.0f, WeatherAmount(WEATHER_RAIN) + WeatherAmount(WEATHER_STORM));
			if (WeatherIs(WEATHER_SNOW) && !(ab & AB_ICE_IMMUNE) && z->mZombieType != ZOMBIE_YETI) f *= 1.0f - 0.20f * std::min(1.5f, WeatherAmount(WEATHER_SNOW));
			if (WeatherIs(WEATHER_WIND) && z->mZombieType == ZOMBIE_BALLOON) f *= 1.0f + 0.5f * WeatherAmount(WEATHER_WIND);
			if (WeatherIs(WEATHER_HEAT) && (ab & AB_ICE_IMMUNE)) f *= 0.85f;
			if (EventIs(EVENT_BLOOD_MOON)) f *= 1.3f;
			if (IsMode(MODE_HARDCORE)) f *= 1.25f;
			if (IsMode(MODE_RUSH)) f *= 1.15f;
		}
		return std::clamp(f, 0.05f, 8.0f);
	}

	Zombie* SpawnWithSpec(ZombieType theType, int theRow, const SpawnSpec& s, float thePosX = -1.0f)
	{
		Board* b = GetBoard();
		if (!b) return nullptr;
		if (theRow < 0 || !b->RowCanHaveZombieType(theRow, theType))
		{
			theRow = -1;
			for (int t = 0; t < 12 && theRow < 0; t++)
			{
				int r = Rand(b->StageHas6Rows() ? 6 : 5);
				if (b->RowCanHaveZombieType(r, theType)) theRow = r;
			}
			if (theRow < 0) return nullptr;
		}
		if (b->mZombies.mSize >= b->mZombies.mMaxSize - 8) return nullptr;
		sSuppressRoll = true;
		Zombie* z = b->AddZombieInRow(theType, theRow, b->mCurrentWave);
		sSuppressRoll = false;
		if (!z) return nullptr;
		ApplySpec(z, s, true);
		z->UpdateAnimSpeed();
		if (thePosX >= 0.0f && theType != ZOMBIE_BUNGEE)
		{
			z->mPosX = thePosX;
			z->mX = static_cast<int>(thePosX);
		}
		return z;
	}

	void SpawnMini(Zombie* theParent, ZombieType theType, float theOffset, int theExtraMut)
	{
		SpawnSpec s;
		s.mMini = true;
		s.mMutations = theExtraMut;
		Zombie* z = SpawnWithSpec(theType, theParent->mRow, s, std::clamp(theParent->mPosX + theOffset, 0.0f, 850.0f));
		if (z && theParent->mMindControlled) z->StartMindControlled();
	}

	bool IsWalkerType(Zombie* z)
	{
		switch (z->mZombieType)
		{
		case ZOMBIE_NORMAL: case ZOMBIE_FLAG: case ZOMBIE_TRAFFIC_CONE: case ZOMBIE_PAIL: case ZOMBIE_NEWSPAPER: case ZOMBIE_DOOR:
		case ZOMBIE_FOOTBALL: case ZOMBIE_LADDER: case ZOMBIE_YETI: case ZOMBIE_IMP: case ZOMBIE_POGO:
		case ZOMBIE_PEA_HEAD: case ZOMBIE_WALLNUT_HEAD: case ZOMBIE_TALLNUT_HEAD: case ZOMBIE_JALAPENO_HEAD: case ZOMBIE_GATLING_HEAD: case ZOMBIE_SQUASH_HEAD:
			return true;
		default:
			return false;
		}
	}

	bool InNormalPhase(Zombie* z)
	{
		return z->mZombiePhase == PHASE_ZOMBIE_NORMAL || z->mZombiePhase == PHASE_NEWSPAPER_MAD || z->mZombiePhase == PHASE_NEWSPAPER_READING ||
			z->mZombiePhase == PHASE_POLEVAULTER_POST_VAULT || z->mZombiePhase == PHASE_LADDER_PLACING ||
			z->mZombiePhase == PHASE_DIGGER_WALKING || z->mZombiePhase == PHASE_POGO_BOUNCING || z->mZombiePhase == PHASE_YETI_RUNNING;
	}

	void TryLaneHop(Zombie* z)
	{
		Board* b = z->mBoard;
		if (z->mIsEating || !InNormalPhase(z) || z->mInPool || z->mPosX > 760 || z->IsFlying()) return;
		int aDir = Rand(2) ? 1 : -1;
		for (int t = 0; t < 2; t++, aDir = -aDir)
		{
			int r = z->mRow + aDir;
			if (r < 0 || r >= (b->StageHas6Rows() ? 6 : 5)) continue;
			if (!b->RowCanHaveZombieType(r, z->mZombieType) || b->mPlantRow[r] == PLANTROW_POOL) continue;
			z->SetRow(r);
			z->mPosY = z->GetPosYBasedOnRow(r);
			if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 100, z->mRenderOrder + 1, PARTICLE_DUST_FOOT);
			return;
		}
	}

	void ChainLightning(Zombie* z, int theTargets, int theDamage, float theRange, int theRowSpan)
	{
		Board* b = z->mBoard;
		float zx = z->mPosX + 40, zy = z->mPosY + 50;
		std::vector<Plant*> aHit;
		for (Plant* p : b->mPlants)
		{
			if (p->mDead || p->NotOnGround()) continue;
			if (std::abs(p->mRow - z->mRow) > theRowSpan) continue;
			float dx = zx - (p->mX + 40);
			if (dx < -30 || dx > theRange) continue;
			aHit.push_back(p);
		}
		std::sort(aHit.begin(), aHit.end(), [zx](Plant* a, Plant* c) { return std::fabs(zx - a->mX) < std::fabs(zx - c->mX); });
		float lx = zx, ly = zy;
		int n = 0;
		for (Plant* p : aHit)
		{
			if (n >= theTargets) break;
			if (PlantProtected(p)) continue;
			AddBolt(lx, ly, p->mX + 40.0f, p->mY + 40.0f, 140, 210, 255);
			lx = p->mX + 40.0f; ly = p->mY + 40.0f;
			DamagePlant(p, theDamage);
			n++;
		}
		if (n > 0)
		{
			gApp->PlayFoley(FOLEY_BUGSPRAY);
			if (M(z).mCombo == COMBO_DYNAMO) HealZombie(z, z->mBodyMaxHealth / 20);
		}
	}

	void DoStomp(Zombie* z, int theDamage, float theReach)
	{
		Board* b = z->mBoard;
		bool any = false;
		for (Plant* p : b->mPlants)
		{
			if (p->mDead || p->NotOnGround() || p->mRow != z->mRow) continue;
			float px = p->mX + 40.0f;
			float zx = z->mPosX + 40.0f;
			if (px < zx - theReach || px > zx + 30) continue;
			DamagePlant(p, theDamage);
			any = true;
		}
		if (On(OPT_V_ABILITY_FX))
			gApp->AddPvzpParticle(z->mPosX + 40, z->mPosY + 110, z->mRenderOrder + 1, PARTICLE_DUST_SQUASH);
		if (any) { gApp->PlayFoley(FOLEY_THUMP); ShakeIfAllowed(1, 2); }
	}

	void DoSabotage(Zombie* z, int theTicks)
	{
		Board* b = z->mBoard;
		int aCol = b->PixelToGridXKeepOnBoard(static_cast<int>(z->mPosX + 40), static_cast<int>(z->mPosY + 60));
		bool any = false;
		for (Plant* p : b->mPlants)
		{
			if (p->mDead) continue;
			if (std::abs(p->mPlantCol - aCol) <= 1 && std::abs(p->mRow - z->mRow) <= 1)
			{
				DisablePlant(p, theTicks);
				any = true;
			}
		}
		if (any)
		{
			gApp->PlayFoley(FOLEY_BLEEP);
			AddFloatingText(z->mPosX + 40, z->mPosY, "SABOTAGE", 200, 200, 200, 0.9f);
		}
	}

	void DoBuild(Zombie* z)
	{
		Board* b = z->mBoard;
		int aCol = b->PixelToGridXKeepOnBoard(static_cast<int>(z->mPosX + 40), static_cast<int>(z->mPosY + 60)) - 1;
		if (aCol < 1) return;
		int aRow = z->mRow + RandRangeInt(-1, 1);
		if (aRow < 0 || aRow >= (b->StageHas6Rows() ? 6 : 5)) aRow = z->mRow;
		if (b->mPlantRow[aRow] == PLANTROW_POOL) return;
		if (b->GetTopPlantAt(aCol, aRow, TOPPLANT_ANY) || b->GetGridItemAt(GRIDITEM_CRATER, aCol, aRow) || b->GetGridItemAt(GRIDITEM_GRAVESTONE, aCol, aRow))
			return;
		GridItem* g = b->AddACrater(aCol, aRow);
		if (g) g->mGridItemCounter = 1500;
		gApp->PlayFoley(FOLEY_DIGGER);
		AddFloatingText(z->mPosX + 20, z->mPosY, "CONSTRUCT", 230, 190, 120, 0.9f);
	}

	void DoNecro(Zombie* z, int theMax)
	{
		ZombieModState& m = M(z);
		Board* b = z->mBoard;
		if (m.mSummonCount >= theMax) return;
		int aCol = b->PixelToGridXKeepOnBoard(static_cast<int>(z->mPosX + 40), static_cast<int>(z->mPosY + 60)) - 1;
		if (aCol < 2 || aCol > 8 || b->mPlantRow[z->mRow] == PLANTROW_POOL) return;
		if (b->GetTopPlantAt(aCol, z->mRow, TOPPLANT_ANY)) aCol = std::min(8, aCol + 1);
		SpawnSpec s;
		s.mMini = true;
		sSuppressRoll = true;
		Zombie* r = b->AddZombieInRow(Rand(3) == 0 ? ZOMBIE_TRAFFIC_CONE : ZOMBIE_NORMAL, z->mRow, b->mCurrentWave);
		sSuppressRoll = false;
		if (!r) return;
		ApplySpec(r, s, true);
		r->RiseFromGrave(aCol, z->mRow);
		if (z->mMindControlled) r->StartMindControlled();
		m.mSummonCount++;
		gApp->PlayFoley(FOLEY_DIRT_RISE);
	}

	void DoSummon(Zombie* z, int theMax)
	{
		ZombieModState& m = M(z);
		if (m.mSummonCount >= theMax || z->mPosX > 780) return;
		ZombieType t = (z->mZombieType == ZOMBIE_GARGANTUAR || z->mZombieType == ZOMBIE_REDEYE_GARGANTUAR) ? ZOMBIE_IMP : ZOMBIE_NORMAL;
		if (!z->mBoard->RowCanHaveZombieType(z->mRow, t)) t = ZOMBIE_DUCKY_TUBE;
		SpawnMini(z, t, 25.0f, 0);
		m.mSummonCount++;
		if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 90, z->mRenderOrder + 1, PARTICLE_ZOMBIE_RISE);
		gApp->PlayFoley(FOLEY_GRAVESTONE_RUMBLE);
	}

	void DoFreezer(Zombie* z, bool theController)
	{
		Plant* p = FindPlantAhead(z, theController ? 200.0f : 120.0f);
		if (!p) return;
		FreezePlant(p, 180);
		if (theController)
		{
			for (Plant* q : z->mBoard->mPlants)
				if (!q->mDead && q->mRow == z->mRow && q->mX < z->mPosX + 40 && q->mX > z->mPosX - 240)
					q->mMod.mSlowed = std::max(q->mMod.mSlowed, 300);
		}
		if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(p->mX + 40, p->mY + 40, p->mRenderOrder + 1, PARTICLE_ICE_SPARKLE);
		gApp->PlayFoley(FOLEY_FROZEN);
	}

	void ToxicTrail(Zombie* z)
	{
		for (Plant* p : z->mBoard->mPlants)
		{
			if (p->mDead || p->mRow != z->mRow) continue;
			if (std::fabs((p->mX + 40) - (z->mPosX + 40)) < 45)
				p->mMod.mPoison = std::max(p->mMod.mPoison, 240);
		}
	}

	void MimicNearby(Zombie* z)
	{
		ZombieModState& m = M(z);
		Zombie* aBest = nullptr;
		float aBestD = 260.0f;
		for (Zombie* o : z->mBoard->mZombies)
		{
			if (o == z || o->mDead || o->IsDeadOrDying()) continue;
			uint32_t oab = o->mMod.mAbilities & ~(AB_MIMIC | AB_TUNNEL);
			if (!oab) continue;
			float d = std::fabs(o->mPosX - z->mPosX) + 80.0f * std::abs(o->mRow - z->mRow);
			if (d < aBestD) { aBestD = d; aBest = o; }
		}
		if (!aBest) return;
		uint32_t oab = aBest->mMod.mAbilities & ~(AB_MIMIC | AB_TUNNEL);
		std::vector<uint32_t> bits;
		for (int i = 0; i < NUM_MOD_ABILITIES; i++) if (oab & (1u << i)) bits.push_back(1u << i);
		uint32_t pick = bits[Rand(static_cast<int>(bits.size()))];
		m.mTempAbilities = pick;
		if (pick & AB_BUBBLE) { m.mShieldMax = std::max(m.mShieldMax, 150); m.mShieldHP = m.mShieldMax; }
		for (int i = 0; i < NUM_MOD_ABILITIES; i++)
			if (pick == (1u << i)) AddFloatingText(z->mPosX + 30, z->mPosY - 10, std::format("MIMIC: {}", gModAbilityInfo[i].mName), 255, 200, 255, 0.85f);
	}

	void OnDeath(Zombie* z)
	{
		ZombieModState& m = M(z);
		if (m.mDeathHandled || !m.mInitialized) return;
		m.mDeathHandled = true;
		if (!InPlay() || !z->IsOnBoard()) return;
		Board* b = z->mBoard;
		RecordKill(z);
		uint32_t ab = m.mAbilities | m.mTempAbilities;
		float cx = z->mPosX + 40.0f, cy = z->mPosY + 60.0f;
		bool ally = z->mMindControlled;

		if (m.mBoss >= 0) BossDeath(z);

		if (ab & AB_EXPLODE)
		{
			gApp->PlayFoley(FOLEY_EXPLOSION);
			gApp->AddPvzpParticle(cx, cy, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_POWIE);
			ShakeIfAllowed(2, -3);
			if (ally)
				b->KillAllZombiesInRadius(z->mRow, static_cast<int>(cx), static_cast<int>(cy), 90, 1, false, 127);
			else
				DamagePlantsInRadius(cx, cy, 95.0f, m.mCombo == COMBO_PLAGUE ? 150 : 300, m.mCombo == COMBO_PLAGUE, false);
		}
		if ((ab & AB_SPLIT) && !m.mMini)
		{
			int extra = (m.mCombo == COMBO_CLUSTER) ? (1 << MUT_EXPLOSIVE) : 0;
			ZombieType t = (z->mZombieType == ZOMBIE_DUCKY_TUBE || z->mInPool) ? ZOMBIE_DUCKY_TUBE : ZOMBIE_NORMAL;
			if (z->mZombieType == ZOMBIE_GARGANTUAR || z->mZombieType == ZOMBIE_REDEYE_GARGANTUAR) t = ZOMBIE_IMP;
			SpawnMini(z, t, -15.0f, extra);
			SpawnMini(z, t, 25.0f, extra);
			if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(cx, cy, z->mRenderOrder + 1, PARTICLE_ZOMBIE_RISE);
		}
		if ((ab & AB_DEATH_FREEZE) && !ally)
		{
			DamagePlantsInRadius(cx, cy, 120.0f, 0, m.mCombo == COMBO_PLAGUE, true);
			gApp->AddPvzpParticle(cx, cy, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_ICEBALL_DEATH);
			gApp->PlayFoley(FOLEY_FROZEN);
		}
		if (m.mStolenSun > 0)
		{
			int n = std::min(10, m.mStolenSun / 25 + 1);
			for (int i = 0; i < n; i++)
				b->AddCoin(static_cast<int>(cx) - 20 + i * 8, static_cast<int>(cy) - 30, COIN_SMALLSUN, COIN_MOTION_COIN);
			AddFloatingText(cx, cy - 40, std::format("+{} sun returned", m.mStolenSun), 255, 240, 120, 0.9f);
			m.mStolenSun = 0;
		}
		if (m.mElite && On(OPT_G_PLANT_FOOD))
		{
			ModSystem::AddPlantFood(1);
			AddFloatingText(cx, cy - 50, "+1 PLANT FOOD", 120, 255, 120, 1.1f);
		}
		if (On(OPT_E_KILL_SUN))
		{
			b->AddSunMoney(10);
			AddFloatingText(cx, cy - 20, "+10", 255, 240, 120, 0.8f);
		}
		if (b->CanDropLoot())
		{
			if (On(OPT_Z_EXTRA_LOOT))
				b->AddCoin(static_cast<int>(cx) - 10, static_cast<int>(cy) - 30, Rand(5) == 0 ? COIN_GOLD : COIN_SILVER, COIN_MOTION_COIN);
			if (Chance(Opt(OPT_E_DIAMOND_CHANCE)))
				b->AddCoin(static_cast<int>(cx) - 20, static_cast<int>(cy) - 30, COIN_DIAMOND, COIN_MOTION_COIN);
		}
		if (On(OPT_X_CHAIN_EXPLODE))
		{
			for (Zombie* o : b->mZombies)
			{
				if (o == z || o->mDead || o->IsDeadOrDying() || o->mMindControlled != ally) continue;
				if (std::abs(o->mRow - z->mRow) <= 1 && std::fabs(o->mPosX - z->mPosX) < 90)
					o->TakeDamage(100, 0U);
			}
			if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(cx, cy, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_POW);
		}
	}
}

namespace ModInt
{
	float ClassPower(int theClass) { return (theClass >= 0 && theClass < NUM_MOD_CLASSES) ? Opt(OPT_CL_POWER_0 + theClass) : 1.0f; }

	uint32_t Abilities(Zombie* z) { return z->mMod.mAbilities | z->mMod.mTempAbilities; }

	bool IsSpecial(Zombie* z)
	{
		const ZombieModState& m = z->mMod;
		return m.mVariant >= 0 || m.mClass >= 0 || m.mMutations != 0 || m.mBoss >= 0 || m.mElite;
	}

	bool IsLiveEnemy(Zombie* z) { return !z->mDead && !z->IsDeadOrDying() && !z->mMindControlled && z->mHasHead; }

	void FreezeZombie(Zombie* z, int theTicks)
	{
		if (z->IsDeadOrDying() || (Abilities(z) & AB_ICE_IMMUNE) || On(OPT_Z_IMMUNE_SLOW) || !z->CanBeFrozen()) return;
		if (WeatherIs(WEATHER_HEAT)) theTicks /= 2;
		if (z->mMod.mBoss >= 0) theTicks /= 3;
		z->ApplyChill(true);
		z->mIceTrapCounter = std::max(z->mIceTrapCounter, theTicks);
		z->UpdateAnimSpeed();
	}

	Plant* FindPlantAhead(Zombie* z, float theRange)
	{
		Plant* aBest = nullptr;
		float aBestX = -1e9f;
		float zx = z->mPosX + 40.0f;
		for (Plant* p : z->mBoard->mPlants)
		{
			if (p->mDead || p->NotOnGround() || p->mRow != z->mRow) continue;
			float px = p->mX + 40.0f;
			if (px > zx + 20 || px < zx - theRange) continue;
			if (px > aBestX) { aBestX = px; aBest = p; }
		}
		return aBest;
	}

	void LobAtPlant(Zombie* z, Plant* thePlant, ProjectileType theType)
	{
		Board* b = z->mBoard;
		float aOriginX = z->mPosX + 40.0f, aOriginY = z->mPosY + 10.0f;
		float aTargetX = thePlant ? thePlant->mX : z->mPosX - 300.0f;
		float aTargetY = thePlant ? thePlant->mY : 0.0f;
		gApp->PlayFoley(FOLEY_BASKETBALL);
		Projectile* p = b->AddProjectile(static_cast<int>(aOriginX), static_cast<int>(aOriginY), z->mRenderOrder, thePlant ? thePlant->mRow : z->mRow, theType);
		if (!p) return;
		float aRangeX = std::max(40.0f, aOriginX - aTargetX - 20.0f);
		float aRangeY = aTargetY - aOriginY;
		p->mMotionType = MOTION_LOBBED;
		p->mVelX = -aRangeX / 120.0f;
		p->mVelY = 0.0f;
		p->mVelZ = aRangeY / 120.0f - 7.0f;
		p->mAccZ = 0.115f;
	}

	void UpdateAuras(Board* b)
	{
		for (Zombie* z : b->mZombies)
		{
			if (z->mDead) continue;
			z->mMod.mAuraSpeed = 1.0f;
			z->mMod.mAuraDefense = 1.0f;
		}
		bool aSyn = On(OPT_CL_SYNERGY);
		int aScoutRows = 0;
		for (Zombie* s : b->mZombies)
		{
			if (s->mDead || s->IsDeadOrDying() || !s->mMod.mInitialized) continue;
			uint32_t ab = Abilities(s);
			int cls = s->mMod.mClass;
			if (cls == CLASS_SCOUT && !s->mMindControlled) aScoutRows |= 1 << s->mRow;
			if (!(ab & (AB_PROTECT | AB_HASTE_AURA | AB_HEALER)) && cls != CLASS_SUPPORT) continue;
			float pw = ClassPower(cls);
			for (Zombie* t : b->mZombies)
			{
				if (t == s || t->mDead || t->IsDeadOrDying() || t->mMindControlled != s->mMindControlled) continue;
				if (std::abs(t->mRow - s->mRow) > 1 || std::fabs(t->mPosX - s->mPosX) > 170) continue;
				if (ab & AB_PROTECT) t->mMod.mAuraDefense = std::min(t->mMod.mAuraDefense, 0.7f);
				if (cls == CLASS_SUPPORT) t->mMod.mAuraDefense = std::min(t->mMod.mAuraDefense, 1.0f - 0.15f * pw);
				if (ab & AB_HASTE_AURA)
				{
					float h = 1.25f;
					if (aSyn && cls == CLASS_SUPPORT && t->mMod.mClass == CLASS_ASSASSIN) h = 1.45f;
					t->mMod.mAuraSpeed = std::max(t->mMod.mAuraSpeed, h);
				}
				if (ab & AB_HEALER)
				{
					float aRate = 0.006f * (cls == CLASS_HEALER ? pw : 1.0f);
					if (aSyn && cls == CLASS_HEALER && t->mMod.mClass == CLASS_TANK) aRate *= 2.0f;
					HealZombie(t, std::max(1, static_cast<int>(t->mBodyMaxHealth * aRate)));
				}
			}
		}
		if (aScoutRows)
		{
			for (Zombie* z : b->mZombies)
				if (!z->mDead && !z->mMindControlled && (aScoutRows & (1 << z->mRow)))
					z->mMod.mAuraSpeed = std::max(z->mMod.mAuraSpeed, 1.15f);
		}
		// Synergy: Saboteur + Destroyer in the same lane -> destroyers resist damage while plants are disabled
		if (aSyn)
		{
			for (Zombie* z : b->mZombies)
			{
				if (z->mDead || z->mMod.mClass != CLASS_DESTROYER) continue;
				for (Zombie* o : b->mZombies)
					if (!o->mDead && o != z && o->mMod.mClass == CLASS_SABOTEUR && o->mRow == z->mRow)
					{ z->mMod.mAuraDefense = std::min(z->mMod.mAuraDefense, 0.8f); break; }
			}
		}
	}

	std::string ZombieDisplayName(Zombie* z)
	{
		const ZombieModState& m = z->mMod;
		if (m.mBoss >= 0) return gModBosses[m.mBoss].mName;
		std::string s = m.mVariant >= 0 ? gModVariants[m.mVariant].mName : ModZombieTypeName(z->mZombieType);
		if (m.mMini) s = "Mini " + s;
		return s;
	}
}

namespace ModSystem
{
	Zombie* SpawnZombie(ZombieType theType, int theRow, int theVariant, int theClass, int theBoss, int theMutations)
	{
		SpawnSpec s;
		s.mVariant = theVariant; s.mClass = theClass; s.mBoss = theBoss; s.mMutations = theMutations;
		return SpawnWithSpec(theType, theRow, s);
	}

	void ZombieInit(Zombie* z)
	{
		ZombieModState& m = z->mMod;
		m = ZombieModState();
		m.mInitialized = true;
		m.mPhase = Rand(10000);
		if (!gApp || !z->mBoard || !Moddable(z) || sSuppressRoll)
			return;

		SpawnSpec s;
		ZombieType t = z->mZombieType;
		if (IsMode(MODE_CUSTOM_WAVES) && z->mFromWave >= 0)
		{
			CustomWaveSpec(t, s.mVariant, s.mClass, s.mMutations);
			ApplySpec(z, s, true);
			return;
		}
		if (On(OPT_D_VARIANTS) || IsMode(MODE_RANDOM_WAVES) || IsMode(MODE_INVASION))
			s.mVariant = RollVariant(t, IsMode(MODE_RANDOM_WAVES) && Rand(2) == 0);
		if (On(OPT_CL_ENABLE) && Chance(Opt(OPT_CL_CHANCE) * (1.0f + gW.mAdaptive)))
			s.mClass = RollClass();
		if (On(OPT_MU_ENABLE) || EventIs(EVENT_BLOOD_MOON))
			s.mMutations = RollMutations(false);
		ApplySpec(z, s, true);
		if (On(OPT_G_PLANT_FOOD) && Chance(Opt(OPT_G_PF_CHANCE)))
			m.mElite = true;
		if (Chance(Opt(OPT_X_ALLY_CHANCE)))
			m.mStatusFlash = -1;   // marker: becomes an ally on its first update

		// Scout: picks the lane with the fewest plants
		if (m.mClass == CLASS_SCOUT && IsWalkerType(z) && z->mPosX > 700)
		{
			Board* b = z->mBoard;
			int aBest = z->mRow, aBestN = 999;
			for (int r = 0; r < (b->StageHas6Rows() ? 6 : 5); r++)
			{
				if (!b->RowCanHaveZombieType(r, t) || b->mPlantRow[r] == PLANTROW_POOL) continue;
				int n = 0;
				for (Plant* p : b->mPlants) if (!p->mDead && p->mRow == r) n++;
				if (n < aBestN) { aBestN = n; aBest = r; }
			}
			if (aBest != z->mRow && (!IsMode(MODE_SINGLE_LANE)))
			{
				z->SetRow(aBest);
				z->mPosY = z->GetPosYBasedOnRow(aBest);
			}
		}
	}

	bool ZombieFrozen(Zombie* z)
	{
		return On(OPT_Z_FREEZE) && z->mBoard && z->IsOnBoard() && !IsBossType(z);
	}

	float ZombieAnimFactor(Zombie* z)
	{
		if (!z->mBoard || !z->IsOnBoard() || !z->mMod.mInitialized) return 1.0f;
		if (ZombieFrozen(z)) return 0.0f;
		if (z->mIsEating)
		{
			float f = 1.0f;
			uint32_t ab = Abilities(z);
			if ((ab & AB_BERSERK) && HealthFrac(z) < 0.4f) f *= 1.5f;
			if (z->mMod.mCombo == COMBO_FRENZY) f *= 1.3f;
			if (z->mMod.mClass == CLASS_ASSASSIN) f *= 1.0f + 0.25f * ClassPower(CLASS_ASSASSIN);
			if (IsMode(MODE_HARDCORE)) f *= 1.2f;
			return f;
		}
		return SpeedFactor(z);
	}

	float ZombieWalkFactor(Zombie* z)
	{
		if (!z->mBoard || !z->IsOnBoard() || !z->mMod.mInitialized) return 1.0f;
		return SpeedFactor(z);
	}

	bool ZombieUntargetable(Zombie* z)
	{
		const ZombieModState& m = z->mMod;
		return (m.mInvisible && !RevealedByPlantern(z)) || m.mUnderground || m.mJumpCounter > 0;
	}

	bool ZombieIgnoresPlants(Zombie* z)
	{
		const ZombieModState& m = z->mMod;
		return m.mUnderground || m.mJumpCounter > 0;
	}

	bool ZombieBlockChill(Zombie* z)
	{
		if (!z->mBoard || !z->IsOnBoard()) return false;
		return On(OPT_Z_IMMUNE_SLOW) || (Abilities(z) & AB_ICE_IMMUNE) != 0;
	}

	bool ZombieBurnOverride(Zombie* z)
	{
		if (!InPlay() || !(Abilities(z) & AB_FIRE_IMMUNE)) return false;
		z->TakeDamage(600, 18U);
		AddFloatingText(z->mPosX + 40, z->mPosY, "FIREPROOF", 255, 160, 60, 0.9f);
		return true;
	}

	int ZombieTakeDamage(Zombie* z, int theDamage, unsigned int theFlags)
	{
		bool aShot = sShotInProgress;
		sShotInProgress = false;
		if (!gApp || !z->mBoard || !z->IsOnBoard() || theDamage <= 0) return theDamage;
		if (theFlags == 9U) return theDamage;   // head-loss health drain
		ZombieModState& m = z->mMod;
		if (On(OPT_Z_INVULN)) return 0;
		if (On(OPT_Z_ONEHIT)) return std::max(theDamage, 100000);
		uint32_t ab = Abilities(z);
		bool aExplosive = theDamage >= 1000;
		float f = 1.0f;
		if (m.mBoss < 0 || !aExplosive)
		{
			if (ab & AB_ARMOR) f *= aExplosive ? 1.0f : 0.6f;
			if (m.mClass >= 0) f *= 1.0f - (1.0f - gModClasses[m.mClass].mDefense) * ClassPower(m.mClass);
			f *= m.mAuraDefense;
		}
		if ((ab & AB_DODGE) && aShot && Rand(100) < 30)
		{
			AddFloatingText(z->mPosX + 40, z->mPosY + 10, "MISS", 230, 230, 230, 0.8f);
			return 0;
		}
		if (WeatherIs(WEATHER_FOG) && z->mPosX > 560) f *= 0.8f;
		if (WeatherIs(WEATHER_HEAT) && (ab & AB_ICE_IMMUNE)) f *= 1.5f;
		if (gW.mShatterTimer > 0 && z->mIceTrapCounter > 0) f *= 1.25f;
		if (m.mPoison > 0) f *= 1.1f;
		int d = std::max(1, static_cast<int>(std::lround(theDamage * f)));
		if (m.mBoss >= 0) d = BossDamage(z, d, aExplosive);
		if (d > 0 && m.mShieldHP > 0)
		{
			int aAbs = std::min(m.mShieldHP, d);
			m.mShieldHP -= aAbs;
			d -= aAbs;
			m.mShieldRecharge = 600;
			if (m.mShieldHP == 0) gApp->PlayFoley(FOLEY_SHIELD_HIT);
			if (d <= 0) return 0;
		}
		if (ab & AB_RAGE) m.mRageStacks = std::min(25, m.mRageStacks + 1);
		if (On(OPT_V_DMG_NUMBERS) && !aExplosive)
		{
			m.mDamageAccum += d;
			if (m.mDamageAccumTimer <= 0) m.mDamageAccumTimer = 10;
		}
		gP.mMaxDamageHit = std::max(gP.mMaxDamageHit, std::min(d, 99999));
		return d;
	}

	int ZombieBite(Zombie* z, Plant* p, int theDamage)
	{
		if (!InPlay() || !z->IsOnBoard()) return theDamage;
		if (On(OPT_Z_NOEAT) || PlantProtected(p)) return 0;
		ZombieModState& m = z->mMod;
		uint32_t ab = Abilities(z);
		float f = Opt(OPT_Z_BITE);
		if (m.mVariant >= 0) f *= gModVariants[m.mVariant].mBite;
		if (m.mClass >= 0) f *= 1.0f + (gModClasses[m.mClass].mBite - 1.0f) * ClassPower(m.mClass);
		if ((ab & AB_BERSERK) && HealthFrac(z) < 0.4f) f *= 2.0f;
		if (m.mCombo == COMBO_FRENZY) f *= 1.3f;
		if (m.mBoss >= 0) f *= 2.0f;
		if (IsMode(MODE_HARDCORE)) f *= 1.3f;
		if (m.mClass == CLASS_DESTROYER && (p->mSeedType == SEED_WALLNUT || p->mSeedType == SEED_TALLNUT || p->mSeedType == SEED_PUMPKINSHELL))
			f *= 2.0f;
		if (z->mMindControlled) f = 1.0f;
		int d = std::max(0, static_cast<int>(std::lround(theDamage * f)));

		// plant reflection (Wall-nut / Tall-nut / Pumpkin / Spikerock abilities, Thorny trait)
		float aReflect = 0.0f;
		if (PlantAbilityOn(p->mSeedType))
		{
			int br = PlantBranch(p->mSeedType);
			switch (p->mSeedType)
			{
			case SEED_WALLNUT:      aReflect = br == 1 ? 0.6f : 0.25f; break;
			case SEED_TALLNUT:      aReflect = br == 1 ? 0.4f : 0.15f; break;
			case SEED_PUMPKINSHELL: aReflect = br == 2 ? 0.5f : 0.2f; break;
			case SEED_SPIKEROCK:    aReflect = 0.3f; z->mMod.mPoison = std::max(z->mMod.mPoison, 300); break;
			case SEED_GARLIC:       if (br == 1) z->mMod.mPoison = std::max(z->mMod.mPoison, 300); break;
			default: break;
			}
		}
		if (p->mMod.mTrait == TRAIT_THORNY) aReflect += 0.3f;
		if (p->mMod.mCombos & (1 << PCOMBO_BULWARK)) aReflect += 0.1f;
		if (aReflect > 0.0f && d > 0)
			z->TakeDamage(std::max(1, static_cast<int>(d * aReflect * 2.0f)), 1U);  // DAMAGE_DOESNT_CAUSE_FLASH-ish bit

		if (!z->mMindControlled && d > 0)
		{
			if (ab & AB_VAMPIRE) HealZombie(z, d * 3);
			if (ab & AB_TOXIC) p->mMod.mPoison = std::max(p->mMod.mPoison, 600);
			if ((ab & AB_SUN_THIEF) && z->mBoard->mSunMoney >= 10 && !InfiniteSun())
			{
				z->mBoard->mSunMoney -= 10;
				m.mStolenSun += 10;
				if ((z->mZombieAge % 4) == 0) AddFloatingText(z->mPosX + 30, z->mPosY - 10, "-10 sun", 255, 220, 80, 0.8f);
			}
		}
		if (d > 0 && PlantAbilityOn(p->mSeedType) && (p->mSeedType == SEED_WALLNUT || p->mSeedType == SEED_TALLNUT || p->mSeedType == SEED_PUMPKINSHELL))
			AddPlantXP(p, d / 2);
		return d;
	}

	void ZombieUpdate(Zombie* z)
	{
		ZombieModState& m = z->mMod;
		if (!m.mInitialized) { m.mInitialized = true; m.mPhase = Rand(10000); }
		if (!InPlay() || !z->IsOnBoard()) return;

		// damage numbers
		if (m.mDamageAccumTimer > 0 && --m.mDamageAccumTimer == 0 && m.mDamageAccum > 0)
		{
			int v = m.mDamageAccum;
			m.mDamageAccum = 0;
			bool big = v >= 100;
			AddFloatingText(z->mPosX + 45.0f + RandRangeFloat(-8, 8), z->mPosY + 20.0f, std::to_string(v), 255, big ? 120 : 230, big ? 60 : 200, big ? 1.15f : 0.9f);
		}

		if (z->IsDeadOrDying() || z->mDead)
		{
			if (z->mZombiePhase == PHASE_ZOMBIE_DYING || z->mZombiePhase == PHASE_ZOMBIE_BURNED || z->mZombiePhase == PHASE_ZOMBIE_MOWERED)
				OnDeath(z);
			return;
		}
		if (m.mStatusFlash == -1)
		{
			m.mStatusFlash = 0;
			if (!z->mMindControlled && m.mBoss < 0) z->StartMindControlled();
		}
		if (ZombieFrozen(z)) return;

		Board* b = z->mBoard;
		const int age = z->mZombieAge + m.mPhase;
		uint32_t ab = m.mAbilities | m.mTempAbilities;
		bool ally = z->mMindControlled;
		bool fx = On(OPT_V_ABILITY_FX) && !On(OPT_V_LOW_FX);
		bool onLawn = z->mPosX < 780.0f;

		if (m.mPoison > 0)
		{
			m.mPoison--;
			if (m.mPoison % 40 == 0) z->TakeDamage(8, 1U);
		}
		if (((ab & AB_REGEN) || On(OPT_Z_REGEN)) && (z->mZombieAge % 30) == 0)
		{
			float r = (ab & AB_REGEN) ? 0.012f : 0.006f;
			if (m.mCombo == COMBO_DYNAMO) r *= 1.5f;
			HealZombie(z, std::max(1, static_cast<int>(z->mBodyMaxHealth * r)));
		}
		if ((ab & AB_GROW) && (z->mZombieAge % 120) == 0 && m.mGrowth < 1.4f)
		{
			m.mGrowth += 0.02f;
			z->mScaleZombie *= 1.0f + 0.02f / m.mGrowth;
			int add = z->mBodyMaxHealth / 50;
			z->mBodyMaxHealth += add;
			z->mBodyHealth += add;
		}
		if (m.mShieldMax > 0 && m.mShieldHP < m.mShieldMax && m.mShieldRecharge > 0 && --m.mShieldRecharge == 0)
		{
			m.mShieldHP = m.mShieldMax;
			if (fx) AddFloatingText(z->mPosX + 40, z->mPosY, "SHIELD UP", 140, 200, 255, 0.85f);
		}
		bool wasInvis = m.mInvisible;
		m.mInvisible = ((ab & AB_INVIS) && (age % 420) >= 240) || (EventIs(EVENT_ECLIPSE) && (age % 600) >= 420 && m.mBoss < 0);
		if (m.mInvisible != wasInvis && fx)
			gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 70, z->mRenderOrder + 1, PARTICLE_MOWER_CLOUD);
		if (m.mUnderground)
		{
			if (z->mPosX < 360.0f || z->mZombiePhase != PHASE_ZOMBIE_NORMAL || ally)
			{
				m.mUnderground = false;
				gApp->PlayFoley(FOLEY_DIRT_RISE);
				gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 100, z->mRenderOrder + 1, PARTICLE_DIGGER_RISE);
			}
			else if (fx && (z->mZombieAge % 25) == 0)
				gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 110, z->mRenderOrder + 1, PARTICLE_DIGGER_TUNNEL);
		}
		// Leap over the first plant
		if (m.mJumpCounter > 0)
		{
			m.mJumpCounter--;
			z->mPosX -= 3.4f;
			float t = 1.0f - m.mJumpCounter / 36.0f;
			if (!z->mOnHighGround && !z->mInPool && z->mZombieHeight == HEIGHT_ZOMBIE_NORMAL)
				z->mAltitude = 60.0f * std::sin(t * 3.14159f);
			if (m.mJumpCounter == 0)
			{
				z->mAltitude = 0.0f;
				gApp->PlayFoley(FOLEY_THUMP);
			}
		}
		else if ((ab & AB_JUMP) && !m.mHasJumped && z->mIsEating && !ally && IsWalkerType(z))
		{
			m.mHasJumped = true;
			m.mJumpCounter = 36;
			z->StopEating();
			gApp->PlayFoley(FOLEY_POLEVAULT);
		}

		if (!ally && onLawn && !m.mUnderground)
		{
			if (ab & AB_FREEZER)    { if (age % 480 == 0) DoFreezer(z, m.mClass == CLASS_CONTROLLER); }
			if (ab & AB_ELECTRIC)   { if (age % 420 == 0) ChainLightning(z, 3, 40, 260.0f, 0); }
			if (ab & AB_STOMP)      { if (age % 480 == 0) DoStomp(z, m.mBoss >= 0 ? 150 : 60, 100.0f); }
			if (ab & AB_SABOTAGE)   { if (age % 540 == 0) DoSabotage(z, m.mClass == CLASS_SABOTEUR ? static_cast<int>(240 * ClassPower(CLASS_SABOTEUR)) : 240); }
			if (ab & AB_ARTILLERY)  { if (age % 420 == 0) { Plant* p = FindPlantAhead(z, 450.0f); if (p && p->mX < z->mPosX - 90) LobAtPlant(z, p, PROJECTILE_BASKETBALL); } }
			if (ab & AB_SUMMON)     { if (age % 720 == 0) DoSummon(z, m.mClass == CLASS_SUMMONER ? 2 + static_cast<int>(ClassPower(CLASS_SUMMONER)) : 3); }
			if (ab & AB_NECRO)      { if (age % 840 == 0) DoNecro(z, 4); }
			if (ab & AB_BUILDER)    { if (age % 900 == 0) DoBuild(z); }
			if (ab & AB_LANE_HOP)   { if (age % 540 == 0) TryLaneHop(z); }
			if (ab & AB_MIMIC)      { if (age % 600 == 0) MimicNearby(z); }
			if (m.mMutations & (1 << MUT_TOXIC)) { if (age % 60 == 0) ToxicTrail(z); }
			if (m.mCombo == COMBO_GLACIER && age % 90 == 0)
			{
				for (Plant* p : b->mPlants)
					if (!p->mDead && std::abs(p->mRow - z->mRow) <= 1 && std::fabs(p->mX - z->mPosX) < 130)
						p->mMod.mSlowed = std::max(p->mMod.mSlowed, 120);
			}
			if (m.mClass == CLASS_SCOUT && age % 600 == 0 && fx)
				AddFloatingText(z->mPosX + 30, z->mPosY - 5, "SCOUTING", 180, 255, 255, 0.8f);
			if (On(OPT_X_LANE_SWITCH) && age % 900 == 450 && Rand(2) == 0) TryLaneHop(z);
		}
		if (m.mBoss >= 0) BossUpdate(z);

		float f = SpeedFactor(z);
		if (std::fabs(f - m.mLastSpeedFactor) > 0.02f)
		{
			m.mLastSpeedFactor = f;
			z->UpdateAnimSpeed();
		}
	}

	void ZombieTint(Zombie* z, Color& theColor, Color& theAdditive, bool& theUseAdditive)
	{
		if (!gApp || !z->mBoard || !z->IsOnBoard() || z->mZombiePhase == PHASE_ZOMBIE_BURNED) return;
		const ZombieModState& m = z->mMod;
		if (!m.mInitialized) return;
		if (On(OPT_V_TINTS) && !z->mMindControlled)
		{
			int r = 255, g = 255, bl = 255;
			bool tinted = false;
			auto mix = [&](int tr, int tg, int tb, float w)
			{
				r = static_cast<int>(r * (1 - w) + tr * w); g = static_cast<int>(g * (1 - w) + tg * w); bl = static_cast<int>(bl * (1 - w) + tb * w);
				tinted = true;
			};
			if (m.mBoss >= 0) mix(gModBosses[m.mBoss].mR, gModBosses[m.mBoss].mG, gModBosses[m.mBoss].mB, 0.75f);
			else if (m.mVariant >= 0) mix(gModVariants[m.mVariant].mR, gModVariants[m.mVariant].mG, gModVariants[m.mVariant].mB, 0.7f);
			if (m.mClass >= 0) mix(gModClasses[m.mClass].mR, gModClasses[m.mClass].mG, gModClasses[m.mClass].mB, 0.25f);
			for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
				if (m.mMutations & (1 << i)) mix(gModMutations[i].mR, gModMutations[i].mG, gModMutations[i].mB, 0.3f);
			if (tinted)
			{
				theColor.mRed = theColor.mRed * r / 255;
				theColor.mGreen = theColor.mGreen * g / 255;
				theColor.mBlue = theColor.mBlue * bl / 255;
			}
		}
		int aPulse = static_cast<int>(60 + 50 * std::sin((z->mZombieAge + m.mPhase) * 0.12f));
		if (m.mElite && On(OPT_G_PLANT_FOOD))
		{
			theAdditive = Color(40, std::clamp(aPulse * 2, 0, 255), 40, 255);
			theUseAdditive = true;
		}
		else if (m.mPoison > 0 && On(OPT_V_STATUS))
		{
			theAdditive = Color(20, 90, 0, 255);
			theUseAdditive = true;
		}
		else if (m.mBoss >= 0 && m.mBossPhase >= 2)
		{
			theAdditive = Color(std::clamp(aPulse * 2, 0, 255), 30, 0, 255);
			theUseAdditive = true;
		}
		else if (m.mCombo >= 0)
		{
			theAdditive = Color(aPulse, aPulse, 0, 255);
			theUseAdditive = true;
		}
		if (m.mUnderground) theColor.mAlpha = 0;
		else if (m.mInvisible) theColor.mAlpha = std::min(theColor.mAlpha, RevealedByPlantern(z) ? 150 : 45);
	}

	void ZombieDraw(Zombie* z, Graphics* g)
	{
		if (!InPlay() || !z->IsOnBoard() || gApp->mGameMode == GAMEMODE_CHALLENGE_INVISIGHOUL) return;
		const ZombieModState& m = z->mMod;
		if (!m.mInitialized || z->IsDeadOrDying()) return;
		float s = z->mScaleZombie;
		float aCenterX = 30.0f + 32.0f * s;
		float aTop = 120.0f - 128.0f * s - z->mAltitude;
		if (z->mZombieType == ZOMBIE_GARGANTUAR || z->mZombieType == ZOMBIE_REDEYE_GARGANTUAR) { aTop -= 40.0f * s; aCenterX += 10.0f * s; }
		if (z->mZombieType == ZOMBIE_ZAMBONI || z->mZombieType == ZOMBIE_CATAPULT) { aTop += 10.0f; aCenterX += 30.0f; }

		if (m.mUnderground)
		{
			g->SetColor(Color(110, 80, 50, 200));
			g->FillRect(static_cast<int>(aCenterX - 22), 108, 44, 8);
			g->SetColor(Color(80, 55, 35, 220));
			g->FillRect(static_cast<int>(aCenterX - 14), 104, 28, 5);
			return;
		}
		if (m.mInvisible && !RevealedByPlantern(z)) return;

		bool special = IsSpecial(z);
		int aMaxHP = z->mBodyMaxHealth + z->mHelmMaxHealth + z->mShieldMaxHealth + z->mFlyingMaxHealth;
		int aHP = z->mBodyHealth + z->mHelmHealth + z->mShieldHealth + z->mFlyingHealth;
		bool damaged = aHP < aMaxHP;
		if (On(OPT_V_HP_BARS) && (special || damaged) && m.mBoss < 0 && aMaxHP > 0)
		{
			int w = special ? 46 : 36;
			int x = static_cast<int>(aCenterX - w / 2.0f), y = static_cast<int>(aTop);
			float fr = std::clamp(static_cast<float>(aHP) / aMaxHP, 0.0f, 1.0f);
			g->SetColor(Color(0, 0, 0, 170));
			g->FillRect(x - 1, y - 1, w + 2, 6);
			g->SetColor(fr > 0.5f ? Color(90, 220, 70) : fr > 0.25f ? Color(240, 200, 40) : Color(230, 60, 40));
			g->FillRect(x, y, static_cast<int>(w * fr), 4);
			if (m.mShieldMax > 0 && m.mShieldHP > 0)
			{
				g->SetColor(Color(120, 190, 255));
				g->FillRect(x, y - 4, static_cast<int>(w * static_cast<float>(m.mShieldHP) / m.mShieldMax), 2);
			}
		}
		if (On(OPT_V_ICONS) && special && FONT_PICO129)
		{
			g->SetFont(FONT_PICO129);
			std::string aTags;
			if (m.mClass >= 0) aTags += gModClasses[m.mClass].mShort;
			for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
				if (m.mMutations & (1 << i)) { if (!aTags.empty()) aTags += ' '; aTags += gModMutations[i].mShort; }
			std::string aName = m.mBoss >= 0 ? std::string() : (m.mVariant >= 0 ? std::string(gModVariants[m.mVariant].mName) : std::string());
			if (m.mCombo >= 0) aName = gModCombos[m.mCombo].mName;
			if (m.mElite && aName.empty()) aName = "Glowing";
			int y = static_cast<int>(aTop) - 4;
			if (!aTags.empty())
			{
				int tw = FONT_PICO129->StringWidth(aTags);
				g->SetColor(Color(0, 0, 0, 150));
				g->FillRect(static_cast<int>(aCenterX) - tw / 2 - 2, y - 9, tw + 4, 10);
				g->SetColor(Color(255, 230, 160));
				g->DrawString(aTags, static_cast<int>(aCenterX) - tw / 2, y);
				y -= 11;
			}
			if (!aName.empty())
			{
				int tw = FONT_PICO129->StringWidth(aName);
				Color c = m.mCombo >= 0 ? Color(255, 215, 60) : m.mVariant >= 0 ? Color(gModVariants[m.mVariant].mR, gModVariants[m.mVariant].mG, gModVariants[m.mVariant].mB) : Color(140, 255, 140);
				g->SetColor(Color(0, 0, 0, 150));
				g->FillRect(static_cast<int>(aCenterX) - tw / 2 - 2, y - 9, tw + 4, 10);
				g->SetColor(c);
				g->DrawString(aName, static_cast<int>(aCenterX) - tw / 2, y);
			}
		}
		if (m.mShieldHP > 0 && On(OPT_V_STATUS) && !On(OPT_V_LOW_FX))
		{
			int pulse = 40 + static_cast<int>(25 * std::sin(z->mZombieAge * 0.1f));
			g->SetColor(Color(120, 190, 255, pulse));
			g->FillRect(static_cast<int>(aCenterX - 30 * s), static_cast<int>(aTop + 8), static_cast<int>(60 * s), static_cast<int>(110 * s));
		}
	}

	bool ZombieReachedHouse(Zombie* z)
	{
		if (!InPlay()) return false;
		if (On(OPT_G_NO_LOSE) || IsMode(MODE_SANDBOX))
		{
			AddFloatingText(60, z->mPosY + 40, "SAVED!", 255, 120, 120, 1.0f);
			return true;   // caller removes the zombie instead of ending the game
		}
		return false;
	}

	void ZombieDropLoot(Zombie* z)
	{
		OnDeath(z);
	}

	// called by the projectile system right before a shot's TakeDamage
	void MarkShot() { sShotInProgress = true; }
}
