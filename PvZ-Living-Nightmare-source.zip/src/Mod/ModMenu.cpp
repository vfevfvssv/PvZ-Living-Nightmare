// PvZ Living Nightmare - in-game mod menu: expandable option categories, encyclopedias and statistics.
#include "ModInternal.h"
#include "widget/Widget.h"
#include "widget/WidgetManager.h"

using namespace ModInt;

namespace
{
	constexpr int PANEL_X = 14, PANEL_Y = 8, PANEL_W = 772, PANEL_H = 584;
	constexpr int LIST_X = 26, LIST_Y = 82, LIST_W = 748, LIST_H = 452;
	constexpr int ROW_H = 38, HEAD_H = 36;
	constexpr int CTRL_X = 470;

	const char* const kTabNames[4] = { "Options", "Zombiepedia", "Plantpedia", "Statistics" };

	const char* const kBaseWeakness[] = {
		"Any plant; slow and weak.", "Same as a basic zombie; leads huge waves.", "Cone absorbs ~370 damage: use Melon-pult or Fume-shroom.",
		"Tall-nut stops the vault; Spikeweed.", "Magnet-shroom steals the bucket.", "Destroy the paper fast; it enrages when lost.",
		"Lobbed shots and Fume-shroom ignore the door; Magnet-shroom.", "Magnet-shroom removes the helmet; Squash.",
		"Kill quickly before backups rise; Jalapeno lane clear.", "Tangle Kelp; it is weak once out of the water.",
		"Can only be hit when surfacing; Tangle Kelp.", "Spikeweed pops it instantly; Jalapeno.", "Tall-nut stops the jump; Tangle Kelp.",
		"Magnet-shroom steals the box before it explodes.", "Cactus and Blover.", "Split Pea and Starfruit hit backwards; Magnet-shroom.",
		"Tall-nut and Magnet-shroom stop the bounce.", "Fast damage: it runs away and drops diamonds.", "Umbrella Leaf blocks the drop.",
		"Magnet-shroom takes the ladder.", "Umbrella Leaf; Spikeweed destroys it.", "Doom-shroom, Cob Cannon, Squash + Jalapeno.",
		"Weak alone; kill before it lands deep in your rows.", "Out-range it with lobbed plants.", "Lobbed and splash damage.",
		"Ice it and burn the lane.", "Gatling-heavy: use Squash or Chomper.", "Squash it first or it squashes you.",
		"Explosives and piercing shots.", "Two Doom-shrooms or Cob Cannons."
	};
	static_assert(sizeof(kBaseWeakness) / sizeof(kBaseWeakness[0]) == 30, "one weakness per spawnable zombie");

	_Font* FontS() { return FONT_PICO129 ? FONT_PICO129 : FONT_DWARVENTODCRAFT12; }
	_Font* FontM() { return FONT_DWARVENTODCRAFT15 ? FONT_DWARVENTODCRAFT15 : FontS(); }
	_Font* FontL() { return FONT_HOUSEOFTERROR20 ? FONT_HOUSEOFTERROR20 : FontM(); }

	void Text(Graphics* g, _Font* f, const std::string& s, int x, int y, Color c, int theAlign = 0)
	{
		if (!f) return;
		g->SetFont(f);
		int w = f->StringWidth(s);
		if (theAlign == 1) x -= w / 2;
		if (theAlign == 2) x -= w;
		g->SetColor(Color(0, 0, 0, 160));
		g->DrawString(s, x + 1, y + 1);
		g->SetColor(c);
		g->DrawString(s, x, y);
	}

	int Wrap(Graphics* g, _Font* f, const std::string& s, int x, int y, int w, Color c, int theLineH = 16)
	{
		if (!f) return y;
		std::string line, word;
		std::vector<std::string> lines;
		auto flush = [&]() { lines.push_back(line); line.clear(); };
		for (size_t i = 0; i <= s.size(); i++)
		{
			char ch = i < s.size() ? s[i] : ' ';
			if (ch == '\n') { if (!word.empty()) { line += (line.empty() ? "" : " ") + word; word.clear(); } flush(); continue; }
			if (ch == ' ')
			{
				if (word.empty()) continue;
				std::string cand = line.empty() ? word : line + " " + word;
				if (f->StringWidth(cand) > w && !line.empty()) { flush(); line = word; }
				else line = cand;
				word.clear();
			}
			else word += ch;
		}
		if (!line.empty()) flush();
		for (const std::string& l : lines) { Text(g, f, l, x, y, c); y += theLineH; }
		return y;
	}

	void Button(Graphics* g, const Rect& r, const std::string& s, Color fill, Color txt = Color(255, 240, 200))
	{
		g->SetColor(Color(0, 0, 0, 140));
		g->FillRect(r.mX + 2, r.mY + 2, r.mWidth, r.mHeight);
		g->SetColor(fill);
		g->FillRect(r);
		g->SetColor(Color(255, 255, 255, 60));
		g->FillRect(r.mX, r.mY, r.mWidth, 2);
		g->SetColor(Color(20, 12, 4));
		g->DrawRect(r.mX, r.mY, r.mWidth - 1, r.mHeight - 1);
		_Font* f = FontM();
		if (f) Text(g, f, s, r.mX + r.mWidth / 2, r.mY + r.mHeight / 2 + f->GetAscent() / 2 - 1, txt, 1);
	}

	std::string AbilityList(uint32_t ab)
	{
		std::string s;
		for (int i = 0; i < NUM_MOD_ABILITIES; i++)
			if (ab & (1u << i)) s += std::format("- {}: {}\n", gModAbilityInfo[i].mName, gModAbilityInfo[i].mDesc);
		return s.empty() ? "- none\n" : s;
	}

	struct Row { int mType; int mCat; int mOpt; int mY; int mH; };
	struct Entry { int mKind; int mIdx; };   // kind: -1 header, 0 base, 1 variant, 2 class, 3 mutation, 4 combo, 5 boss / plants: 10 plant, 11 trait, 12 combo, 13 levels

	std::vector<bool> sExpanded(NUM_MOD_CATEGORIES, false);
	int sTab = 0;
}

class ModMenuWidget : public Widget
{
public:
	float mScroll = 0.0f, mListScroll = 0.0f;
	int   mContentH = 0, mListContentH = 0;
	bool  mPressed = false, mMoved = false, mDragList = false;
	int   mPressX = 0, mPressY = 0, mLastY = 0;
	int   mSliderOpt = -1;
	int   mSelOpt = -1;
	std::string mStatus;
	int   mStatusTimer = 0;
	int   mKeypadOpt = -1;
	std::string mKeypad;
	int   mEntryZ = 1, mEntryP = 1;
	int   mConfirmReset = 0;

	ModMenuWidget() { mHasAlpha = true; }

	void Update() override
	{
		Widget::Update();
		if (mStatusTimer > 0) mStatusTimer--;
		if (mConfirmReset > 0) mConfirmReset--;
		MarkDirty();
	}

	// ---------- rows of the option list
	std::vector<Row> BuildRows()
	{
		std::vector<Row> rows;
		int y = 0;
		for (int c = 0; c < NUM_MOD_CATEGORIES; c++)
		{
			rows.push_back({ 0, c, -1, y, HEAD_H });
			y += HEAD_H + 4;
			if (!sExpanded[c]) continue;
			for (int o = 0; o < NUM_MOD_OPTS; o++)
			{
				if (ModConfig::Def(o).mCategory != c) continue;
				rows.push_back({ 1, c, o, y, ROW_H });
				y += ROW_H + 2;
			}
			y += 6;
		}
		mContentH = y;
		return rows;
	}

	static int CountInCategory(int c)
	{
		int n = 0;
		for (int o = 0; o < NUM_MOD_OPTS; o++) if (ModConfig::Def(o).mCategory == c && ModConfig::Def(o).mIsFunction) n++;
		return n;
	}

	void ClampScroll(float& s, int contentH, int viewH) { s = std::clamp(s, 0.0f, static_cast<float>(std::max(0, contentH - viewH))); }

	void SetStatus(const std::string& s) { mStatus = s; mStatusTimer = 240; }

	// ---------- drawing
	void Draw(Graphics* g) override
	{
		g->SetColor(Color(0, 0, 0, 170));
		g->FillRect(0, 0, mWidth, mHeight);
		g->SetColor(Color(48, 32, 18, 245));
		g->FillRect(PANEL_X, PANEL_Y, PANEL_W, PANEL_H);
		g->SetColor(Color(120, 85, 40));
		g->DrawRect(PANEL_X, PANEL_Y, PANEL_W - 1, PANEL_H - 1);
		g->DrawRect(PANEL_X + 3, PANEL_Y + 3, PANEL_W - 7, PANEL_H - 7);

		const char* aTitle = "PVZ LIVING NIGHTMARE";
		Text(g, FontL(), aTitle, PANEL_X + 18, PANEL_Y + 30, Color(200, 60, 60));
		int aStatsX = std::max(PANEL_X + 300, PANEL_X + 18 + FontL()->StringWidth(aTitle) + 24);
		Text(g, FontS(), std::format("{} functions  |  {} variants  |  {} bosses", ModConfig::CountFunctions(), static_cast<int>(NUM_MOD_VARIANTS), static_cast<int>(NUM_MOD_BOSSES)),
			aStatsX, PANEL_Y + 26, Color(230, 220, 180));
		Button(g, Rect(PANEL_X + PANEL_W - 50, PANEL_Y + 10, 38, 30), "X", Color(150, 40, 30));
		for (int i = 0; i < 4; i++)
			Button(g, TabRect(i), kTabNames[i], i == sTab ? Color(70, 140, 50) : Color(90, 62, 30));

		switch (sTab)
		{
		case 0: DrawOptions(g); break;
		case 1: DrawZombiepedia(g); break;
		case 2: DrawPlantpedia(g); break;
		default: DrawStats(g); break;
		}
		DrawFooter(g);
		if (mKeypadOpt >= 0) DrawKeypad(g);
	}

	Rect TabRect(int i) { return Rect(PANEL_X + 14 + i * 186, PANEL_Y + 40, 178, 30); }

	void DrawScrollbar(Graphics* g, int x, int y, int h, float scroll, int contentH)
	{
		if (contentH <= h) return;
		g->SetColor(Color(0, 0, 0, 120));
		g->FillRect(x, y, 8, h);
		int bh = std::max(30, h * h / contentH);
		int by = y + static_cast<int>((h - bh) * scroll / std::max(1, contentH - h));
		g->SetColor(Color(200, 160, 90));
		g->FillRect(x, by, 8, bh);
	}

	void DrawOptions(Graphics* g)
	{
		std::vector<Row> rows = BuildRows();
		ClampScroll(mScroll, mContentH, LIST_H);
		g->PushState();
		g->ClipRect(LIST_X, LIST_Y, LIST_W, LIST_H);
		for (const Row& r : rows)
		{
			int y = LIST_Y + r.mY - static_cast<int>(mScroll);
			if (y + r.mH < LIST_Y || y > LIST_Y + LIST_H) continue;
			if (r.mType == 0)
			{
				bool ex = sExpanded[r.mCat];
				g->SetColor(ex ? Color(92, 130, 52) : Color(100, 70, 34));
				g->FillRect(LIST_X, y, LIST_W - 14, r.mH);
				g->SetColor(Color(20, 12, 4));
				g->DrawRect(LIST_X, y, LIST_W - 15, r.mH - 1);
				Text(g, FontM(), std::string(ex ? "[-]  " : "[+]  ") + gModCategoryNames[r.mCat], LIST_X + 12, y + 24, Color(255, 240, 190));
				Text(g, FontS(), std::format("{} functions", CountInCategory(r.mCat)), LIST_X + LIST_W - 30, y + 22, Color(230, 230, 200), 2);
				continue;
			}
			DrawOptionRow(g, r.mOpt, y);
		}
		g->PopState();
		DrawScrollbar(g, LIST_X + LIST_W - 10, LIST_Y, LIST_H, mScroll, mContentH);
	}

	Rect CtrlMinus(int y) { return Rect(CTRL_X, y + 5, 34, 28); }
	Rect CtrlPlus(int y) { return Rect(CTRL_X + 220, y + 5, 34, 28); }
	Rect CtrlBar(int y) { return Rect(CTRL_X + 40, y + 5, 174, 28); }
	Rect CtrlToggle(int y) { return Rect(CTRL_X + 150, y + 5, 104, 28); }
	Rect CtrlAction(int y) { return Rect(CTRL_X + 124, y + 5, 130, 28); }

	void DrawOptionRow(Graphics* g, int o, int y)
	{
		const ModOptionDef& d = ModConfig::Def(o);
		g->SetColor(o == mSelOpt ? Color(84, 60, 30, 230) : Color(66, 46, 24, 220));
		g->FillRect(LIST_X + 10, y, LIST_W - 24, ROW_H);
		Text(g, FontM(), d.mLabel, LIST_X + 22, y + 25, d.mIsFunction ? Color(255, 250, 230) : Color(210, 200, 170));
		float v = ModConfig::Get(o);
		switch (d.mType)
		{
		case ModOptType::Toggle:
		{
			bool on = v > 0.5f;
			Button(g, CtrlToggle(y), on ? "ON" : "OFF", on ? Color(50, 150, 50) : Color(140, 50, 40));
			break;
		}
		case ModOptType::Slider:
		case ModOptType::Int:
		{
			Button(g, CtrlMinus(y), "-", Color(90, 62, 30));
			Button(g, CtrlPlus(y), "+", Color(90, 62, 30));
			Rect bar = CtrlBar(y);
			g->SetColor(Color(25, 18, 10));
			g->FillRect(bar);
			if (d.mType == ModOptType::Slider && d.mMax > d.mMin)
			{
				float f = (v - d.mMin) / (d.mMax - d.mMin);
				g->SetColor(Color(80, 150, 60));
				g->FillRect(bar.mX + 2, bar.mY + 2, static_cast<int>((bar.mWidth - 4) * f), bar.mHeight - 4);
			}
			else
			{
				g->SetColor(Color(60, 60, 90));
				g->DrawRect(bar.mX + 2, bar.mY + 2, bar.mWidth - 5, bar.mHeight - 5);
			}
			Text(g, FontM(), ModConfig::FormatValue(o), bar.mX + bar.mWidth / 2, bar.mY + 20, Color(255, 255, 220), 1);
			break;
		}
		case ModOptType::Select:
		{
			Button(g, CtrlMinus(y), "<", Color(90, 62, 30));
			Button(g, CtrlPlus(y), ">", Color(90, 62, 30));
			Rect bar = CtrlBar(y);
			g->SetColor(Color(25, 18, 10));
			g->FillRect(bar);
			std::string s = ModConfig::FormatValue(o);
			_Font* f = FontM();
			if (f && f->StringWidth(s) > bar.mWidth - 6) f = FontS();
			Text(g, f, s, bar.mX + bar.mWidth / 2, bar.mY + 19, Color(255, 240, 160), 1);
			break;
		}
		case ModOptType::Action:
			Button(g, CtrlAction(y), "RUN", Color(170, 110, 30));
			break;
		}
	}

	void DrawFooter(Graphics* g)
	{
		int y = PANEL_Y + PANEL_H - 50;
		std::string s = mStatusTimer > 0 ? mStatus : (sTab == 0 && mSelOpt >= 0 ? ModConfig::Def(mSelOpt).mDesc : std::string("Tap a category to expand it. Settings are saved automatically."));
		g->SetColor(Color(0, 0, 0, 120));
		g->FillRect(PANEL_X + 12, y - 4, PANEL_W - 24, 18);
		Text(g, FontS(), s, PANEL_X + 18, y + 9, mStatusTimer > 0 ? Color(140, 255, 140) : Color(230, 220, 190));
		if (sTab == 0)
		{
			Button(g, FooterRect(0), mConfirmReset > 0 ? "Tap to confirm" : "Reset all", Color(150, 50, 40));
			Button(g, FooterRect(1), "Expand all", Color(90, 62, 30));
			Button(g, FooterRect(2), "Collapse all", Color(90, 62, 30));
			Button(g, FooterRect(3), "Save", Color(60, 110, 160));
		}
		Button(g, FooterRect(4), "Close", Color(70, 140, 50));
	}

	Rect FooterRect(int i)
	{
		int y = PANEL_Y + PANEL_H - 32;
		if (i == 4) return Rect(PANEL_X + PANEL_W - 142, y, 128, 26);
		return Rect(PANEL_X + 14 + i * 142, y, 134, 26);
	}

	// ---------- encyclopedias
	std::vector<Entry> ZombieEntries()
	{
		std::vector<Entry> v;
		v.push_back({ -1, 0 });
		for (int i = 0; i < NUM_MOD_SPAWNABLE_ZOMBIES; i++) v.push_back({ 0, i });
		v.push_back({ -1, 1 });
		for (int i = 0; i < NUM_MOD_VARIANTS; i++) v.push_back({ 1, i });
		v.push_back({ -1, 2 });
		for (int i = 0; i < NUM_MOD_CLASSES; i++) v.push_back({ 2, i });
		v.push_back({ -1, 3 });
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++) v.push_back({ 3, i });
		v.push_back({ -1, 4 });
		for (int i = 0; i < NUM_MOD_COMBOS; i++) v.push_back({ 4, i });
		v.push_back({ -1, 5 });
		for (int i = 0; i < NUM_MOD_BOSSES; i++) v.push_back({ 5, i });
		return v;
	}

	std::vector<Entry> PlantEntries()
	{
		std::vector<Entry> v;
		v.push_back({ -1, 10 });
		for (int i = 0; i < NUM_MOD_PLANT_ABILITIES; i++) v.push_back({ 10, i });
		v.push_back({ -1, 11 });
		for (int i = 0; i < NUM_MOD_TRAITS; i++) v.push_back({ 11, i });
		v.push_back({ -1, 12 });
		for (int i = 0; i < NUM_MOD_PLANT_COMBOS; i++) v.push_back({ 12, i });
		v.push_back({ -1, 13 });
		v.push_back({ 13, 0 });
		return v;
	}

	std::string EntryName(const Entry& e)
	{
		static const char* const kHeads[] = { "BASE ZOMBIES", "VARIANTS", "CLASSES", "MUTATIONS", "SPECIAL COMBOS", "BOSSES", "", "", "", "", "PLANT ABILITIES", "RARE TRAITS", "COMBINATIONS", "LEVELS" };
		switch (e.mKind)
		{
		case -1: return kHeads[e.mIdx];
		case 0: return gModSpawnableZombieNames[e.mIdx];
		case 1: return (VariantUnlocked(e.mIdx) || VariantDiscovered(e.mIdx)) ? gModVariants[e.mIdx].mName : "??? (locked)";
		case 2: return gModClasses[e.mIdx].mName;
		case 3: return gModMutations[e.mIdx].mName;
		case 4: return gModCombos[e.mIdx].mName;
		case 5: return gModBosses[e.mIdx].mName;
		case 10: return gModPlantAbilities[e.mIdx].mPlant;
		case 11: return gModTraits[e.mIdx].mName;
		case 12: return gModPlantCombos[e.mIdx].mName;
		default: return "Experience & evolution";
		}
	}

	void DrawList(Graphics* g, const std::vector<Entry>& v, int sel)
	{
		const int x = LIST_X, w = 250, h = LIST_H, rh = 26;
		mListContentH = static_cast<int>(v.size()) * rh;
		ClampScroll(mListScroll, mListContentH, h);
		g->SetColor(Color(30, 20, 10, 200));
		g->FillRect(x, LIST_Y, w, h);
		g->PushState();
		g->ClipRect(x, LIST_Y, w, h);
		for (size_t i = 0; i < v.size(); i++)
		{
			int y = LIST_Y + static_cast<int>(i) * rh - static_cast<int>(mListScroll);
			if (y + rh < LIST_Y || y > LIST_Y + h) continue;
			if (v[i].mKind == -1)
			{
				g->SetColor(Color(92, 130, 52));
				g->FillRect(x, y + 1, w - 10, rh - 2);
				Text(g, FontS(), EntryName(v[i]), x + 8, y + 17, Color(255, 250, 210));
				continue;
			}
			if (static_cast<int>(i) == sel) { g->SetColor(Color(130, 95, 40)); g->FillRect(x, y + 1, w - 10, rh - 2); }
			Color c = Color(240, 230, 200);
			if (v[i].mKind == 1) { const ModVariantDef& d = gModVariants[v[i].mIdx]; c = (VariantUnlocked(v[i].mIdx) || VariantDiscovered(v[i].mIdx)) ? Color(d.mR, d.mG, d.mB) : Color(140, 140, 140); }
			if (v[i].mKind == 5) c = Color(gModBosses[v[i].mIdx].mR, gModBosses[v[i].mIdx].mG, gModBosses[v[i].mIdx].mB);
			Text(g, FontM(), EntryName(v[i]), x + 14, y + 19, c);
		}
		g->PopState();
		DrawScrollbar(g, x + w - 9, LIST_Y, h, mListScroll, mListContentH);
	}

	void DrawZombiepedia(Graphics* g)
	{
		std::vector<Entry> v = ZombieEntries();
		mEntryZ = std::clamp(mEntryZ, 0, static_cast<int>(v.size()) - 1);
		DrawList(g, v, mEntryZ);
		const Entry& e = v[mEntryZ];
		int x = LIST_X + 266, y = LIST_Y + 22, w = LIST_W - 276;
		g->SetColor(Color(30, 20, 10, 200));
		g->FillRect(x - 8, LIST_Y, w + 16, LIST_H);
		Text(g, FontL(), EntryName(e), x, y, Color(255, 240, 180));
		y += 26;
		std::string s;
		switch (e.mKind)
		{
		case 0:
		{
			ZombieType t = gModSpawnableZombieTypes[e.mIdx];
			s += std::format("Weak point: {}\n\nVariants of this zombie:\n", kBaseWeakness[e.mIdx]);
			int n = 0;
			for (int i = 0; i < NUM_MOD_VARIANTS; i++)
				if (gModVariants[i].mBase == t) { s += std::format("- {} (kills: {})\n", (VariantUnlocked(i) || VariantDiscovered(i)) ? gModVariants[i].mName : "???", gP.mVariantKills[i]); n++; }
			if (!n) s += "- none\n";
			break;
		}
		case 1:
		{
			const ModVariantDef& d = gModVariants[e.mIdx];
			bool un = VariantUnlocked(e.mIdx);
			if (!un && !VariantDiscovered(e.mIdx))
			{
				s = std::format("Locked. Unlocks after {} total zombie kills (you have {}).\nOr enable 'Unlock all variants' in Difficulty.", d.mTier >= 2 ? 200 : 50, gP.mTotalKills);
				break;
			}
			s += std::format("Based on: {}   Tier: {}{}\n", ModZombieTypeName(d.mBase), d.mTier + 1, un ? "" : "  (locked - seen before)");
			s += std::format("Health x{:.2g}   Speed x{:.2g}   Bite x{:.2g}   Size x{:.2g}\n\n", d.mHealth, d.mSpeed, d.mBite, d.mScale);
			s += std::string(d.mDesc) + "\n\nAbilities:\n" + AbilityList(d.mAbilities);
			s += std::format("\nWeak point: {}\n\nDefeated: {}   Encountered: {}", d.mWeakness, gP.mVariantKills[e.mIdx], gP.mVariantSeen[e.mIdx]);
			break;
		}
		case 2:
		{
			const ModClassDef& d = gModClasses[e.mIdx];
			s += std::format("{}\n\nHealth x{:.2g}   Speed x{:.2g}   Bite x{:.2g}   Damage taken x{:.2g}\nPower setting: x{:.2g}   Enabled: {}\n\n", d.mDesc, d.mHealth, d.mSpeed, d.mBite, d.mDefense,
				ClassPower(e.mIdx), On(OPT_CL_ON_0 + e.mIdx) ? "yes" : "no");
			s += "Abilities granted:\n" + AbilityList(d.mGrants);
			s += "\nCooperation: Support speeds up Assassins even more; Healers heal Tanks twice as fast; Destroyers resist damage next to a Saboteur; Scouts speed up their whole lane.";
			s += std::format("\n\nDefeated: {}", gP.mClassKills[e.mIdx]);
			break;
		}
		case 3:
		{
			const ModMutationDef& d = gModMutations[e.mIdx];
			s += std::format("{}\n\nHealth x{:.2g}   Speed x{:.2g}   Size x{:.2g}\nProbability weight: {:g} (rarer = lower)   Enabled: {}\n\nAbilities granted:\n", d.mDesc, d.mHealth, d.mSpeed, d.mScale,
				ModConfig::Get(OPT_MUT_W_0 + e.mIdx), On(OPT_MUT_ON_0 + e.mIdx) ? "yes" : "no");
			s += AbilityList(d.mGrants);
			s += std::format("\nDefeated: {}", gP.mMutationKills[e.mIdx]);
			break;
		}
		case 4:
		{
			const ModComboDef& d = gModCombos[e.mIdx];
			s += std::format("Requires: {} + {}\n\n{}\n\nHealth x{:.2g}   Speed x{:.2g}\n\nExtra abilities:\n{}\nDefeated: {}", gModMutations[d.mMutA].mName, gModMutations[d.mMutB].mName,
				d.mDesc, d.mHealth, d.mSpeed, AbilityList(d.mGrants), gP.mComboKills[e.mIdx]);
			break;
		}
		case 5:
		{
			const ModBossDef& d = gModBosses[e.mIdx];
			s += std::format("Body: {}   Health: {}   Speed x{:.2g}\n\n{}\n\nPhases: {}\n\nAbilities:\n{}\nHow to win: big explosions are capped at 600 damage, so mix steady damage with crowd control. Each phase unlocks new attacks at 66% and 33% health.\n\nDefeated: {}   Encountered: {}",
				ModZombieTypeName(d.mBase), static_cast<int>(d.mHealth * Opt(OPT_B_HP)), d.mSpeed, d.mDesc, d.mPhases, AbilityList(d.mAbilities), gP.mBossKills[e.mIdx], gP.mBossSeen[e.mIdx]);
			break;
		}
		default:
			s = "Select an entry on the left.";
		}
		Wrap(g, FontM(), s, x, y, w, Color(240, 235, 210), 17);
	}

	Rect BranchRect(int i) { return Rect(LIST_X + 266 + i * 92, LIST_Y + LIST_H - 44, 86, 30); }
	Rect AbilityToggleRect() { return Rect(LIST_X + 266 + 290, LIST_Y + LIST_H - 44, 170, 30); }

	void DrawPlantpedia(Graphics* g)
	{
		std::vector<Entry> v = PlantEntries();
		mEntryP = std::clamp(mEntryP, 0, static_cast<int>(v.size()) - 1);
		DrawList(g, v, mEntryP);
		const Entry& e = v[mEntryP];
		int x = LIST_X + 266, y = LIST_Y + 22, w = LIST_W - 276;
		g->SetColor(Color(30, 20, 10, 200));
		g->FillRect(x - 8, LIST_Y, w + 16, LIST_H);
		Text(g, FontL(), EntryName(e), x, y, Color(200, 255, 170));
		y += 26;
		std::string s;
		if (e.mKind == 10)
		{
			const ModPlantAbilityDef& d = gModPlantAbilities[e.mIdx];
			int xp = gP.mPlantXP[d.mSeed];
			bool unlocked = xp >= d.mUnlockXP || On(OPT_PA_UNLOCK_UPGRADES);
			s += std::format("New ability: {}\n\nUpgrade branch A: {}\nUpgrade branch B: {}\n\n", d.mAbility, d.mBranchA, d.mBranchB);
			s += std::format("Total experience: {} / {} {}\n", xp, d.mUnlockXP, unlocked ? "(branches unlocked)" : "(earn XP with this plant to unlock branches)");
			s += "Experience comes from damage dealt, sun produced and bites absorbed. Each plant on the lawn also levels up from 1 to 5: +10% damage, +8% fire rate and +10% health per level. Level 5 is the evolved form (golden, bigger, +15% damage).";
			Wrap(g, FontM(), s, x, y, w, Color(240, 235, 210), 17);
			int br = ModConfig::GetInt(OPT_PBR_0 + e.mIdx);
			const char* names[3] = { "None", "A", "B" };
			for (int i = 0; i < 3; i++)
				Button(g, BranchRect(i), names[i], br == i ? Color(70, 140, 50) : (unlocked || i == 0 ? Color(90, 62, 30) : Color(70, 70, 70)));
			bool on = On(OPT_PAB_0 + e.mIdx);
			Button(g, AbilityToggleRect(), on ? "Ability: ON" : "Ability: OFF", on ? Color(50, 150, 50) : Color(140, 50, 40));
			return;
		}
		if (e.mKind == 11) s = std::format("{}\n\n20% of planted plants receive a random rare trait (can be disabled in Plant Abilities). The trait name is shown in the plant's corner.", gModTraits[e.mIdx].mDesc);
		else if (e.mKind == 12) s = std::format("{}\n\nCombinations are recalculated every second. Disable them with 'Plant combinations'.", gModPlantCombos[e.mIdx].mDesc);
		else if (e.mKind == 13) s = "Levels: 1 -> 2 at 120 XP, 3 at 400, 4 at 900, 5 (evolved) at 1800.\nEvery level: +10% damage, +8% fire rate, +10% max health and a full heal.\nLevel 3+: +5% critical chance.\nLevel 5: golden evolved form, +15% damage, bigger size.\n\nPlant Food (from glowing zombies or bosses): tap PF, then a plant. Shooters fire 5x faster for 3 seconds, sun plants make 3-6 sun, nuts gain armor and a shield, other plants become invulnerable briefly.";
		else s = "Select an entry on the left.";
		Wrap(g, FontM(), s, x, y, w, Color(240, 235, 210), 17);
	}

	void DrawStats(Graphics* g)
	{
		int x = LIST_X + 10, y = LIST_Y + 16;
		g->SetColor(Color(30, 20, 10, 200));
		g->FillRect(LIST_X, LIST_Y, LIST_W, LIST_H);
		int discovered = 0, unlocked = 0;
		for (int i = 0; i < NUM_MOD_VARIANTS; i++) { if (VariantDiscovered(i)) discovered++; if (VariantUnlocked(i)) unlocked++; }
		int bosses = 0; for (int i = 0; i < NUM_MOD_BOSSES; i++) bosses += gP.mBossKills[i];
		std::vector<std::string> L = {
			std::format("Total zombies defeated: {}", gP.mTotalKills),
			std::format("Variants discovered: {}/{}  (unlocked {})", discovered, NUM_MOD_VARIANTS, unlocked),
			std::format("Bosses defeated: {}", bosses),
			std::format("Levels won / lost: {} / {}", gP.mLevelsWon, gP.mLevelsLost),
			std::format("Most waves in one level: {}", gP.mMaxWave),
			std::format("Best endless cycle: {}", gP.mMaxEndlessCycle),
			std::format("Plant Food used: {}", gP.mPlantFoodUsed),
			std::format("Plants evolved: {}", gP.mEvolvedPlants),
			std::format("Lightning strikes: {}", gP.mLightningStrikes),
			std::format("Biggest single hit: {}", gP.mMaxDamageHit),
		};
		for (const std::string& l : L) { Text(g, FontM(), l, x, y, Color(240, 235, 210)); y += 20; }
		y += 6;
		Text(g, FontM(), "Bosses:", x, y, Color(255, 220, 140)); y += 18;
		for (int i = 0; i < NUM_MOD_BOSSES; i++)
		{
			Text(g, FontS(), std::format("{}: {} defeated / {} met", gModBosses[i].mName, gP.mBossKills[i], gP.mBossSeen[i]), x + 10, y, Color(gModBosses[i].mR, gModBosses[i].mG, gModBosses[i].mB));
			y += 13;
		}
		int x2 = LIST_X + 390, y2 = LIST_Y + 16;
		Text(g, FontM(), "Hardest waves survived", x2, y2, Color(255, 200, 120)); y2 += 20;
		if (gP.mHardestWaves.empty()) { Text(g, FontS(), "No waves recorded yet.", x2, y2, Color(200, 200, 200)); y2 += 14; }
		for (size_t i = 0; i < gP.mHardestWaves.size(); i++)
		{
			const WaveRecord& r = gP.mHardestWaves[i];
			std::string where = r.mLevel < 1000 ? std::format("Adventure {}-{}", (r.mLevel - 1) / 10 + 1, (r.mLevel - 1) % 10 + 1) : std::format("Mode #{}", r.mLevel - 1000);
			Text(g, FontS(), std::format("{:2}. score {}  wave {}  {}  {} zombies ({} special){}", i + 1, r.mScore, r.mWave, where, r.mZombies, r.mSpecials,
				r.mMode > 0 && r.mMode < NUM_MOD_GAME_MODES ? std::format("  [{}]", gModGameModes[r.mMode].mName) : std::string()), x2, y2, Color(240, 235, 210));
			y2 += 14;
		}
		y2 += 10;
		Text(g, FontM(), "Weather seen", x2, y2, Color(200, 230, 255)); y2 += 18;
		for (int i = 1; i < NUM_MOD_WEATHERS; i++) { Text(g, FontS(), std::format("{}: {}", gModWeathers[i].mName, gP.mWeatherSeen[i]), x2 + 10, y2, Color(220, 230, 240)); y2 += 13; }
		for (int i = 1; i < NUM_MOD_EVENTS; i++) { Text(g, FontS(), std::format("{} (rare): {}", gModEvents[i].mName, gP.mEventsSeen[i]), x2 + 10, y2, Color(255, 170, 255)); y2 += 13; }
	}

	// ---------- keypad (numeric fields)
	Rect KeypadRect() { return Rect(250, 130, 300, 340); }
	Rect KeyRect(int i)
	{
		Rect k = KeypadRect();
		int c = i % 3, r = i / 3;
		return Rect(k.mX + 20 + c * 90, k.mY + 80 + r * 52, 80, 44);
	}
	void DrawKeypad(Graphics* g)
	{
		g->SetColor(Color(0, 0, 0, 150));
		g->FillRect(0, 0, mWidth, mHeight);
		Rect k = KeypadRect();
		g->SetColor(Color(48, 32, 18, 250));
		g->FillRect(k);
		g->SetColor(Color(200, 160, 90));
		g->DrawRect(k.mX, k.mY, k.mWidth - 1, k.mHeight - 1);
		const ModOptionDef& d = ModConfig::Def(mKeypadOpt);
		Text(g, FontS(), d.mLabel, k.mX + 16, k.mY + 20, Color(255, 240, 200));
		Text(g, FontS(), std::format("Range {:g} - {:g}", d.mMin, d.mMax), k.mX + 16, k.mY + 34, Color(200, 200, 180));
		g->SetColor(Color(20, 14, 8));
		g->FillRect(k.mX + 16, k.mY + 42, k.mWidth - 32, 30);
		Text(g, FontM(), mKeypad.empty() ? "0" : mKeypad, k.mX + k.mWidth - 24, k.mY + 64, Color(255, 255, 220), 2);
		const char* keys[12] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "<" };
		for (int i = 0; i < 12; i++) Button(g, KeyRect(i), keys[i], Color(90, 62, 30));
		Button(g, KeyRect(12), "OK", Color(70, 140, 50));
		Button(g, Rect(KeyRect(13).mX, KeyRect(13).mY, 170, 44), "Cancel", Color(150, 50, 40));
	}
	void KeypadClick(int x, int y)
	{
		for (int i = 0; i < 14; i++)
		{
			Rect r = i == 13 ? Rect(KeyRect(13).mX, KeyRect(13).mY, 170, 44) : KeyRect(i);
			if (!r.Contains(x, y)) continue;
			gApp->PlaySample(SOUND_BUTTONCLICK);
			if (i < 9 || i == 10) { if (mKeypad.size() < 5) mKeypad += (i == 10 ? '0' : static_cast<char>('1' + i)); }
			else if (i == 9) mKeypad.clear();
			else if (i == 11) { if (!mKeypad.empty()) mKeypad.pop_back(); }
			else if (i == 12)
			{
				ModConfig::Set(mKeypadOpt, static_cast<float>(std::atoi(mKeypad.c_str())));
				SetStatus(std::format("{} = {}", ModConfig::Def(mKeypadOpt).mLabel, ModConfig::FormatValue(mKeypadOpt)));
				mKeypadOpt = -1;
			}
			else mKeypadOpt = -1;
			return;
		}
	}

	// ---------- input
	void MouseDown(int x, int y, int theClickCount) override
	{
		mPressed = true; mMoved = false; mPressX = x; mPressY = y; mLastY = y; mSliderOpt = -1;
		mDragList = false;
		if (mKeypadOpt >= 0) return;
		if (sTab == 0 && Rect(LIST_X, LIST_Y, LIST_W, LIST_H).Contains(x, y))
		{
			// sliders start dragging immediately
			for (const Row& r : BuildRows())
			{
				if (r.mType != 1) continue;
				int ry = LIST_Y + r.mY - static_cast<int>(mScroll);
				if (y < ry || y >= ry + r.mH) continue;
				if (ModConfig::Def(r.mOpt).mType == ModOptType::Slider && CtrlBar(ry).Contains(x, y))
				{
					mSliderOpt = r.mOpt;
					mSelOpt = r.mOpt;
					SliderSet(x, ry);
				}
				break;
			}
		}
		else if ((sTab == 1 || sTab == 2) && Rect(LIST_X, LIST_Y, 250, LIST_H).Contains(x, y))
			mDragList = true;
	}

	void SliderSet(int x, int ry)
	{
		const ModOptionDef& d = ModConfig::Def(mSliderOpt);
		Rect bar = CtrlBar(ry);
		float f = std::clamp(static_cast<float>(x - bar.mX) / bar.mWidth, 0.0f, 1.0f);
		ModConfig::Set(mSliderOpt, d.mMin + (d.mMax - d.mMin) * f);
	}

	void MouseDrag(int x, int y) override
	{
		if (!mPressed || mKeypadOpt >= 0) return;
		if (mSliderOpt >= 0)
		{
			for (const Row& r : BuildRows())
				if (r.mOpt == mSliderOpt) { SliderSet(x, LIST_Y + r.mY - static_cast<int>(mScroll)); break; }
			return;
		}
		if (std::abs(y - mPressY) > 8) mMoved = true;
		if (mMoved)
		{
			float dy = static_cast<float>(mLastY - y);
			if (mDragList) mListScroll += dy;
			else mScroll += dy;
		}
		mLastY = y;
	}

	void MouseWheel(int theDelta) override
	{
		if (sTab == 0) mScroll -= theDelta * 40.0f;
		else mListScroll -= theDelta * 40.0f;
	}

	void MouseUp(int x, int y, int theClickCount) override
	{
		bool wasSlider = mSliderOpt >= 0;
		bool click = mPressed && !mMoved && !wasSlider;
		mPressed = false;
		mSliderOpt = -1;
		if (wasSlider) { ModConfig::SaveIfDirty(); return; }
		if (!click) return;
		if (mKeypadOpt >= 0) { KeypadClick(x, y); return; }
		Click(mPressX, mPressY);
	}

	void KeyDown(KeyCode theKey) override
	{
		if (theKey == KEYCODE_ESCAPE || theKey == KEYCODE_F2)
		{
			if (mKeypadOpt >= 0) mKeypadOpt = -1;
			else ModSystem::CloseMenu();
		}
		else if (theKey == KEYCODE_UP) MouseWheel(1);
		else if (theKey == KEYCODE_DOWN) MouseWheel(-1);
	}

	void Click(int x, int y)
	{
		if (Rect(PANEL_X + PANEL_W - 50, PANEL_Y + 10, 38, 30).Contains(x, y) || FooterRect(4).Contains(x, y))
		{
			gApp->PlaySample(SOUND_BUTTONCLICK);
			ModSystem::CloseMenu();
			return;
		}
		for (int i = 0; i < 4; i++)
			if (TabRect(i).Contains(x, y)) { sTab = i; mListScroll = 0; gApp->PlaySample(SOUND_BUTTONCLICK); return; }
		if (sTab == 0)
		{
			if (FooterRect(0).Contains(x, y))
			{
				if (mConfirmReset > 0) { ModSystem::ExecuteAction(OPT_MI_RESET); SetStatus(gActionMsg); mConfirmReset = 0; }
				else mConfirmReset = 180;
				return;
			}
			if (FooterRect(1).Contains(x, y)) { for (int c = 0; c < NUM_MOD_CATEGORIES; c++) sExpanded[c] = true; return; }
			if (FooterRect(2).Contains(x, y)) { for (int c = 0; c < NUM_MOD_CATEGORIES; c++) sExpanded[c] = false; mScroll = 0; return; }
			if (FooterRect(3).Contains(x, y)) { ModSystem::ExecuteAction(OPT_MI_SAVE); SetStatus(gActionMsg); return; }
			if (Rect(LIST_X, LIST_Y, LIST_W, LIST_H).Contains(x, y)) OptionsClick(x, y);
			return;
		}
		if (sTab == 1 || sTab == 2)
		{
			if (Rect(LIST_X, LIST_Y, 250, LIST_H).Contains(x, y))
			{
				std::vector<Entry> v = sTab == 1 ? ZombieEntries() : PlantEntries();
				int i = static_cast<int>((y - LIST_Y + mListScroll) / 26);
				if (i >= 0 && i < static_cast<int>(v.size()) && v[i].mKind != -1)
				{
					(sTab == 1 ? mEntryZ : mEntryP) = i;
					gApp->PlaySample(SOUND_BUTTONCLICK);
				}
				return;
			}
			if (sTab == 2)
			{
				std::vector<Entry> v = PlantEntries();
				const Entry& e = v[std::clamp(mEntryP, 0, static_cast<int>(v.size()) - 1)];
				if (e.mKind != 10) return;
				for (int i = 0; i < 3; i++)
					if (BranchRect(i).Contains(x, y))
					{
						ModConfig::Set(OPT_PBR_0 + e.mIdx, static_cast<float>(i));
						const ModPlantAbilityDef& d = gModPlantAbilities[e.mIdx];
						bool unlocked = gP.mPlantXP[d.mSeed] >= d.mUnlockXP || On(OPT_PA_UNLOCK_UPGRADES);
						SetStatus(i == 0 ? "Upgrade removed" : unlocked ? "Upgrade selected" : "Selected - it activates once the branch is unlocked");
						gApp->PlaySample(SOUND_BUTTONCLICK);
					}
				if (AbilityToggleRect().Contains(x, y))
				{
					ModConfig::Set(OPT_PAB_0 + e.mIdx, On(OPT_PAB_0 + e.mIdx) ? 0.0f : 1.0f);
					gApp->PlaySample(SOUND_BUTTONCLICK);
				}
			}
		}
	}

	void OptionsClick(int x, int y)
	{
		for (const Row& r : BuildRows())
		{
			int ry = LIST_Y + r.mY - static_cast<int>(mScroll);
			if (y < ry || y >= ry + r.mH) continue;
			gApp->PlaySample(SOUND_BUTTONCLICK);
			if (r.mType == 0) { sExpanded[r.mCat] = !sExpanded[r.mCat]; return; }
			int o = r.mOpt;
			mSelOpt = o;
			const ModOptionDef& d = ModConfig::Def(o);
			float v = ModConfig::Get(o);
			switch (d.mType)
			{
			case ModOptType::Toggle:
				if (CtrlToggle(ry).Contains(x, y) || x > CTRL_X) ModConfig::Set(o, v > 0.5f ? 0.0f : 1.0f);
				break;
			case ModOptType::Slider:
			case ModOptType::Int:
			case ModOptType::Select:
			{
				float step = d.mStep > 0 ? d.mStep : 1.0f;
				if (CtrlMinus(ry).Contains(x, y))
				{
					float nv = v - step;
					if (d.mType == ModOptType::Select && nv < d.mMin) nv = d.mMax;
					ModConfig::Set(o, nv);
				}
				else if (CtrlPlus(ry).Contains(x, y))
				{
					float nv = v + step;
					if (d.mType == ModOptType::Select && nv > d.mMax) nv = d.mMin;
					ModConfig::Set(o, nv);
				}
				else if (d.mType == ModOptType::Int && CtrlBar(ry).Contains(x, y))
				{
					mKeypadOpt = o;
					mKeypad = std::to_string(ModConfig::GetInt(o));
				}
				else if (d.mType == ModOptType::Select && CtrlBar(ry).Contains(x, y))
				{
					float nv = v + 1;
					ModConfig::Set(o, nv > d.mMax ? d.mMin : nv);
				}
				break;
			}
			case ModOptType::Action:
				if (CtrlAction(ry).Contains(x, y) || x > CTRL_X)
				{
					ModSystem::ExecuteAction(o);
					SetStatus(gActionMsg.empty() ? std::string("Done: ") + d.mLabel : gActionMsg);
				}
				break;
			}
			return;
		}
	}
};

namespace
{
	ModMenuWidget* sMenu = nullptr;
}

namespace ModSystem
{
	bool IsMenuOpen() { return sMenu != nullptr; }

	void OpenMenu()
	{
		if (sMenu || !gApp || !gApp->mWidgetManager) return;
		sMenu = new ModMenuWidget();
		sMenu->Resize(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
		gApp->mWidgetManager->AddWidget(sMenu);
		gApp->mWidgetManager->AddBaseModal(sMenu);
		gApp->mWidgetManager->SetFocus(sMenu);
		gW.mMenuWasPaused = false;
		Board* b = gApp->mBoard;
		if (b && On(OPT_MI_AUTOPAUSE) && !b->mPaused && gApp->mGameScene == SCENE_PLAYING)
		{
			b->Pause(true);
			gW.mMenuWasPaused = true;
		}
	}

	void CloseMenu()
	{
		if (!sMenu) return;
		ModMenuWidget* m = sMenu;
		sMenu = nullptr;
		gApp->mWidgetManager->RemoveBaseModal(m);
		gApp->mWidgetManager->RemoveWidget(m);
		gApp->SafeDeleteWidget(m);
		if (gW.mMenuWasPaused && gApp->mBoard) gApp->mBoard->Pause(false);
		gW.mMenuWasPaused = false;
		ModConfig::SaveIfDirty();
		ProgressSaveIfDirty();
	}

	static Rect MainMenuButtonRect() { return Rect(14, 548, 100, 36); }

	void DrawMenuButton(Graphics* g, bool theInGame)
	{
		if (theInGame) return;   // the in-game button is drawn by DrawHUD
		Rect r = MainMenuButtonRect();
		Button(g, r, "MOD", Color(120, 70, 30, 235));
	}

	bool MenuButtonHit(int x, int y, bool theInGame)
	{
		return !theInGame && MainMenuButtonRect().Contains(x, y);
	}
}
