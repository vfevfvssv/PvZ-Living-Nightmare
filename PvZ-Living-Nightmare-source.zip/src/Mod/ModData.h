// PvZ Living Nightmare - static content tables (variants, classes, mutations, bosses, weather, plants).
#ifndef __MOD_DATA_H__
#define __MOD_DATA_H__

#include <cstdint>
#include "../ConstEnums.h"

enum ModAbility : uint32_t
{
	AB_ARMOR        = 1u << 0,   // -40% damage from shots and bites
	AB_SPRINT       = 1u << 1,   // periodic sprint bursts
	AB_EXPLODE      = 1u << 2,   // explodes on death, hurting plants
	AB_REGEN        = 1u << 3,   // regenerates health
	AB_PROTECT      = 1u << 4,   // allies nearby take less damage
	AB_TOXIC        = 1u << 5,   // bites poison plants
	AB_FREEZER      = 1u << 6,   // freezes the plant in front
	AB_SUMMON       = 1u << 7,   // summons mini zombies
	AB_VAMPIRE      = 1u << 8,   // heals by biting
	AB_BERSERK      = 1u << 9,   // faster and stronger at low health
	AB_INVIS        = 1u << 10,  // periodically invisible / untargetable
	AB_SPLIT        = 1u << 11,  // splits into minis on death
	AB_ELECTRIC     = 1u << 12,  // chain lightning to several plants
	AB_BUILDER      = 1u << 13,  // builds temporary obstacles (craters)
	AB_TUNNEL       = 1u << 14,  // moves underground for a while
	AB_MIMIC        = 1u << 15,  // copies abilities of nearby zombies
	AB_BUBBLE       = 1u << 16,  // rechargeable energy shield
	AB_JUMP         = 1u << 17,  // leaps over the first plant
	AB_HEALER       = 1u << 18,  // heals allies nearby
	AB_RAGE         = 1u << 19,  // gains speed whenever it is hit
	AB_HASTE_AURA   = 1u << 20,  // allies nearby move faster
	AB_SABOTAGE     = 1u << 21,  // disables nearby plants
	AB_ARTILLERY    = 1u << 22,  // lobs projectiles at plants
	AB_NECRO        = 1u << 23,  // raises zombies from the ground
	AB_ICE_IMMUNE   = 1u << 24,  // cannot be chilled or frozen
	AB_FIRE_IMMUNE  = 1u << 25,  // resists fire and burn deaths
	AB_DEATH_FREEZE = 1u << 26,  // freezes plants when it dies
	AB_STOMP        = 1u << 27,  // shockwave that hurts plants
	AB_SUN_THIEF    = 1u << 28,  // steals sun with every bite
	AB_DODGE        = 1u << 29,  // can dodge projectiles
	AB_LANE_HOP     = 1u << 30,  // switches lanes
	AB_GROW         = 1u << 31   // grows bigger and tougher over time
};
constexpr int NUM_MOD_ABILITIES = 32;

struct ModAbilityInfo { const char* mName; const char* mDesc; };
extern const ModAbilityInfo gModAbilityInfo[NUM_MOD_ABILITIES];

struct ModVariantDef
{
	ZombieType   mBase;
	const char*  mName;
	uint32_t     mAbilities;
	float        mHealth;     // health multiplier
	float        mSpeed;      // speed multiplier
	float        mBite;       // bite damage multiplier
	float        mScale;      // size multiplier
	uint8_t      mR, mG, mB;  // tint
	int          mTier;       // 0 = always, 1 = 50 kills, 2 = 200 kills
	const char*  mDesc;
	const char*  mWeakness;
};
extern const ModVariantDef gModVariants[];
extern const int NUM_MOD_VARIANTS;

enum ModZombieClass : int8_t
{
	CLASS_TANK, CLASS_ASSASSIN, CLASS_SUPPORT, CLASS_HEALER, CLASS_SUMMONER,
	CLASS_DESTROYER, CLASS_SABOTEUR, CLASS_SCOUT, CLASS_CONTROLLER, CLASS_ARTILLERY,
	NUM_MOD_CLASSES
};
struct ModClassDef
{
	const char* mName;
	const char* mShort;
	float       mHealth, mSpeed, mBite, mDefense;
	uint32_t    mGrants;      // abilities granted by the class
	uint8_t     mR, mG, mB;
	const char* mDesc;
};
extern const ModClassDef gModClasses[NUM_MOD_CLASSES];

enum ModMutation : int
{
	MUT_FAST, MUT_ARMORED, MUT_REGEN, MUT_EXPLOSIVE, MUT_TOXIC,
	MUT_ELECTRIC, MUT_GIANT, MUT_MULTIPLIER, MUT_FROZEN, MUT_BERSERK,
	NUM_MOD_MUTATIONS
};
struct ModMutationDef
{
	const char* mName;
	const char* mShort;
	int         mDefaultWeight;   // relative weight (rarity)
	uint32_t    mGrants;
	float       mHealth, mSpeed, mScale;
	uint8_t     mR, mG, mB;
	const char* mDesc;
};
extern const ModMutationDef gModMutations[NUM_MOD_MUTATIONS];

enum ModMutationCombo : int8_t
{
	COMBO_FRENZY, COMBO_COLOSSUS, COMBO_PLAGUE, COMBO_DYNAMO, COMBO_GLACIER, COMBO_CLUSTER,
	NUM_MOD_COMBOS
};
struct ModComboDef
{
	const char* mName;
	int         mMutA, mMutB;
	uint32_t    mGrants;
	float       mHealth, mSpeed;
	const char* mDesc;
};
extern const ModComboDef gModCombos[NUM_MOD_COMBOS];

enum ModBossType : int8_t
{
	BOSS_ARMORED_GIANT, BOSS_MECHANIC, BOSS_NECROMANCER, BOSS_MUTANT, BOSS_FIRE, BOSS_ICE, BOSS_ELECTRIC,
	NUM_MOD_BOSSES
};
struct ModBossDef
{
	const char* mName;
	ZombieType  mBase;
	int         mHealth;
	float       mSpeed;
	float       mScale;
	uint32_t    mAbilities;
	uint8_t     mR, mG, mB;
	const char* mDesc;
	const char* mPhases;
};
extern const ModBossDef gModBosses[NUM_MOD_BOSSES];

enum ModWeather : int
{
	WEATHER_CLEAR, WEATHER_RAIN, WEATHER_STORM, WEATHER_FOG, WEATHER_SNOW, WEATHER_DARK, WEATHER_WIND, WEATHER_HEAT,
	NUM_MOD_WEATHERS
};
enum ModRareEvent : int
{
	EVENT_NONE, EVENT_BLOOD_MOON, EVENT_METEOR_SHOWER, EVENT_AURORA, EVENT_ECLIPSE,
	NUM_MOD_EVENTS
};
struct ModWeatherDef { const char* mName; const char* mDesc; };
extern const ModWeatherDef gModWeathers[NUM_MOD_WEATHERS];
extern const ModWeatherDef gModEvents[NUM_MOD_EVENTS];

enum ModGameMode : int
{
	MODE_NONE, MODE_ENDLESS, MODE_RUSH, MODE_BOSS_RUSH, MODE_RANDOM_WAVES, MODE_HARDCORE, MODE_NO_SUN,
	MODE_SINGLE_LANE, MODE_INVASION, MODE_RANDOM_PLANTS, MODE_RANDOM_ZOMBIES, MODE_CUSTOM_WAVES, MODE_SANDBOX,
	NUM_MOD_GAME_MODES
};
struct ModGameModeDef { const char* mName; const char* mDesc; };
extern const ModGameModeDef gModGameModes[NUM_MOD_GAME_MODES];

enum ModPlantTrait : int8_t
{
	TRAIT_SWIFT, TRAIT_MIGHTY, TRAIT_STURDY, TRAIT_LUCKY, TRAIT_FROSTY, TRAIT_VAMPIRIC, TRAIT_THORNY,
	NUM_MOD_TRAITS
};
struct ModTraitDef { const char* mName; const char* mDesc; };
extern const ModTraitDef gModTraits[NUM_MOD_TRAITS];

// Plant abilities (one toggle each in the mod menu)
struct ModPlantAbilityDef
{
	SeedType    mSeed;
	const char* mPlant;
	const char* mAbility;
	const char* mBranchA;
	const char* mBranchB;
	int         mUnlockXP;     // total XP of this plant type needed to unlock the upgrade branches
};
extern const ModPlantAbilityDef gModPlantAbilities[];
extern const int NUM_MOD_PLANT_ABILITIES;
int ModFindPlantAbility(SeedType theSeed);   // index into gModPlantAbilities or -1

struct ModPlantComboDef { const char* mName; const char* mDesc; };
enum ModPlantCombo { PCOMBO_FLAME_LINE, PCOMBO_SOLAR_GRID, PCOMBO_BULWARK, PCOMBO_DEEP_FREEZE, PCOMBO_SALAD_BAR, PCOMBO_SPORE_CLOUD, PCOMBO_STAR_FORT, NUM_MOD_PLANT_COMBOS };
extern const ModPlantComboDef gModPlantCombos[NUM_MOD_PLANT_COMBOS];

const char* ModZombieTypeName(ZombieType theType);
extern const char* const gModSpawnableZombieNames[];
extern const ZombieType gModSpawnableZombieTypes[];
extern const int NUM_MOD_SPAWNABLE_ZOMBIES;

#endif
