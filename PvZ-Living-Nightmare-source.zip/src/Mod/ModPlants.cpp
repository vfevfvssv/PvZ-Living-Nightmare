// PvZ Living Nightmare - plant abilities, upgrade branches, levels, traits, combos, projectiles and Plant Food.
#include "ModInternal.h"

using namespace ModInt;

namespace
{
	const int kLevelXP[5] = { 0, 120, 400, 900, 1800 };

	bool IsShooter(SeedType s)
	{
		switch (s)
		{
		case SEED_PEASHOOTER: case SEED_SNOWPEA: case SEED_REPEATER: case SEED_THREEPEATER: case SEED_GATLINGPEA: case SEED_SPLITPEA:
		case SEED_LEFTPEATER: case SEED_CACTUS: case SEED_CATTAIL: case SEED_STARFRUIT: case SEED_PUFFSHROOM: case SEED_SCAREDYSHROOM:
		case SEED_FUMESHROOM: case SEED_GLOOMSHROOM: case SEED_SEASHROOM: case SEED_CABBAGEPULT: case SEED_KERNELPULT:
		case SEED_MELONPULT: case SEED_WINTERMELON:
			return true;
		default:
			return false;
		}
	}
	bool IsPeaFamily(SeedType s)
	{
		return s == SEED_PEASHOOTER || s == SEED_REPEATER || s == SEED_GATLINGPEA || s == SEED_THREEPEATER || s == SEED_SNOWPEA || s == SEED_SPLITPEA;
	}
	bool IsNut(SeedType s) { return s == SEED_WALLNUT || s == SEED_TALLNUT || s == SEED_PUMPKINSHELL; }
	bool IsSunPlant(SeedType s) { return s == SEED_SUNFLOWER || s == SEED_TWINSUNFLOWER || s == SEED_SUNSHROOM; }

	Plant* SourcePlant(Projectile* pr)
	{
		Board* b = GetBoard();
		if (!b || pr->mMod.mSourcePlant == 0) return nullptr;
		Plant* p = b->mPlants.DataArrayTryToGet(pr->mMod.mSourcePlant);
		return (p && !p->mDead) ? p : nullptr;
	}

	float LevelDamage(Plant* p) { return On(OPT_PA_XP) ? 1.0f + 0.10f * p->mMod.mLevel : 1.0f; }
	float LevelFire(Plant* p) { return On(OPT_PA_XP) ? 1.0f + 0.08f * p->mMod.mLevel : 1.0f; }

	bool StraightMotion(Projectile* pr)
	{
		return pr->mMotionType == MOTION_STRAIGHT || pr->mMotionType == MOTION_BACKWARDS || pr->mMotionType == MOTION_THREEPEATER || pr->mMotionType == MOTION_PUFF;
	}

	void LevelUp(Plant* p)
	{
		PlantModState& m = p->mMod;
		m.mLevel++;
		m.mLevelUpFlash = 60;
		int add = p->mPlantMaxHealth / 10;
		p->mPlantMaxHealth += add;
		p->mPlantHealth = p->mPlantMaxHealth;
		bool evolved = m.mLevel >= 4;
		if (evolved) gP.mEvolvedPlants++;
		AddFloatingText(p->mX + 40.0f, static_cast<float>(p->mY), evolved ? "EVOLVED!" : std::format("LEVEL {}", m.mLevel + 1), 255, evolved ? 215 : 255, evolved ? 60 : 140, evolved ? 1.2f : 1.0f);
		if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(p->mX + 40, p->mY + 40, p->mRenderOrder + 1, PARTICLE_PRESENT_PICKUP);
		gApp->PlayFoley(FOLEY_PLANTGROW);
	}

	void Accelerate(Plant* p, float theExtra)
	{
		PlantModState& m = p->mMod;
		m.mProduceAccum += theExtra;
		while (m.mProduceAccum >= 1.0f)
		{
			m.mProduceAccum -= 1.0f;
			if (p->mStateCountdown > 1) p->mStateCountdown--;
		}
	}

	void HealNeighbours(Plant* p, int theAmount)
	{
		for (Plant* q : p->mBoard->mPlants)
			if (!q->mDead && q != p && std::abs(q->mPlantCol - p->mPlantCol) <= 1 && std::abs(q->mRow - p->mRow) <= 1)
				HealPlant(q, theAmount);
	}
}

namespace ModInt
{
	bool PlantAbilityOn(SeedType theSeed)
	{
		if (!On(OPT_PA_ENABLE)) return false;
		int i = ModFindPlantAbility(theSeed);
		return i >= 0 && On(OPT_PAB_0 + i);
	}

	int PlantBranch(SeedType theSeed)
	{
		int i = ModFindPlantAbility(theSeed);
		if (i < 0 || !PlantAbilityOn(theSeed)) return 0;
		int br = OptI(OPT_PBR_0 + i);
		if (br == 0) return 0;
		if (!On(OPT_PA_UNLOCK_UPGRADES) && gP.mPlantXP[theSeed] < gModPlantAbilities[i].mUnlockXP) return 0;
		return br;
	}

	bool PlantProtected(Plant* p)
	{
		return On(OPT_P_INVULN) || p->mMod.mShield > 0 || gW.mPlantShieldTimer > 0;
	}

	void HealPlant(Plant* p, int theAmount)
	{
		if (p->mDead || theAmount <= 0) return;
		p->mPlantHealth = std::min(p->mPlantMaxHealth, p->mPlantHealth + theAmount);
	}

	void DamagePlant(Plant* p, int theDamage)
	{
		if (p->mDead || theDamage <= 0 || PlantProtected(p) || !p->IsOnBoard()) return;
		Board* b = p->mBoard;
		// a pumpkin protects the plant inside it
		if (p->mSeedType != SEED_PUMPKINSHELL)
		{
			Plant* aPumpkin = b->GetTopPlantAt(p->mPlantCol, p->mRow, TOPPLANT_ONLY_PUMPKIN);
			if (aPumpkin && aPumpkin != p && !aPumpkin->mDead) p = aPumpkin;
		}
		p->mPlantHealth -= theDamage;
		p->mEatenFlashCountdown = std::max(p->mEatenFlashCountdown, 25);
		if (p->mPlantHealth <= 0)
		{
			gApp->PlaySample(SOUND_GULP);
			b->mPlantsEaten++;
			gW.mPlantsLost++;
			p->Die();
		}
	}

	bool TorchwoodWarmth(Plant* p)
	{
		if (!PlantAbilityOn(SEED_TORCHWOOD) || PlantBranch(SEED_TORCHWOOD) != 2) return false;
		for (Plant* q : p->mBoard->mPlants)
			if (!q->mDead && q->mSeedType == SEED_TORCHWOOD && std::abs(q->mPlantCol - p->mPlantCol) <= 1 && std::abs(q->mRow - p->mRow) <= 1)
				return true;
		return false;
	}

	void FreezePlant(Plant* p, int theTicks)
	{
		if (p->mDead || PlantProtected(p) || TorchwoodWarmth(p)) return;
		if (WeatherIs(WEATHER_HEAT)) theTicks /= 2;
		p->mMod.mFrozen = std::max(p->mMod.mFrozen, theTicks);
	}

	void DisablePlant(Plant* p, int theTicks)
	{
		if (p->mDead || PlantProtected(p)) return;
		p->mMod.mDisabled = std::max(p->mMod.mDisabled, theTicks);
	}

	void AddPlantXP(Plant* p, int theXP)
	{
		if (!p || p->mDead || theXP <= 0 || !p->IsOnBoard() || p->mSeedType < 0 || p->mSeedType >= NUM_SEED_TYPES) return;
		int xp = std::max(1, static_cast<int>(theXP * Opt(OPT_PA_XP_MULT)));
		gP.mPlantXP[p->mSeedType] = std::min(gP.mPlantXP[p->mSeedType] + xp, 100000000);
		MarkProgressDirty();
		if (!On(OPT_PA_XP)) return;
		PlantModState& m = p->mMod;
		m.mXP += xp;
		while (m.mLevel < 4 && m.mXP >= kLevelXP[m.mLevel + 1])
			LevelUp(p);
	}

	bool RevealedByPlantern(Zombie* z)
	{
		Board* b = z->mBoard;
		if (!b || !PlantAbilityOn(SEED_PLANTERN)) return false;
		bool beacon = PlantBranch(SEED_PLANTERN) == 1;
		for (Plant* p : b->mPlants)
		{
			if (p->mDead || p->mSeedType != SEED_PLANTERN) continue;
			if (beacon) return true;
			float dx = (z->mPosX + 40) - (p->mX + 40), dy = (z->mPosY + 60) - (p->mY + 40);
			if (dx * dx + dy * dy < 230.0f * 230.0f) return true;
		}
		return false;
	}

	void DamagePlantsInRadius(float x, float y, float theRadius, int theDamage, bool thePoison, bool theFreeze)
	{
		Board* b = GetBoard();
		if (!b) return;
		for (Plant* p : b->mPlants)
		{
			if (p->mDead || p->NotOnGround()) continue;
			float dx = (p->mX + 40) - x, dy = (p->mY + 40) - y;
			if (dx * dx + dy * dy > theRadius * theRadius) continue;
			if (theDamage > 0) DamagePlant(p, theDamage);
			if (p->mDead) continue;
			if (thePoison) p->mMod.mPoison = std::max(p->mMod.mPoison, 600);
			if (theFreeze) FreezePlant(p, 240);
		}
	}

	void UpdatePlantCombos(Board* b)
	{
		Plant* grid[MAX_GRID_SIZE_X][MAX_GRID_SIZE_Y] = {};
		bool pumpkin[MAX_GRID_SIZE_X][MAX_GRID_SIZE_Y] = {};
		bool on = On(OPT_PA_COMBOS);
		for (Plant* p : b->mPlants)
		{
			if (p->mDead) continue;
			p->mMod.mCombos = 0; p->mMod.mComboFire = 1.0f; p->mMod.mComboDamage = 1.0f;
			if (p->mPlantCol < 0 || p->mPlantCol >= MAX_GRID_SIZE_X || p->mRow < 0 || p->mRow >= MAX_GRID_SIZE_Y) continue;
			if (p->mSeedType == SEED_PUMPKINSHELL) pumpkin[p->mPlantCol][p->mRow] = true;
			else if (p->mSeedType != SEED_LILYPAD && p->mSeedType != SEED_FLOWERPOT) grid[p->mPlantCol][p->mRow] = p;
		}
		if (!on) return;
		auto at = [&](int c, int r) -> Plant* { return (c >= 0 && c < MAX_GRID_SIZE_X && r >= 0 && r < MAX_GRID_SIZE_Y) ? grid[c][r] : nullptr; };
		for (int c = 0; c < MAX_GRID_SIZE_X; c++)
		for (int r = 0; r < MAX_GRID_SIZE_Y; r++)
		{
			Plant* p = grid[c][r];
			if (!p) continue;
			PlantModState& m = p->mMod;
			SeedType s = p->mSeedType;
			if (IsPeaFamily(s))
				for (int cc = c + 1; cc < MAX_GRID_SIZE_X; cc++)
					if (at(cc, r) && at(cc, r)->mSeedType == SEED_TORCHWOOD) { m.mCombos |= 1 << PCOMBO_FLAME_LINE; m.mComboFire *= 1.15f; break; }
			if (IsSunPlant(s))
			{
				int n = 0;
				for (int dc = -1; dc <= 1; dc++) for (int dr = -1; dr <= 1; dr++)
					if ((dc || dr) && at(c + dc, r + dr) && IsSunPlant(at(c + dc, r + dr)->mSeedType)) n++;
				if (n >= 2) { m.mCombos |= 1 << PCOMBO_SOLAR_GRID; m.mComboFire *= 1.1f; }
			}
			if (IsNut(s))
				for (int cc = c - 1; cc >= 0; cc--)
					if (at(cc, r) && IsShooter(at(cc, r)->mSeedType)) { m.mCombos |= 1 << PCOMBO_BULWARK; break; }
			if (s == SEED_SNOWPEA || s == SEED_WINTERMELON)
			{
				SeedType other = s == SEED_SNOWPEA ? SEED_WINTERMELON : SEED_SNOWPEA;
				for (int cc = 0; cc < MAX_GRID_SIZE_X; cc++)
					if (at(cc, r) && at(cc, r)->mSeedType == other) { m.mCombos |= 1 << PCOMBO_DEEP_FREEZE; break; }
			}
			const int dc4[4] = { 1, -1, 0, 0 }, dr4[4] = { 0, 0, 1, -1 };
			for (int k = 0; k < 4; k++)
			{
				Plant* q = at(c + dc4[k], r + dr4[k]);
				if (!q) continue;
				if (s == SEED_KERNELPULT && q->mSeedType == SEED_CABBAGEPULT) m.mCombos |= 1 << PCOMBO_SALAD_BAR;
				if ((s == SEED_FUMESHROOM || s == SEED_GLOOMSHROOM) && Plant::IsFungus(q->mSeedType)) m.mCombos |= 1 << PCOMBO_SPORE_CLOUD;
				int qc = c + dc4[k], qr = r + dr4[k];
				if (s == SEED_STARFRUIT && pumpkin[qc][qr]) m.mCombos |= 1 << PCOMBO_STAR_FORT;
			}
			if (m.mCombos & (1 << PCOMBO_SPORE_CLOUD)) m.mComboDamage *= 1.2f;
			if (m.mCombos & (1 << PCOMBO_STAR_FORT)) m.mComboDamage *= 1.15f;
		}
	}
}

namespace ModSystem
{
	void PlantInit(Plant* p)
	{
		PlantModState& m = p->mMod;
		m = PlantModState();
		m.mInitialized = true;
		if (!gApp || !p->mBoard || !p->IsOnBoard() || gApp->mGameMode == GAMEMODE_CHALLENGE_ZEN_GARDEN || gApp->mGameMode == GAMEMODE_TREE_OF_WISDOM)
			return;
		float hp = Opt(OPT_P_HP);
		if (On(OPT_PA_TRAITS) && Chance(20.0f))
		{
			m.mTrait = static_cast<int8_t>(Rand(NUM_MOD_TRAITS));
			if (m.mTrait == TRAIT_STURDY) hp *= 1.75f;
		}
		SeedType s = p->mSeedType;
		if (PlantAbilityOn(s))
		{
			int br = PlantBranch(s);
			if (s == SEED_GARLIC) hp *= br == 2 ? 3.0f : 1.5f;
			if ((s == SEED_PUMPKINSHELL || s == SEED_SPIKEROCK) && br == 1) hp *= 2.0f;
			if (s == SEED_POTATOMINE && p->mState == STATE_NOTREADY) p->mStateCountdown = std::max(1, static_cast<int>(p->mStateCountdown * (br == 2 ? 0.1f : 0.65f)));
			if (s == SEED_SUNSHROOM && p->mState == STATE_SUNSHROOM_SMALL) p->mStateCountdown = std::max(1, p->mStateCountdown / 2);
		}
		if (std::fabs(hp - 1.0f) > 0.001f)
		{
			p->mPlantMaxHealth = std::max(1, static_cast<int>(p->mPlantMaxHealth * hp));
			p->mPlantHealth = p->mPlantMaxHealth;
		}
	}

	bool PlantUpdate(Plant* p)
	{
		PlantModState& m = p->mMod;
		if (!InPlay() || !p->IsOnBoard()) return false;
		if (m.mShield > 0) m.mShield--;
		if (m.mLevelUpFlash > 0) m.mLevelUpFlash--;
		if (m.mFrozen > 0) m.mFrozen--;
		if (m.mDisabled > 0) m.mDisabled--;
		if (m.mSlowed > 0) m.mSlowed--;
		if (m.mRapidFire > 0) m.mRapidFire--;
		if (m.mBoost > 0) m.mBoost--;
		if (m.mPoison > 0)
		{
			m.mPoison--;
			if (m.mPoison % 50 == 0 && !TorchwoodWarmth(p)) DamagePlant(p, 4);
			if (p->mDead) return true;
		}
		SeedType s = p->mSeedType;
		int age = static_cast<int>(gW.mTick) + p->mPlantCol * 7 + p->mRow * 13;
		bool ab = PlantAbilityOn(s);
		int br = ab ? PlantBranch(s) : 0;
		bool regen = On(OPT_P_REGEN) || EventIs(EVENT_AURORA) || (m.mCombos & (1 << PCOMBO_BULWARK)) ||
			(ab && br == 2 && (s == SEED_WALLNUT || s == SEED_TALLNUT));
		if (regen && age % 60 == 0) HealPlant(p, std::max(1, p->mPlantMaxHealth / 100));
		if (ab)
		{
			if (br == 2 && (s == SEED_SUNFLOWER || s == SEED_TWINSUNFLOWER || s == SEED_SUNSHROOM) && age % 300 == 0) HealNeighbours(p, 20);
			if (br == 2 && s == SEED_PLANTERN && age % 1500 == 0) p->mBoard->AddCoin(p->mX, p->mY, COIN_SMALLSUN, COIN_MOTION_FROM_PLANT);
			if (s == SEED_MAGNETSHROOM && p->mState == STATE_MAGNETSHROOM_SUCKING)
			{
				Accelerate(p, br == 1 ? 4.0f : 1.0f);
				if (br == 2 && m.mShotCount == 0)
				{
					m.mShotCount = 1;
					for (Zombie* z : p->mBoard->mZombies)
						if (IsLiveEnemy(z) && std::fabs(z->mPosX - p->mX) < 260 && std::abs(z->mRow - p->mRow) <= 2)
						{ z->TakeDamage(80, 0U); break; }
				}
			}
			else if (s == SEED_MAGNETSHROOM) m.mShotCount = 0;
			if (s == SEED_COBCANNON && p->mState == STATE_COBCANNON_ARMING) Accelerate(p, br == 1 ? 1.0f : 0.43f);
			if (s == SEED_GRAVEBUSTER && p->mState == STATE_GRAVEBUSTER_EATING)
			{
				if (br == 1) Accelerate(p, 1.0f);
				if (p->mStateCountdown <= 2 && m.mShotCount == 0)
				{
					m.mShotCount = 1;
					p->mBoard->AddCoin(p->mX, p->mY, COIN_SUN, COIN_MOTION_FROM_PLANT);
					p->mBoard->AddCoin(p->mX + 10, p->mY, COIN_SUN, COIN_MOTION_FROM_PLANT);
					if (br == 2) p->mBoard->AddCoin(p->mX, p->mY, COIN_GOLD, COIN_MOTION_COIN);
				}
			}
		}
		bool disabled = (m.mFrozen > 0 || m.mDisabled > 0) && m.mBoost == 0;
		return disabled;
	}

	int PlantShooterUpdates(Plant* p)
	{
		if (!InPlay() || !p->IsOnBoard()) return 1;
		PlantModState& m = p->mMod;
		SeedType s = p->mSeedType;
		float rate = Opt(OPT_P_FIRERATE) * LevelFire(p) * m.mComboFire;
		if (m.mTrait == TRAIT_SWIFT) rate *= 1.3f;
		int br = PlantBranch(s);
		if ((s == SEED_PEASHOOTER && br == 2) || (s == SEED_SPLITPEA && br == 1) || (s == SEED_SCAREDYSHROOM && br == 1)) rate *= 1.3f;
		if ((s == SEED_THREEPEATER && br == 2) || (s == SEED_CATTAIL && br == 2)) rate *= 1.25f;
		if (m.mRapidFire > 0) rate *= 2.5f;
		if (m.mBoost > 0) rate *= 5.0f;
		if (m.mSlowed > 0) rate *= 0.5f;
		if (WeatherIs(WEATHER_SNOW) && !TorchwoodWarmth(p)) rate *= 0.9f;
		m.mFireAccum += rate;
		int n = static_cast<int>(m.mFireAccum);
		m.mFireAccum -= n;
		return std::clamp(n, 0, 8);
	}

	int PlantProducerUpdates(Plant* p)
	{
		if (!InPlay() || !p->IsOnBoard()) return 1;
		PlantModState& m = p->mMod;
		float rate = Opt(OPT_E_SUN_PRODUCTION) * m.mComboFire;
		if (IsMode(MODE_NO_SUN)) return 0;
		if (WeatherIs(WEATHER_RAIN) || WeatherIs(WEATHER_STORM)) rate *= 0.8f;
		if (WeatherIs(WEATHER_DARK)) rate *= 0.7f;
		if (WeatherIs(WEATHER_HEAT)) rate *= 1.25f;
		if (EventIs(EVENT_AURORA)) rate *= 2.0f;
		if (EventIs(EVENT_ECLIPSE)) rate *= 0.5f;
		if (On(OPT_PA_XP)) rate *= 1.0f + 0.05f * m.mLevel;
		if (m.mBoost > 0) rate *= 4.0f;
		m.mFireAccum += rate;
		int n = static_cast<int>(m.mFireAccum);
		m.mFireAccum -= n;
		return std::clamp(n, 0, 8);
	}

	void PlantProducedSun(Plant* p)
	{
		if (!InPlay()) return;
		AddPlantXP(p, 40);
		SeedType s = p->mSeedType;
		if (!PlantAbilityOn(s)) return;
		int br = PlantBranch(s);
		float ch = 0.0f;
		if (s == SEED_SUNFLOWER) ch = br == 1 ? 25.0f : 10.0f;
		if (s == SEED_TWINSUNFLOWER) ch = br == 1 ? 30.0f : 15.0f;
		if (s == SEED_SUNSHROOM && br == 1) ch = 25.0f;
		if (p->mMod.mTrait == TRAIT_LUCKY) ch += 10.0f;
		if (Chance(ch))
		{
			p->mBoard->AddCoin(p->mX + 10, p->mY, s == SEED_SUNSHROOM && p->mState == STATE_SUNSHROOM_SMALL ? COIN_SMALLSUN : COIN_SUN, COIN_MOTION_FROM_PLANT);
			AddFloatingText(p->mX + 40.0f, static_cast<float>(p->mY), "BONUS SUN", 255, 240, 120, 0.8f);
		}
	}

	void PlantFired(Plant* p, Projectile* pr, Zombie* theTarget, int theWeapon)
	{
		if (!pr || !InPlay() || !p->IsOnBoard()) return;
		Board* b = p->mBoard;
		ProjectileModState& pm = pr->mMod;
		pm.mInitialized = true;
		pm.mSourcePlant = b->mPlants.DataArrayGetID(p);
		PlantModState& m = p->mMod;
		SeedType s = p->mSeedType;
		bool ab = PlantAbilityOn(s);
		int br = ab ? PlantBranch(s) : 0;
		float dmg = LevelDamage(p) * m.mComboDamage;
		if (m.mTrait == TRAIT_MIGHTY) dmg *= 1.35f;
		if (m.mLevel >= 4 && On(OPT_PA_XP)) dmg *= 1.15f;
		if (WeatherIs(WEATHER_DARK) && Plant::IsFungus(s)) dmg *= 1.2f;
		float pierceCh = 0.0f, freezeCh = 0.0f;
		if (ab)
		{
			switch (s)
			{
			case SEED_PEASHOOTER:   pierceCh = br == 1 ? 30.0f : 12.0f; if (br == 1) dmg *= 1.2f; break;
			case SEED_THREEPEATER:  pierceCh = 10.0f; if (br == 1) dmg *= 1.2f; break;
			case SEED_GATLINGPEA:   if (br == 2) pierceCh = 15.0f; break;
			case SEED_SNOWPEA:      freezeCh = br == 1 ? 18.0f : 8.0f; if (br == 2) dmg *= 1.4f; break;
			case SEED_WINTERMELON:  freezeCh = br == 1 ? 20.0f : 10.0f; if (br == 2) dmg *= 1.25f; break;
			case SEED_REPEATER:     if (br == 2) dmg *= 1.25f; break;
			case SEED_SPLITPEA:     if (theWeapon == WEAPON_SECONDARY) dmg *= 2.0f; if (br == 2) dmg *= 1.25f; break;
			case SEED_PUFFSHROOM:   if (b->StageIsNight()) dmg *= 1.5f; if (br == 2) dmg *= 1.4f; if (br == 1) pm.mChill = false; break;
			case SEED_SCAREDYSHROOM:dmg *= 1.6f; if (br == 2) pm.mPierce = 2; break;
			case SEED_CACTUS:       pm.mPierce = br == 1 ? 5 : 3; if (br == 2) dmg *= 1.3f; break;
			case SEED_CATTAIL:      pierceCh = 15.0f; if (br == 1) dmg *= 1.25f; break;
			case SEED_STARFRUIT:    pierceCh = br == 2 ? 35.0f : 15.0f; if (br == 1) dmg *= 1.25f; break;
			case SEED_CABBAGEPULT:  if (Chance(br == 1 ? 30.0f : 15.0f)) { pm.mStun = true; dmg *= 1.5f; } if (br == 2) pm.mExplosive = true; break;
			case SEED_KERNELPULT:
				if (pr->mProjectileType == PROJECTILE_BUTTER)
				{
					float ch = br == 1 ? 12.0f : 5.0f;
					if (m.mCombos & (1 << PCOMBO_SALAD_BAR)) ch *= 1.5f;
					pm.mExplosive = Chance(ch);
				}
				if (br == 2) dmg *= 1.3f;
				break;
			case SEED_MELONPULT:    dmg *= br == 1 ? 1.4f : 1.25f; if (br == 2) pm.mStun = true; break;
			default: break;
			}
		}
		if (m.mCombos & (1 << PCOMBO_DEEP_FREEZE)) freezeCh += 5.0f;
		if (Chance(pierceCh)) pm.mPierce = std::max<int8_t>(pm.mPierce, 2);
		if (Chance(freezeCh)) pm.mFreeze = true;
		if (On(OPT_P_PIERCE_ALL) && StraightMotion(pr)) pm.mPierce = std::max<int8_t>(pm.mPierce, 3);
		if (m.mTrait == TRAIT_FROSTY) pm.mChill = true;
		if (s == SEED_PUFFSHROOM && br == 1 && ab) pm.mPoison = 1;
		float crit = Opt(OPT_P_CRIT) + (m.mTrait == TRAIT_LUCKY ? 20.0f : 0.0f) + (m.mLevel >= 2 && On(OPT_PA_XP) ? 5.0f : 0.0f);
		pm.mCrit = Chance(crit);
		pm.mDamageMult = dmg;

		if (StraightMotion(pr))
		{
			float sp = Opt(OPT_P_PROJ_SPEED);
			pr->mVelX *= sp;
			pr->mVelY *= sp;
		}
		else if (pr->mMotionType == MOTION_LOBBED && WeatherIs(WEATHER_WIND) && s != SEED_COBCANNON)
			pr->mVelX *= 1.0f + 0.08f * gW.mWindDir * std::min(1.5f, WeatherAmount(WEATHER_WIND));

		// rapid fire triggers (Repeater / Gatling Pea)
		if (ab && (s == SEED_REPEATER || s == SEED_GATLINGPEA) && m.mRapidFire == 0)
		{
			m.mShotCount++;
			int every = s == SEED_REPEATER ? 24 : 40;     // shots (repeater fires 2 per volley, gatling 4)
			if (m.mShotCount >= every)
			{
				m.mShotCount = 0;
				m.mRapidFire = br == 1 ? 360 : 180;
				AddFloatingText(p->mX + 40.0f, static_cast<float>(p->mY), "RAPID FIRE!", 255, 220, 80, 0.9f);
			}
		}
		if (On(OPT_X_BACKFIRE) && pr->mMotionType == MOTION_STRAIGHT && !pm.mBackward)
		{
			Projectile* back = b->AddProjectile(static_cast<int>(pr->mPosX) - 30, static_cast<int>(pr->mPosY), pr->mRenderOrder, pr->mRow, pr->mProjectileType);
			if (back)
			{
				back->mMotionType = MOTION_BACKWARDS;
				back->mDamageRangeFlags = pr->mDamageRangeFlags;
				back->mMod = pm;
				back->mMod.mBackward = true;
			}
		}
	}

	int ProjectileDamageInternal(Projectile* pr, Zombie* z, int theDamage, bool theRecordXP)
	{
		ProjectileModState& pm = pr->mMod;
		float f = Opt(OPT_P_DAMAGE) * (pm.mInitialized ? pm.mDamageMult : 1.0f);
		if (pr->mProjectileType == PROJECTILE_FIREBALL)
		{
			if (PlantAbilityOn(SEED_TORCHWOOD)) f *= PlantBranch(SEED_TORCHWOOD) == 1 ? 1.5f : 1.25f;
			if (WeatherIs(WEATHER_RAIN) || WeatherIs(WEATHER_STORM)) f *= 0.7f;
		}
		if (pm.mCrit) f *= 2.0f;
		int d = std::max(1, static_cast<int>(std::lround(theDamage * f)));
		if (pm.mCrit && z && On(OPT_V_DMG_NUMBERS))
			AddFloatingText(z->mPosX + 40.0f, z->mPosY, "CRIT!", 255, 80, 60, 1.0f);
		if (theRecordXP) AddPlantXP(SourcePlant(pr), d / 4 + 1);
		MarkShot();
		return d;
	}

	void ProjectileInit(Projectile* pr)
	{
		pr->mMod = ProjectileModState();
	}

	int ProjectileDamage(Projectile* pr, Zombie* z, int theDamage)
	{
		if (!InPlay()) return theDamage;
		return ProjectileDamageInternal(pr, z, theDamage, true);
	}

	void ProjectileHit(Projectile* pr, Zombie* z)
	{
		if (!InPlay() || !z) return;
		ProjectileModState& pm = pr->mMod;
		Board* b = pr->mBoard;
		bool boss = z->mMod.mBoss >= 0 || z->mZombieType == ZOMBIE_BOSS;
		if (pm.mFreeze && !z->IsDeadOrDying())
		{
			FreezeZombie(z, 150);
			if (On(OPT_V_DMG_NUMBERS)) AddFloatingText(z->mPosX + 40.0f, z->mPosY + 5, "FROZEN", 150, 220, 255, 0.9f);
		}
		if (pm.mChill && !z->IsDeadOrDying()) z->ApplyChill(false);
		if (pm.mPoison) z->mMod.mPoison = std::max(z->mMod.mPoison, 240);
		if (pm.mStun && !boss && !z->IsDeadOrDying() && z->mZombieType != ZOMBIE_BOSS)
		{
			z->ApplyButter();
			z->mButteredCounter = std::min(z->mButteredCounter, 150);
		}
		if (pm.mExplosive)
		{
			float cx = z->mPosX + 40.0f;
			for (Zombie* o : b->mZombies)
			{
				if (o == z || !IsLiveEnemy(o)) continue;
				if (std::abs(o->mRow - z->mRow) <= 1 && std::fabs(o->mPosX + 40.0f - cx) < 90.0f)
				{
					o->TakeDamage(60, 0U);
					if (pr->mProjectileType == PROJECTILE_BUTTER && o->mMod.mBoss < 0) o->ApplyButter();
				}
			}
			if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(cx, z->mPosY + 60, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), pr->mProjectileType == PROJECTILE_BUTTER ? PARTICLE_BUTTER_SPLAT : PARTICLE_CABBAGE_SPLAT);
		}
		if (!boss && !z->mMindControlled && !z->IsDeadOrDying() && Chance(Opt(OPT_Z_HYPNO_CHANCE)))
			z->StartMindControlled();
		Plant* src = SourcePlant(pr);
		if (src && (On(OPT_X_LIFESTEAL) || src->mMod.mTrait == TRAIT_VAMPIRIC)) HealPlant(src, 3);
		if (On(OPT_X_RICOCHET) && !pm.mBackward && (pr->mProjectileType == PROJECTILE_PEA || pr->mProjectileType == PROJECTILE_SNOWPEA || pr->mProjectileType == PROJECTILE_FIREBALL) && Rand(100) < 30)
		{
			int rows = b->StageHas6Rows() ? 6 : 5;
			int nr = pr->mRow + (Rand(2) ? 1 : -1);
			if (nr < 0 || nr >= rows) nr = pr->mRow * 2 - nr;
			if (nr >= 0 && nr < rows)
			{
				int dy = b->GridToPixelY(0, nr) - b->GridToPixelY(0, pr->mRow);
				Projectile* rb = b->AddProjectile(static_cast<int>(pr->mPosX) + 20, static_cast<int>(pr->mPosY) + dy, Board::MakeRenderOrder(RENDER_LAYER_PROJECTILE, nr, 0), nr, pr->mProjectileType);
				if (rb)
				{
					rb->mDamageRangeFlags = pr->mDamageRangeFlags;
					rb->mMod = pm;
					rb->mMod.mBackward = true;
					rb->mMod.mPierce = 0;
				}
			}
		}
	}

	bool ProjectileSkipZombie(Projectile* pr, Zombie* z)
	{
		const ProjectileModState& pm = pr->mMod;
		if (!pm.mInitialized || pm.mHitZombies[0] == 0) return false;
		unsigned int id = pr->mBoard->mZombies.DataArrayGetID(z);
		for (int i = 0; i < MOD_MAX_PIERCE_MEMORY; i++)
			if (pm.mHitZombies[i] == id) return true;
		return false;
	}

	bool ProjectileKeepAlive(Projectile* pr, Zombie* z)
	{
		ProjectileModState& pm = pr->mMod;
		if (!z || pm.mPierce <= 0 || !InPlay()) return false;
		if (!StraightMotion(pr) && pr->mMotionType != MOTION_HOMING && pr->mMotionType != MOTION_STAR) return false;
		pm.mPierce--;
		unsigned int id = pr->mBoard->mZombies.DataArrayGetID(z);
		for (int i = MOD_MAX_PIERCE_MEMORY - 1; i > 0; i--) pm.mHitZombies[i] = pm.mHitZombies[i - 1];
		pm.mHitZombies[0] = id;
		return true;
	}

	int PlantDamageOut(Plant* p, Zombie* z, int theDamage)
	{
		if (!InPlay() || !p->IsOnBoard()) return theDamage;
		PlantModState& m = p->mMod;
		SeedType s = p->mSeedType;
		float f = Opt(OPT_P_DAMAGE) * LevelDamage(p) * m.mComboDamage;
		if (m.mTrait == TRAIT_MIGHTY) f *= 1.35f;
		if (WeatherIs(WEATHER_DARK) && Plant::IsFungus(s)) f *= 1.2f;
		if (PlantAbilityOn(s) && z)
		{
			int br = PlantBranch(s);
			switch (s)
			{
			case SEED_FUMESHROOM:
				if (z->mShieldType != SHIELDTYPE_NONE) f *= 1.5f;
				if (br == 1) z->mMod.mPoison = std::max(z->mMod.mPoison, 200);
				if (br == 2) f *= 1.25f;
				break;
			case SEED_GLOOMSHROOM:
				f *= 1.3f;
				if (br == 1) z->mMod.mPoison = std::max(z->mMod.mPoison, 200);
				if (br == 2) f *= 1.3f;
				break;
			case SEED_SPIKEWEED:
				z->mMod.mPoison = std::max(z->mMod.mPoison, 200);
				if (br == 1) f *= 1.5f;
				if (br == 2) z->ApplyChill(false);
				break;
			case SEED_SPIKEROCK:
				z->mMod.mPoison = std::max(z->mMod.mPoison, 250);
				if (br == 2) f *= 1.5f;
				break;
			case SEED_CHOMPER:
				if (br == 2) return 400;
				break;
			default: break;
			}
		}
		int d = std::max(1, static_cast<int>(std::lround(theDamage * f)));
		AddPlantXP(p, d / 4 + 1);
		return d;
	}

	int PlantHitDamage(Plant* p, int theDamage)
	{
		if (!InPlay()) return theDamage;
		return PlantProtected(p) ? 0 : theDamage;
	}

	int KernelButterOdds(Plant* p)
	{
		if (!InPlay() || !PlantAbilityOn(SEED_KERNELPULT)) return 4;
		return (p->mMod.mCombos & (1 << PCOMBO_SALAD_BAR)) ? 2 : 3;
	}

	void ZombieHypnotized(Zombie* z)
	{
		if (!InPlay() || !PlantAbilityOn(SEED_HYPNOSHROOM)) return;
		int br = PlantBranch(SEED_HYPNOSHROOM);
		float f = br == 1 ? 3.0f : 2.0f;
		z->mBodyMaxHealth = static_cast<int>(z->mBodyMaxHealth * f);
		z->mBodyHealth = std::max(1, static_cast<int>(z->mBodyHealth * f));
		if (br == 2) { z->mMod.mAbilities |= AB_RAGE; z->mMod.mRageStacks = 25; }   // berserk ally: much faster
	}

	bool PlantSquishBlocked(Plant* p)
	{
		return InPlay() && PlantProtected(p);
	}

	bool PlantNoSleep() { return On(OPT_P_NO_SLEEP); }

	void PlantReanimAdjust(Plant* p, float& ox, float& oy, float& sx, float& sy)
	{
		if (!InPlay() || !p->IsOnBoard()) return;
		float s = Opt(OPT_P_SIZE);
		if (On(OPT_PA_XP) && p->mMod.mLevel >= 4) s *= 1.1f;
		if (p->mMod.mBoost > 0) s *= 1.0f + 0.06f * std::sin(gW.mTick * 0.3f);
		if (std::fabs(s - 1.0f) < 0.001f) return;
		ox += 40.0f * (1.0f - s);
		oy += 80.0f * (1.0f - s);
		sx *= s;
		sy *= s;
	}

	bool PlantColor(Plant* p, Color& c)
	{
		if (!InPlay() || !p->IsOnBoard() || !On(OPT_V_STATUS)) return false;
		if (c.mRed != 255 || c.mGreen != 255 || c.mBlue != 255) return false;
		const PlantModState& m = p->mMod;
		if (m.mFrozen > 0) { c = Color(140, 200, 255, c.mAlpha); return true; }
		if (m.mDisabled > 0) { c = Color(120, 120, 120, c.mAlpha); return true; }
		if (m.mPoison > 0) { c = Color(170, 255, 140, c.mAlpha); return true; }
		if (m.mBoost > 0) { int v = 200 + static_cast<int>(55 * std::sin(gW.mTick * 0.4f)); c = Color(v, 255, v, c.mAlpha); return true; }
		if (m.mSlowed > 0) { c = Color(200, 220, 255, c.mAlpha); return true; }
		if (m.mLevel >= 4 && On(OPT_PA_XP)) { c = Color(255, 240, 180, c.mAlpha); return true; }
		return false;
	}

	void PlantDraw(Plant* p, Graphics* g)
	{
		if (!InPlay() || !p->IsOnBoard() || !FONT_PICO129) return;
		const PlantModState& m = p->mMod;
		g->SetFont(FONT_PICO129);
		if (On(OPT_V_PLANT_BADGES) && On(OPT_PA_XP) && m.mLevel > 0)
		{
			for (int i = 0; i < m.mLevel; i++)
			{
				g->SetColor(m.mLevel >= 4 ? Color(255, 200, 40) : Color(255, 240, 120));
				g->FillRect(6 + i * 7, 70, 5, 5);
				g->SetColor(Color(120, 80, 0));
				g->DrawRect(6 + i * 7, 70, 5, 5);
			}
		}
		if (On(OPT_V_PLANT_BADGES) && m.mTrait >= 0)
		{
			std::string t = gModTraits[m.mTrait].mName;
			g->SetColor(Color(0, 0, 0, 140));
			g->FillRect(78 - FONT_PICO129->StringWidth(t) - 2, 0, FONT_PICO129->StringWidth(t) + 4, 9);
			g->SetColor(Color(200, 255, 255));
			g->DrawString(t, 78 - FONT_PICO129->StringWidth(t), 8);
		}
		if (On(OPT_V_STATUS))
		{
			std::string st;
			if (m.mFrozen > 0) st = "FROZEN";
			else if (m.mDisabled > 0) st = "DISABLED";
			else if (m.mPoison > 0) st = "POISON";
			else if (m.mRapidFire > 0) st = "RAPID";
			else if (m.mBoost > 0) st = "BOOST";
			if (m.mShield > 0 || gW.mPlantShieldTimer > 0)
			{
				g->SetColor(Color(255, 240, 120, 70));
				g->FillRect(4, 4, 72, 72);
			}
			if (!st.empty())
			{
				int w = FONT_PICO129->StringWidth(st);
				g->SetColor(Color(0, 0, 0, 150));
				g->FillRect(40 - w / 2 - 2, 56, w + 4, 10);
				g->SetColor(m.mFrozen > 0 ? Color(150, 220, 255) : m.mPoison > 0 ? Color(150, 255, 120) : Color(255, 230, 120));
				g->DrawString(st, 40 - w / 2, 64);
			}
		}
		if (m.mLevelUpFlash > 0)
		{
			g->SetColor(Color(255, 255, 200, m.mLevelUpFlash * 2));
			g->FillRect(0, 0, 80, 80);
		}
	}

	void PlantSpecial(Plant* p)
	{
		if (!InPlay() || !PlantAbilityOn(p->mSeedType)) return;
		Board* b = p->mBoard;
		int x = p->mX + p->mWidth / 2, y = p->mY + p->mHeight / 2;
		int flags = p->GetDamageRangeFlags(WEAPON_PRIMARY);
		int br = PlantBranch(p->mSeedType);
		switch (p->mSeedType)
		{
		case SEED_CHERRYBOMB:
			b->KillAllZombiesInRadius(p->mRow, x, y, br == 1 ? 210 : 160, br == 1 ? 2 : 1, true, flags);
			if (br == 2) { gW.mEmberRow = p->mRow; gW.mEmberTimer = 500; }
			break;
		case SEED_DOOMSHROOM:
			if (br == 1) b->KillAllZombiesInRadius(p->mRow, x, y, 350, 4, true, flags);
			if (GridItem* c = b->GetGridItemAt(GRIDITEM_CRATER, p->mPlantCol, p->mRow))
				c->mGridItemCounter = br == 2 ? 1 : 6000;
			break;
		case SEED_JALAPENO:
			for (int r = p->mRow - 1; r <= p->mRow + 1; r += 2)
			{
				if (r < 0 || r >= (b->StageHas6Rows() ? 6 : 5)) continue;
				if (br == 1) { b->DoFwoosh(r); p->BurnRow(r); }
				else
					for (Zombie* z : b->mZombies)
						if (IsLiveEnemy(z) && z->mRow == r) z->TakeDamage(200, 0U);
			}
			if (br == 2) { gW.mEmberRow = p->mRow; gW.mEmberTimer = 500; }
			break;
		case SEED_ICESHROOM:
			for (Zombie* z : b->mZombies)
			{
				if (!IsLiveEnemy(z)) continue;
				z->TakeDamage(40, 0U);
				if (z->mIceTrapCounter > 0) z->mIceTrapCounter = static_cast<int>(z->mIceTrapCounter * (br == 1 ? 2.0f : 1.5f));
			}
			if (br == 2) gW.mShatterTimer = 1200;
			break;
		case SEED_POTATOMINE:
			if (br == 1) b->KillAllZombiesInRadius(p->mRow, x - 20, y, 110, 1, false, flags);
			break;
		case SEED_SQUASH:
		{
			int dmg = br == 2 ? 600 : 300;
			float reach = br == 1 ? 170.0f : 100.0f;
			for (Zombie* z : b->mZombies)
				if (IsLiveEnemy(z) && std::abs(z->mRow - p->mRow) <= (br == 1 ? 1 : 0) && std::fabs(z->mPosX + 40 - x) < reach && std::fabs(z->mPosX + 40 - x) > 30)
					z->TakeDamage(dmg, 0U);
			if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(x, y + 30, p->mRenderOrder + 1, PARTICLE_DUST_SQUASH);
			ShakeIfAllowed(2, 2);
			break;
		}
		case SEED_BLOVER:
			if (p->mMod.mShotCount) break;
			p->mMod.mShotCount = 1;
			gW.mWeatherClearTimer = 3000;
			AddFloatingText(400, 120, "WEATHER CLEARED", 200, 255, 255, 1.1f);
			for (Zombie* z : b->mZombies)
			{
				if (!IsLiveEnemy(z)) continue;
				if (br == 1 && z->mPosX < 760 && z->mZombieType != ZOMBIE_BOSS && z->mMod.mBoss < 0) { z->mPosX = std::min(800.0f, z->mPosX + 60.0f); }
				if (br == 2) z->ApplyChill(false);
			}
			break;
		default:
			break;
		}
	}

	void PlantDigested(Plant* p)
	{
		if (!InPlay() || !PlantAbilityOn(SEED_CHOMPER)) return;
		p->mStateCountdown = static_cast<int>(p->mStateCountdown * (PlantBranch(SEED_CHOMPER) == 1 ? 0.3f : 0.6f));
	}

	void PlantShoveled(Plant* p)
	{
		if (!InPlay() || !On(OPT_E_SHOVEL_REFUND) || InfiniteSun()) return;
		int refund = Plant::GetCost(p->mSeedType, p->mImitaterType) / 2;
		if (refund > 0)
		{
			p->mBoard->AddSunMoney(refund);
			AddFloatingText(p->mX + 40.0f, static_cast<float>(p->mY), std::format("+{} refund", refund), 255, 240, 120, 0.9f);
		}
	}

	int AdjustCost(SeedType theSeed, int theCost)
	{
		if (!gApp || !gApp->mBoard) return theCost;
		if (InfiniteSun() || IsMode(MODE_SANDBOX)) return 0;
		float f = Opt(OPT_P_COST);
		if (IsMode(MODE_HARDCORE)) f *= 1.25f;
		return std::max(0, static_cast<int>(std::lround(theCost * f / 5.0f)) * 5);
	}

	int AdjustRefresh(SeedType theSeed, int theTime)
	{
		if (!gApp || !gApp->mBoard) return theTime;
		return std::max(0, static_cast<int>(theTime * Opt(OPT_P_COOLDOWN)));
	}

	void ApplyPlantFood(Plant* p)
	{
		if (!p || p->mDead) return;
		Board* b = p->mBoard;
		PlantModState& m = p->mMod;
		SeedType s = p->mSeedType;
		p->mPlantHealth = p->mPlantMaxHealth;
		m.mPoison = m.mFrozen = m.mDisabled = m.mSlowed = 0;
		m.mBoost = 300;
		if (IsSunPlant(s) || s == SEED_MARIGOLD)
		{
			int n = s == SEED_TWINSUNFLOWER ? 6 : 3;
			for (int i = 0; i < n; i++)
				b->AddCoin(p->mX + i * 6, p->mY, s == SEED_MARIGOLD ? COIN_GOLD : COIN_SUN, COIN_MOTION_FROM_PLANT);
		}
		else if (IsNut(s) || s == SEED_GARLIC)
		{
			p->mPlantMaxHealth = static_cast<int>(p->mPlantMaxHealth * 1.5f);
			p->mPlantHealth = p->mPlantMaxHealth;
			m.mShield = 600;
		}
		else if (s == SEED_POTATOMINE && p->mState == STATE_NOTREADY) p->mStateCountdown = 1;
		else if (s == SEED_CHOMPER && p->mState == STATE_CHOMPER_DIGESTING) p->mStateCountdown = 1;
		else if (s == SEED_MAGNETSHROOM && p->mState == STATE_MAGNETSHROOM_SUCKING) p->mStateCountdown = 1;
		else if (s == SEED_COBCANNON && p->mState == STATE_COBCANNON_ARMING) p->mStateCountdown = 1;
		else if (s == SEED_SPIKEWEED || s == SEED_SPIKEROCK)
		{
			for (Zombie* z : b->mZombies)
				if (IsLiveEnemy(z) && z->mRow == p->mRow) z->TakeDamage(200, 0U);
		}
		else if (!IsShooter(s)) m.mShield = 600;
		if (p->mIsAsleep) p->SetSleeping(false);
		AddPlantXP(p, 100);
		AddFloatingText(p->mX + 40.0f, p->mY - 5.0f, "PLANT FOOD!", 120, 255, 120, 1.1f);
		gApp->PlayFoley(FOLEY_PLANTGROW);
		if (On(OPT_V_ABILITY_FX)) gApp->AddPvzpParticle(p->mX + 40, p->mY + 40, p->mRenderOrder + 1, PARTICLE_PRESENT_PICKUP);
		gP.mPlantFoodUsed++;
		MarkProgressDirty();
	}
}
