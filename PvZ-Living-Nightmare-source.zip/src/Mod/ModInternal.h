// PvZ Living Nightmare - internal shared helpers (only included by src/Mod/*.cpp).
#ifndef __MOD_INTERNAL_H__
#define __MOD_INTERNAL_H__

#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include <format>

#include "../Lawn/BoardInclude.h"
#include "../Lawn/System/PlayerInfo.h"
#include "../PvzpLib/PvzpCommon.h"
#include "../PvzpLib/PvzpFoley.h"
#include "../PvzpLib/Reanimator.h"
#include "../PvzpLib/PvzpParticle.h"
#include "../PvzpLib/EffectSystem.h"
#include "graphics/Font.h"

#include "ModConfig.h"
#include "ModData.h"
#include "ModSystem.h"

using namespace Sexy;

namespace ModInt
{
	extern LawnApp* gApp;

	inline Board* GetBoard() { return gApp ? gApp->mBoard : nullptr; }
	bool  InPlay();                                    // board exists and the level is being played
	inline float Opt(int o) { return ModConfig::Get(o); }
	inline bool  On(int o) { return ModConfig::On(o); }
	inline int   OptI(int o) { return ModConfig::GetInt(o); }
	inline int   Mode() { return ModConfig::GetInt(OPT_M_MODE); }
	inline bool  IsMode(int m) { return Mode() == m; }
	inline bool  Chance(float thePercent) { return thePercent > 0.0f && Sexy::Rand(10000) < static_cast<int>(thePercent * 100.0f); }

	// ---- world state (ModWorld.cpp)
	struct FloatText { float x, y, vy; int life, maxLife; std::string text; uint8_t r, g, b; float scale; };
	struct Bolt { float x1, y1, x2, y2; int life; uint8_t r, g, b; };
	struct Meteor { float x, y, tx, ty; int life; bool hitsPlants; };
	struct WorldState
	{
		Board* mBoard = nullptr;
		bool   mInit = false;
		uint32_t mTick = 0;
		int    mWeather = 0;
		int    mPrevWeather = 0;
		float  mBlend = 1.0f;            // 0..1 transition progress to mWeather
		int    mWeatherTimer = 0;
		int    mEvent = 0;
		int    mEventTimer = 0;
		int    mLightningTimer = 0;
		int    mFlash = 0;
		uint8_t mFlashR = 255, mFlashG = 255, mFlashB = 255;
		int    mWeatherClearTimer = 0;   // Blover clears weather
		int    mWindDir = 1;
		int    mPlantFood = 0;
		bool   mPFArmed = false;
		int    mEndlessCycle = 0;
		int    mProgressGraves = 0;      // gravestones created by level progress
		int    mChaosTimer = 0;
		int    mPlantShieldTimer = 0;
		int    mShatterTimer = 0;
		int    mEmberRow = -1;
		int    mEmberTimer = 0;
		float  mAdaptive = 0.0f;
		int    mPlantsLost = 0;
		int    mLane = 2;
		bool   mMenuWasPaused = false;
		bool   mResultCounted = false;
		bool   mConsumedMouse = false;
		float  mSpeedAccum = 0.0f;
		std::vector<FloatText> mTexts;
		std::vector<Bolt>      mBolts;
		std::vector<Meteor>    mMeteors;
	};
	extern WorldState gW;
	extern std::string gActionMsg;
	bool  CustomWaveSpec(int theType, int& theVariant, int& theClass, int& theMutations);

	float WeatherAmount(int theWeather);     // effective strength 0..2 of a weather type right now
	inline bool WeatherIs(int theWeather) { return WeatherAmount(theWeather) > 0.05f; }
	bool  EventIs(int theEvent);
	void  AddBolt(float x1, float y1, float x2, float y2, int r, int g, int b);
	void  Flash(int r, int g, int b, int theTicks);
	void  ShakeIfAllowed(int x, int y);

	// ---- zombies (ModZombies.cpp)
	uint32_t Abilities(Zombie* z);
	inline bool Has(Zombie* z, uint32_t theAb) { return (Abilities(z) & theAb) != 0; }
	bool  IsSpecial(Zombie* z);
	bool  IsLiveEnemy(Zombie* z);
	float ClassPower(int theClass);
	void  FreezeZombie(Zombie* z, int theTicks);
	void  UpdateAuras(Board* b);
	void  BossInit(Zombie* z, int theBoss);
	void  BossUpdate(Zombie* z);
	int   BossDamage(Zombie* z, int theDamage, bool theExplosive);
	void  BossDeath(Zombie* z);
	std::string ZombieDisplayName(Zombie* z);
	void  LobAtPlant(Zombie* z, Plant* thePlant, ProjectileType theType);
	Plant* FindPlantAhead(Zombie* z, float theRange);

	// ---- plants (ModPlants.cpp)
	void  DamagePlant(Plant* p, int theDamage);
	void  FreezePlant(Plant* p, int theTicks);
	void  DisablePlant(Plant* p, int theTicks);
	void  HealPlant(Plant* p, int theAmount);
	int   PlantBranch(SeedType theSeed);       // 0 none, 1 A, 2 B (only when unlocked)
	bool  PlantAbilityOn(SeedType theSeed);
	void  AddPlantXP(Plant* p, int theXP);
	void  UpdatePlantCombos(Board* b);
	bool  PlantProtected(Plant* p);              // invulnerable right now
	bool  RevealedByPlantern(Zombie* z);
	void  DamagePlantsInRadius(float x, float y, float theRadius, int theDamage, bool thePoison, bool theFreeze);

	// ---- progress (ModProgress.cpp)
	struct WaveRecord { int mScore; int mWave; int mLevel; int mMode; int mZombies; int mSpecials; };
	struct Progress
	{
		int mTotalKills = 0;
		int mVariantKills[128] = {};
		int mVariantSeen[128] = {};
		int mClassKills[NUM_MOD_CLASSES] = {};
		int mMutationKills[NUM_MOD_MUTATIONS] = {};
		int mComboKills[NUM_MOD_COMBOS] = {};
		int mBossKills[NUM_MOD_BOSSES] = {};
		int mBossSeen[NUM_MOD_BOSSES] = {};
		int mPlantXP[NUM_SEED_TYPES] = {};
		int mMaxEndlessCycle = 0;
		int mMaxWave = 0;
		int mPlantFoodUsed = 0;
		int mEvolvedPlants = 0;
		int mLevelsWon = 0;
		int mLevelsLost = 0;
		int mLightningStrikes = 0;
		int mMaxDamageHit = 0;
		int mWeatherSeen[NUM_MOD_WEATHERS] = {};
		int mEventsSeen[NUM_MOD_EVENTS] = {};
		std::vector<WaveRecord> mHardestWaves;
	};
	extern Progress gP;
	void  ProgressLoad();
	void  ProgressSave();
	void  ProgressReset();
	void  RecordKill(Zombie* z);
	void  RecordWave(Board* b, int theWave);
	bool  VariantUnlocked(int theVariant);
	bool  VariantDiscovered(int theVariant);
	void  MarkProgressDirty();
	void  ProgressSaveIfDirty();

	// public mod API used unqualified inside the implementation
	using ModSystem::AddFloatingText;
	using ModSystem::SpawnZombie;
	using ModSystem::AddPlantFood;
	using ModSystem::GetPlantFood;
	using ModSystem::ApplyPlantFood;
	using ModSystem::InfiniteSun;
	using ModSystem::IsMenuOpen;
	using ModSystem::OpenMenu;
	using ModSystem::CloseMenu;
}

#endif
