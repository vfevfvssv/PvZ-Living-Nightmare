// PvZ Living Nightmare - option registry, persistence and defaults.
#ifndef __MOD_CONFIG_H__
#define __MOD_CONFIG_H__

#include <string>
#include <vector>
#include "ModData.h"

constexpr int MOD_PLANT_ABILITY_COUNT = 40;

enum ModCategory : int
{
	CAT_ZOMBIES, CAT_PLANTS, CAT_PLANT_ABILITIES, CAT_GAME, CAT_ECONOMY, CAT_LEVEL, CAT_MODES, CAT_CUSTOM_WAVES,
	CAT_VISUAL, CAT_DIFFICULTY, CAT_MUTATIONS, CAT_CLASSES, CAT_WEATHER, CAT_BOSSES, CAT_ABILITIES,
	CAT_EXPERIMENTAL, CAT_MISC,
	NUM_MOD_CATEGORIES
};
extern const char* const gModCategoryNames[NUM_MOD_CATEGORIES];

enum class ModOptType : uint8_t { Toggle, Slider, Select, Int, Action };

enum ModOpt : int
{
	// Zombie control
	OPT_Z_FREEZE, OPT_Z_HP, OPT_Z_SPEED, OPT_Z_BITE, OPT_Z_SIZE, OPT_Z_INVULN, OPT_Z_ONEHIT, OPT_Z_NOEAT,
	OPT_Z_IMMUNE_SLOW, OPT_Z_EXTRA_LOOT, OPT_Z_HYPNO_CHANCE, OPT_Z_MAX_ON_SCREEN, OPT_Z_REGEN,
	OPT_Z_SPAWN_TYPE, OPT_Z_SPAWN_COUNT, OPT_Z_SPAWN_ROW, OPT_Z_SPAWN_NOW, OPT_Z_VARIANT_SEL, OPT_Z_VARIANT_SPAWN,
	OPT_Z_KILL_ALL, OPT_Z_HYPNO_ALL, OPT_Z_PUSH_BACK, OPT_Z_STRIP_ARMOR, OPT_Z_BUTTER_ALL, OPT_Z_CHILL_ALL,
	// Plant control
	OPT_P_INVULN, OPT_P_DAMAGE, OPT_P_FIRERATE, OPT_P_HP, OPT_P_SIZE, OPT_P_NO_COOLDOWN, OPT_P_COOLDOWN, OPT_P_COST,
	OPT_P_PROJ_SPEED, OPT_P_PIERCE_ALL, OPT_P_CRIT, OPT_P_NO_SLEEP, OPT_P_HEAL_ALL, OPT_P_REGEN, OPT_P_UNLOCK_ALL, OPT_P_MAX_SLOTS,
	// Plant abilities / progression
	OPT_PA_ENABLE, OPT_PA_XP, OPT_PA_XP_MULT, OPT_PA_TRAITS, OPT_PA_COMBOS, OPT_PA_UNLOCK_UPGRADES, OPT_PA_EVOLVE_ALL,
	// Game modifiers
	OPT_G_SPEED, OPT_G_SLOWMO, OPT_G_PAUSE_SPAWN, OPT_G_NEXT_WAVE, OPT_G_WIN, OPT_G_NO_LOSE, OPT_G_INF_MOWERS,
	OPT_G_NO_MOWERS, OPT_G_RESTORE_MOWERS, OPT_G_AUTO_COLLECT, OPT_G_NO_SKY_SUN, OPT_G_SKY_SUN_RATE,
	OPT_G_PLANT_FOOD, OPT_G_INF_PF, OPT_G_PF_CHANCE, OPT_G_ADD_PF,
	// Economy
	OPT_E_INF_SUN, OPT_E_SUN_MULT, OPT_E_ADD_SUN, OPT_E_SUN_VALUE, OPT_E_SET_SUN, OPT_E_COIN_MULT, OPT_E_ADD_COINS,
	OPT_E_DIAMOND_CHANCE, OPT_E_SUN_PRODUCTION, OPT_E_START_SUN, OPT_E_SHOVEL_REFUND, OPT_E_KILL_SUN,
	// Level modification
	OPT_L_WAVES, OPT_L_POINTS, OPT_L_COUNTDOWN, OPT_L_RANDOM_TYPES, OPT_L_ENVIRONMENT, OPT_L_ADD_GRAVES,
	OPT_L_REMOVE_GRAVES, OPT_L_UNLOCK_MODES, OPT_L_ADV_LEVEL, OPT_L_SET_ADV_LEVEL,
	OPT_L_ALL_ZOMBIES, OPT_L_LIVING_GRAVES, OPT_L_GRAVE_MAX, OPT_L_GRAVE_RISE,
	// Game modes
	OPT_M_MODE, OPT_M_LANE, OPT_M_ENDLESS_SCALE,
	// Custom waves
	OPT_CW_TYPE1, OPT_CW_COUNT1, OPT_CW_TYPE2, OPT_CW_COUNT2, OPT_CW_TYPE3, OPT_CW_COUNT3, OPT_CW_TYPE4, OPT_CW_COUNT4,
	OPT_CW_VARIANTS, OPT_CW_CLASS, OPT_CW_MUTATION, OPT_CW_SPAWN, OPT_CW_REPLACE,
	// Visual
	OPT_V_HP_BARS, OPT_V_DMG_NUMBERS, OPT_V_BOSS_BAR, OPT_V_ICONS, OPT_V_WEATHER_FX, OPT_V_SHAKE, OPT_V_ABILITY_FX,
	OPT_V_FLASH, OPT_V_HUD, OPT_V_TINTS, OPT_V_PLANT_BADGES, OPT_V_STATUS, OPT_V_LOW_FX,
	// Difficulty
	OPT_D_PRESET, OPT_D_VARIANTS, OPT_D_VARIANT_CHANCE, OPT_D_UNLOCK_VARIANTS, OPT_D_ADAPTIVE,
	// Mutations
	OPT_MU_ENABLE, OPT_MU_CHANCE, OPT_MU_MAX, OPT_MU_COMBOS,
	// Classes
	OPT_CL_ENABLE, OPT_CL_CHANCE, OPT_CL_SYNERGY,
	// Weather
	OPT_W_ENABLE, OPT_W_MODE, OPT_W_TYPE, OPT_W_INTENSITY, OPT_W_INTERVAL, OPT_W_RARE, OPT_W_NEXT, OPT_W_TRIGGER_RARE,
	// Bosses
	OPT_B_SELECT, OPT_B_SPAWN, OPT_B_HP, OPT_B_FINAL_CHANCE,
	// Special abilities
	OPT_S_LIGHTNING, OPT_S_METEOR, OPT_S_FREEZE, OPT_S_SUN_RAIN, OPT_S_SHIELD, OPT_S_QUAKE, OPT_S_MOWERS, OPT_S_PF_ALL,
	OPT_S_COINS, OPT_S_BLIZZARD, OPT_S_FIRESTORM, OPT_S_GRAVITY,
	// Experimental
	OPT_X_LANE_SWITCH, OPT_X_BACKFIRE, OPT_X_CHAIN_EXPLODE, OPT_X_CHAOS, OPT_X_ALLY_CHANCE, OPT_X_RICOCHET, OPT_X_LIFESTEAL,
	// Misc
	OPT_MI_RESET, OPT_MI_SAVE, OPT_MI_RESET_STATS, OPT_MI_BUTTON_POS, OPT_MI_AUTOPAUSE,
	NUM_CORE_OPTS,

	// Generated ranges
	OPT_MUT_ON_0   = NUM_CORE_OPTS,
	OPT_MUT_W_0    = OPT_MUT_ON_0 + NUM_MOD_MUTATIONS,
	OPT_CL_ON_0    = OPT_MUT_W_0 + NUM_MOD_MUTATIONS,
	OPT_CL_POWER_0 = OPT_CL_ON_0 + NUM_MOD_CLASSES,
	OPT_PAB_0      = OPT_CL_POWER_0 + NUM_MOD_CLASSES,
	OPT_PBR_0      = OPT_PAB_0 + MOD_PLANT_ABILITY_COUNT,
	NUM_MOD_OPTS   = OPT_PBR_0 + MOD_PLANT_ABILITY_COUNT
};

struct ModOptionDef
{
	std::string              mKey;
	std::string              mLabel;
	std::string              mDesc;
	int                      mCategory = 0;
	ModOptType               mType = ModOptType::Toggle;
	float                    mMin = 0.0f, mMax = 1.0f, mStep = 1.0f, mDefault = 0.0f;
	std::vector<std::string> mChoices;
	bool                     mIsFunction = true;   // counted as a distinct mod function
};

namespace ModConfig
{
	void                Init();                   // builds option table + loads config
	const ModOptionDef& Def(int theOpt);
	float               Get(int theOpt);
	inline bool         On(int theOpt) { return Get(theOpt) > 0.5f; }
	inline int          GetInt(int theOpt) { float v = Get(theOpt); return static_cast<int>(v >= 0 ? v + 0.5f : v - 0.5f); }
	void                Set(int theOpt, float theValue);
	void                ResetAll();
	void                Load();
	void                Save();
	void                SaveIfDirty();
	bool                IsDirty();
	int                 CountFunctions();
	std::string         FormatValue(int theOpt);
	std::string         ConfigPath();
}

#endif
