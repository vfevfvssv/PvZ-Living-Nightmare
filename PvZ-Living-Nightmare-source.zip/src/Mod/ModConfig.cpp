// PvZ Living Nightmare - option registry, persistence and defaults.
#include "ModConfig.h"
#include "ModSystem.h"
#include "../SexyAppFramework/Common.h"

using Sexy::PathFromU8;

#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <format>
#include <fstream>
#include <sstream>
#include <algorithm>

static_assert(MOD_PLANT_ABILITY_COUNT == 40, "update MOD_PLANT_ABILITY_COUNT when editing gModPlantAbilities");

const char* const gModCategoryNames[NUM_MOD_CATEGORIES] = {
	"Zombie Control", "Plant Control", "Plant Abilities & Upgrades", "Game Modifiers", "Economy & Resources",
	"Level Modification", "Game Modes", "Custom Waves", "Visual Settings", "Difficulty", "Mutations",
	"Zombie Classes", "Weather & Environment", "Bosses", "Special Abilities", "Experimental", "Miscellaneous"
};

namespace
{
	std::vector<ModOptionDef> sDefs;
	std::vector<float>        sValues;
	bool                      sDirty = false;
	bool                      sInit = false;

	ModOptionDef& At(int theOpt, const char* theKey, const char* theLabel, int theCat, ModOptType theType, const char* theDesc)
	{
		ModOptionDef& d = sDefs[theOpt];
		d.mKey = theKey;
		d.mLabel = theLabel;
		d.mCategory = theCat;
		d.mType = theType;
		d.mDesc = theDesc ? theDesc : "";
		return d;
	}
	void T(int o, const char* k, const char* l, int c, bool def, const char* desc)
	{
		ModOptionDef& d = At(o, k, l, c, ModOptType::Toggle, desc);
		d.mMin = 0; d.mMax = 1; d.mStep = 1; d.mDefault = def ? 1.0f : 0.0f;
	}
	void S(int o, const char* k, const char* l, int c, float mn, float mx, float st, float def, const char* desc)
	{
		ModOptionDef& d = At(o, k, l, c, ModOptType::Slider, desc);
		d.mMin = mn; d.mMax = mx; d.mStep = st; d.mDefault = def;
	}
	void I(int o, const char* k, const char* l, int c, int mn, int mx, int st, int def, const char* desc, bool isFunc = true)
	{
		ModOptionDef& d = At(o, k, l, c, ModOptType::Int, desc);
		d.mMin = (float)mn; d.mMax = (float)mx; d.mStep = (float)st; d.mDefault = (float)def; d.mIsFunction = isFunc;
	}
	void A(int o, const char* k, const char* l, int c, const char* desc)
	{
		ModOptionDef& d = At(o, k, l, c, ModOptType::Action, desc);
		d.mMin = 0; d.mMax = 0; d.mDefault = 0;
	}
	void C(int o, const char* k, const char* l, int c, std::vector<std::string> choices, int def, const char* desc, bool isFunc = true)
	{
		ModOptionDef& d = At(o, k, l, c, ModOptType::Select, desc);
		d.mChoices = std::move(choices);
		d.mMin = 0; d.mMax = (float)(d.mChoices.size() - 1); d.mStep = 1; d.mDefault = (float)def; d.mIsFunction = isFunc;
	}

	std::vector<std::string> ZombieChoices(bool withNone)
	{
		std::vector<std::string> v;
		if (withNone) v.push_back("None");
		for (int i = 0; i < NUM_MOD_SPAWNABLE_ZOMBIES; i++) v.push_back(gModSpawnableZombieNames[i]);
		return v;
	}

	void BuildDefs()
	{
		sDefs.assign(NUM_MOD_OPTS, ModOptionDef());

		// ---------------- Zombie control
		T(OPT_Z_FREEZE,      "z_freeze",      "Freeze all zombies", CAT_ZOMBIES, false, "Zombies stop moving, eating and animating.");
		S(OPT_Z_HP,          "z_hp",          "Zombie health x", CAT_ZOMBIES, 0.1f, 10.0f, 0.1f, 1.0f, "Health multiplier for newly spawned zombies.");
		S(OPT_Z_SPEED,       "z_speed",       "Zombie speed x", CAT_ZOMBIES, 0.1f, 5.0f, 0.1f, 1.0f, "Movement speed multiplier (applies instantly).");
		S(OPT_Z_BITE,        "z_bite",        "Zombie bite damage x", CAT_ZOMBIES, 0.0f, 10.0f, 0.1f, 1.0f, "Damage zombies deal to plants.");
		S(OPT_Z_SIZE,        "z_size",        "Zombie size x", CAT_ZOMBIES, 0.5f, 2.0f, 0.05f, 1.0f, "Visual size of newly spawned zombies.");
		T(OPT_Z_INVULN,      "z_invuln",      "Invulnerable zombies", CAT_ZOMBIES, false, "Zombies take no damage.");
		T(OPT_Z_ONEHIT,      "z_onehit",      "One-hit kill", CAT_ZOMBIES, false, "Any hit destroys a zombie.");
		T(OPT_Z_NOEAT,       "z_noeat",       "Zombies cannot eat", CAT_ZOMBIES, false, "Zombies stop at plants but deal no damage.");
		T(OPT_Z_IMMUNE_SLOW, "z_noslow",      "Zombies immune to slow", CAT_ZOMBIES, false, "Snow peas and ice no longer slow zombies.");
		T(OPT_Z_EXTRA_LOOT,  "z_loot",        "Extra loot", CAT_ZOMBIES, false, "Every defeated zombie drops a coin.");
		S(OPT_Z_HYPNO_CHANCE,"z_hypno_hit",   "Hypno rounds chance %", CAT_ZOMBIES, 0.0f, 50.0f, 1.0f, 0.0f, "Chance a projectile hit hypnotizes the zombie.");
		I(OPT_Z_MAX_ON_SCREEN,"z_cap",        "Max zombies on lawn (0=off)", CAT_ZOMBIES, 0, 200, 5, 0, "Extra spawns are skipped above this number.");
		T(OPT_Z_REGEN,       "z_regen",       "All zombies regenerate", CAT_ZOMBIES, false, "Every zombie slowly regenerates health.");
		C(OPT_Z_SPAWN_TYPE,  "z_spawn_type",  "Spawn: zombie type", CAT_ZOMBIES, ZombieChoices(false), 0, "Zombie type used by 'Spawn zombies now'.", false);
		I(OPT_Z_SPAWN_COUNT, "z_spawn_count", "Spawn: amount", CAT_ZOMBIES, 1, 30, 1, 1, "How many zombies to spawn.", false);
		C(OPT_Z_SPAWN_ROW,   "z_spawn_row",   "Spawn: lane", CAT_ZOMBIES, {"Random","Lane 1","Lane 2","Lane 3","Lane 4","Lane 5","Lane 6"}, 0, "Lane for spawned zombies.", false);
		A(OPT_Z_SPAWN_NOW,   "z_spawn_now",   "Spawn zombies now", CAT_ZOMBIES, "Spawns the selected zombie type.");
		{
			std::vector<std::string> v;
			for (int i = 0; i < NUM_MOD_VARIANTS; i++) v.push_back(gModVariants[i].mName);
			C(OPT_Z_VARIANT_SEL, "z_variant_sel", "Spawn: variant", CAT_ZOMBIES, v, 0, "Variant used by 'Spawn variant now'.", false);
		}
		A(OPT_Z_VARIANT_SPAWN,"z_variant_now","Spawn variant now", CAT_ZOMBIES, "Spawns the selected zombie variant.");
		A(OPT_Z_KILL_ALL,    "z_kill_all",    "Kill all zombies", CAT_ZOMBIES, "Instantly defeats every zombie on the lawn.");
		A(OPT_Z_HYPNO_ALL,   "z_hypno_all",   "Hypnotize all zombies", CAT_ZOMBIES, "Every zombie joins your side.");
		A(OPT_Z_PUSH_BACK,   "z_push_back",   "Push zombies back", CAT_ZOMBIES, "Knocks every zombie back two tiles.");
		A(OPT_Z_STRIP_ARMOR, "z_strip",       "Strip all armor", CAT_ZOMBIES, "Removes helmets and shields.");
		A(OPT_Z_BUTTER_ALL,  "z_butter",      "Butter all zombies", CAT_ZOMBIES, "Immobilizes every zombie for 4 seconds.");
		A(OPT_Z_CHILL_ALL,   "z_chill",       "Chill all zombies", CAT_ZOMBIES, "Slows every zombie.");

		// ---------------- Plant control
		T(OPT_P_INVULN,      "p_invuln",      "Invulnerable plants", CAT_PLANTS, false, "Plants cannot be eaten, crushed or damaged.");
		S(OPT_P_DAMAGE,      "p_damage",      "Plant damage x", CAT_PLANTS, 0.1f, 10.0f, 0.1f, 1.0f, "Damage of plant projectiles.");
		S(OPT_P_FIRERATE,    "p_firerate",    "Plant fire rate x", CAT_PLANTS, 0.25f, 5.0f, 0.05f, 1.0f, "How often shooters fire.");
		S(OPT_P_HP,          "p_hp",          "Plant health x", CAT_PLANTS, 0.25f, 10.0f, 0.25f, 1.0f, "Health of newly planted plants.");
		S(OPT_P_SIZE,        "p_size",        "Plant size x", CAT_PLANTS, 0.6f, 1.5f, 0.05f, 1.0f, "Visual size of plants.");
		T(OPT_P_NO_COOLDOWN, "p_nocd",        "Instant recharge", CAT_PLANTS, false, "Seed packets recharge immediately.");
		S(OPT_P_COOLDOWN,    "p_cd",          "Recharge time x", CAT_PLANTS, 0.0f, 3.0f, 0.05f, 1.0f, "Seed packet recharge time multiplier.");
		S(OPT_P_COST,        "p_cost",        "Plant cost x", CAT_PLANTS, 0.0f, 3.0f, 0.05f, 1.0f, "Sun cost multiplier.");
		S(OPT_P_PROJ_SPEED,  "p_proj",        "Projectile speed x", CAT_PLANTS, 0.25f, 4.0f, 0.05f, 1.0f, "Speed of straight-flying projectiles.");
		T(OPT_P_PIERCE_ALL,  "p_pierce",      "All shots pierce", CAT_PLANTS, false, "Straight projectiles pass through 3 zombies.");
		S(OPT_P_CRIT,        "p_crit",        "Critical hit chance %", CAT_PLANTS, 0.0f, 100.0f, 1.0f, 0.0f, "Critical hits deal double damage.");
		T(OPT_P_NO_SLEEP,    "p_nosleep",     "Mushrooms never sleep", CAT_PLANTS, false, "Mushrooms work during the day.");
		A(OPT_P_HEAL_ALL,    "p_heal",        "Heal all plants", CAT_PLANTS, "Restores every plant to full health.");
		T(OPT_P_REGEN,       "p_regen",       "Plants regenerate", CAT_PLANTS, false, "Plants slowly recover health.");
		T(OPT_P_UNLOCK_ALL,  "p_unlock",      "Unlock all plants", CAT_PLANTS, false, "Every plant is available in the seed chooser.");
		T(OPT_P_MAX_SLOTS,   "p_slots",       "10 seed slots", CAT_PLANTS, false, "Always use the maximum number of seed slots.");

		// ---------------- Plant abilities
		T(OPT_PA_ENABLE,     "pa_enable",     "New plant abilities", CAT_PLANT_ABILITIES, true, "Master switch for all new plant abilities.");
		T(OPT_PA_XP,         "pa_xp",         "Plant experience & levels", CAT_PLANT_ABILITIES, true, "Plants level up (1-5) by dealing damage.");
		S(OPT_PA_XP_MULT,    "pa_xp_mult",    "Experience gain x", CAT_PLANT_ABILITIES, 0.1f, 10.0f, 0.1f, 1.0f, "Speed of plant level-ups.");
		T(OPT_PA_TRAITS,     "pa_traits",     "Random plant traits", CAT_PLANT_ABILITIES, true, "20% of plants get a random rare trait.");
		T(OPT_PA_COMBOS,     "pa_combos",     "Plant combinations", CAT_PLANT_ABILITIES, true, "Bonuses for specific plant arrangements.");
		T(OPT_PA_UNLOCK_UPGRADES,"pa_unlock", "Unlock all upgrade branches", CAT_PLANT_ABILITIES, false, "Branches normally unlock with plant experience.");
		A(OPT_PA_EVOLVE_ALL, "pa_evolve",     "Evolve all plants now", CAT_PLANT_ABILITIES, "Every plant on the lawn reaches level 5 (evolved form).");

		// ---------------- Game modifiers
		S(OPT_G_SPEED,       "g_speed",       "Game speed x", CAT_GAME, 0.25f, 4.0f, 0.25f, 1.0f, "Speeds up or slows down the whole game.");
		T(OPT_G_SLOWMO,      "g_slowmo",      "Slow motion", CAT_GAME, false, "Halves the game speed.");
		T(OPT_G_PAUSE_SPAWN, "g_nospawn",     "Pause zombie waves", CAT_GAME, false, "No new waves arrive.");
		A(OPT_G_NEXT_WAVE,   "g_nextwave",    "Next wave now", CAT_GAME, "The next wave arrives immediately.");
		A(OPT_G_WIN,         "g_win",         "Win level now", CAT_GAME, "Ends the level with a victory.");
		T(OPT_G_NO_LOSE,     "g_nolose",      "Zombies cannot win", CAT_GAME, false, "Zombies reaching the house are destroyed.");
		T(OPT_G_INF_MOWERS,  "g_infmowers",   "Infinite lawn mowers", CAT_GAME, false, "Used lawn mowers come back.");
		T(OPT_G_NO_MOWERS,   "g_nomowers",    "No lawn mowers", CAT_GAME, false, "Removes lawn mowers at level start.");
		A(OPT_G_RESTORE_MOWERS,"g_restore",   "Restore lawn mowers", CAT_GAME, "Puts back every missing lawn mower.");
		T(OPT_G_AUTO_COLLECT,"g_autocollect", "Auto-collect sun & coins", CAT_GAME, false, "Sun and coins are collected automatically.");
		T(OPT_G_NO_SKY_SUN,  "g_noskysun",    "No falling sun", CAT_GAME, false, "Sun no longer falls from the sky.");
		S(OPT_G_SKY_SUN_RATE,"g_skysun",      "Falling sun rate x", CAT_GAME, 0.25f, 5.0f, 0.25f, 1.0f, "How often sun falls from the sky.");
		T(OPT_G_PLANT_FOOD,  "g_pf",          "Plant Food system", CAT_GAME, true, "Glowing zombies drop Plant Food; tap PF then a plant.");
		T(OPT_G_INF_PF,      "g_inf_pf",      "Infinite Plant Food", CAT_GAME, false, "Plant Food never runs out.");
		S(OPT_G_PF_CHANCE,   "g_pf_chance",   "Glowing zombie chance %", CAT_GAME, 0.0f, 50.0f, 1.0f, 5.0f, "Chance a zombie glows and drops Plant Food.");
		A(OPT_G_ADD_PF,      "g_add_pf",      "Add 3 Plant Food", CAT_GAME, "Adds three Plant Food charges.");

		// ---------------- Economy
		T(OPT_E_INF_SUN,     "e_infsun",      "Infinite sun", CAT_ECONOMY, false, "Planting costs nothing; sun stays at 9990.");
		S(OPT_E_SUN_MULT,    "e_sunmult",     "Collected sun x", CAT_ECONOMY, 0.5f, 10.0f, 0.5f, 1.0f, "Multiplies the value of collected sun.");
		A(OPT_E_ADD_SUN,     "e_addsun",      "Add 1000 sun", CAT_ECONOMY, "Adds 1000 sun.");
		I(OPT_E_SUN_VALUE,   "e_sunvalue",    "Sun amount to set", CAT_ECONOMY, 0, 9990, 50, 500, "Used by 'Set sun'.", false);
		A(OPT_E_SET_SUN,     "e_setsun",      "Set sun", CAT_ECONOMY, "Sets your sun to the amount above.");
		S(OPT_E_COIN_MULT,   "e_coinmult",    "Coin value x", CAT_ECONOMY, 1.0f, 10.0f, 1.0f, 1.0f, "Multiplies silver, gold and diamond value.");
		A(OPT_E_ADD_COINS,   "e_addcoins",    "Add $10,000", CAT_ECONOMY, "Adds money for Crazy Dave's shop.");
		S(OPT_E_DIAMOND_CHANCE,"e_diamond",   "Diamond drop chance %", CAT_ECONOMY, 0.0f, 25.0f, 0.5f, 0.0f, "Chance a defeated zombie drops a diamond.");
		S(OPT_E_SUN_PRODUCTION,"e_sunprod",   "Sun plant speed x", CAT_ECONOMY, 0.25f, 5.0f, 0.25f, 1.0f, "How fast sunflowers produce sun.");
		I(OPT_E_START_SUN,   "e_startsun",    "Starting sun (0=default)", CAT_ECONOMY, 0, 9990, 50, 0, "Sun at the start of every level.");
		T(OPT_E_SHOVEL_REFUND,"e_refund",     "Shovel refund 50%", CAT_ECONOMY, false, "Digging up a plant returns half its cost.");
		T(OPT_E_KILL_SUN,    "e_killsun",     "Sun for kills", CAT_ECONOMY, false, "Every defeated zombie gives 10 sun.");

		// ---------------- Level
		I(OPT_L_WAVES,       "l_waves",       "Number of waves (0=default)", CAT_LEVEL, 0, 100, 1, 0, "Overrides the number of waves in a level.");
		S(OPT_L_POINTS,      "l_points",      "Wave size x", CAT_LEVEL, 0.25f, 5.0f, 0.25f, 1.0f, "Multiplies how many zombies each wave has.");
		S(OPT_L_COUNTDOWN,   "l_countdown",   "Time between waves x", CAT_LEVEL, 0.1f, 3.0f, 0.1f, 1.0f, "Lower = faster waves.");
		T(OPT_L_RANDOM_TYPES,"l_randtypes",   "Random zombie types", CAT_LEVEL, false, "Each level picks a random set of zombie types.");
		C(OPT_L_ENVIRONMENT, "l_env",         "Environment", CAT_LEVEL, {"Default","Day","Night","Pool","Fog","Roof"}, 0, "Forces the lawn type at level start.");
		A(OPT_L_ADD_GRAVES,  "l_addgraves",   "Add 5 graves", CAT_LEVEL, "Places gravestones on the lawn.");
		A(OPT_L_REMOVE_GRAVES,"l_rmgraves",   "Remove all graves", CAT_LEVEL, "Removes every gravestone and crater.");
		T(OPT_L_UNLOCK_MODES,"l_unlockmodes", "Unlock all mini-games & puzzles", CAT_LEVEL, false, "Unlocks every mini-game, puzzle and survival level.");
		I(OPT_L_ADV_LEVEL,   "l_advlevel",    "Adventure level (1-50)", CAT_LEVEL, 1, 50, 1, 1, "Used by 'Jump to adventure level'.", false);
		A(OPT_L_SET_ADV_LEVEL,"l_setadv",     "Jump to adventure level", CAT_LEVEL, "Sets your adventure progress to the level above.");
		T(OPT_L_ALL_ZOMBIES, "l_allzombies",  "All zombies on all levels", CAT_LEVEL, true, "All zombie types, Zombotany included, can appear in any level except Dr. Zomboss.");
		T(OPT_L_LIVING_GRAVES,"l_livinggraves","Graves grow during levels", CAT_LEVEL, true, "New gravestones push out of the lawn during every level (not Dr. Zomboss).");
		I(OPT_L_GRAVE_MAX,   "l_gravemax",    "Max graves from progress", CAT_LEVEL, 1, 20, 1, 8, "Limit for the gravestones created by level progress.");
		T(OPT_L_GRAVE_RISE,  "l_graverise",   "Zombies rise from graves", CAT_LEVEL, true, "On flag waves and the final wave zombies climb out of the gravestones.");

		// ---------------- Game modes
		{
			std::vector<std::string> v;
			for (int i = 0; i < NUM_MOD_GAME_MODES; i++) v.push_back(gModGameModes[i].mName);
			C(OPT_M_MODE, "m_mode", "Game mode", CAT_MODES, v, 0, "Applied when the next level starts.");
		}
		C(OPT_M_LANE,        "m_lane",        "Single Lane: lane", CAT_MODES, {"Lane 1","Lane 2","Lane 3","Lane 4","Lane 5","Lane 6"}, 2, "Lane used by the Single Lane mode.", false);
		S(OPT_M_ENDLESS_SCALE,"m_endless",    "Endless: health growth %/cycle", CAT_MODES, 0.0f, 100.0f, 5.0f, 20.0f, "How much tougher zombies get each endless cycle.");

		// ---------------- Custom waves
		{
			const int t[4] = { OPT_CW_TYPE1, OPT_CW_TYPE2, OPT_CW_TYPE3, OPT_CW_TYPE4 };
			const int c[4] = { OPT_CW_COUNT1, OPT_CW_COUNT2, OPT_CW_COUNT3, OPT_CW_COUNT4 };
			static const char* tk[4] = { "cw_t1", "cw_t2", "cw_t3", "cw_t4" };
			static const char* ck[4] = { "cw_c1", "cw_c2", "cw_c3", "cw_c4" };
			static const char* tl[4] = { "Group 1: zombie", "Group 2: zombie", "Group 3: zombie", "Group 4: zombie" };
			static const char* cl[4] = { "Group 1: amount", "Group 2: amount", "Group 3: amount", "Group 4: amount" };
			for (int i = 0; i < 4; i++)
			{
				C(t[i], tk[i], tl[i], CAT_CUSTOM_WAVES, ZombieChoices(true), i == 0 ? 1 : 0, "Zombie type of this group.", false);
				I(c[i], ck[i], cl[i], CAT_CUSTOM_WAVES, 0, 20, 1, i == 0 ? 5 : 0, "Zombies in this group.", false);
			}
		}
		C(OPT_CW_VARIANTS,   "cw_variants",   "Variants", CAT_CUSTOM_WAVES, {"Off","Random","Always"}, 1, "Whether custom wave zombies get variants.", false);
		{
			std::vector<std::string> v = {"Random","None"};
			for (int i = 0; i < NUM_MOD_CLASSES; i++) v.push_back(gModClasses[i].mName);
			C(OPT_CW_CLASS, "cw_class", "Class", CAT_CUSTOM_WAVES, v, 0, "Class selection for custom waves.", false);
		}
		{
			std::vector<std::string> v = {"Random","None"};
			for (int i = 0; i < NUM_MOD_MUTATIONS; i++) v.push_back(gModMutations[i].mName);
			C(OPT_CW_MUTATION, "cw_mutation", "Mutation", CAT_CUSTOM_WAVES, v, 0, "Mutation for custom waves.", false);
		}
		A(OPT_CW_SPAWN,      "cw_spawn",      "Spawn custom wave now", CAT_CUSTOM_WAVES, "Spawns the configured groups.");
		T(OPT_CW_REPLACE,    "cw_replace",    "Add custom wave to flag waves", CAT_CUSTOM_WAVES, false, "Every flag wave also spawns the custom groups.");

		// ---------------- Visual
		T(OPT_V_HP_BARS,     "v_hpbars",      "Health bars", CAT_VISUAL, true, "Health bars for special zombies (or all, when damaged).");
		T(OPT_V_DMG_NUMBERS, "v_dmgnum",      "Damage numbers", CAT_VISUAL, true, "Floating damage numbers.");
		T(OPT_V_BOSS_BAR,    "v_bossbar",     "Boss health bar", CAT_VISUAL, true, "Large boss health bar at the top.");
		T(OPT_V_ICONS,       "v_icons",       "Class & mutation tags", CAT_VISUAL, true, "Shows tags above special zombies.");
		T(OPT_V_WEATHER_FX,  "v_weather",     "Weather visuals", CAT_VISUAL, true, "Rain, snow, fog and lightning drawing.");
		T(OPT_V_SHAKE,       "v_shake",       "Screen shake", CAT_VISUAL, true, "Shakes the screen on big explosions.");
		T(OPT_V_ABILITY_FX,  "v_abilityfx",   "Ability effects", CAT_VISUAL, true, "Particles for zombie and plant abilities.");
		T(OPT_V_FLASH,       "v_flash",       "Screen flashes", CAT_VISUAL, true, "Flashes for lightning and bosses.");
		T(OPT_V_HUD,         "v_hud",         "Mod info panel", CAT_VISUAL, true, "Shows mode, weather and Plant Food.");
		T(OPT_V_TINTS,       "v_tints",       "Variant colors", CAT_VISUAL, true, "Colors special zombies.");
		T(OPT_V_PLANT_BADGES,"v_badges",      "Plant level stars", CAT_VISUAL, true, "Shows plant levels.");
		T(OPT_V_STATUS,      "v_status",      "Status indicators", CAT_VISUAL, true, "Shows poisoned, frozen, boosted states.");
		T(OPT_V_LOW_FX,      "v_lowfx",       "Low effects mode", CAT_VISUAL, false, "Fewer particles for slower phones.");

		// ---------------- Difficulty
		C(OPT_D_PRESET,      "d_preset",      "Difficulty preset", CAT_DIFFICULTY, {"Custom","Easy","Normal","Hard","Insane","Nightmare"}, 0, "Sets several difficulty values at once.");
		T(OPT_D_VARIANTS,    "d_variants",    "Zombie variants", CAT_DIFFICULTY, true, "Allows the 69 new zombie variants to appear.");
		S(OPT_D_VARIANT_CHANCE,"d_varchance", "Variant chance %", CAT_DIFFICULTY, 0.0f, 100.0f, 1.0f, 15.0f, "Chance a zombie becomes a variant.");
		T(OPT_D_UNLOCK_VARIANTS,"d_unlockvar","Unlock all variants", CAT_DIFFICULTY, false, "Variants normally unlock with total kills.");
		T(OPT_D_ADAPTIVE,    "d_adaptive",    "Adaptive difficulty", CAT_DIFFICULTY, false, "The better you play, the more specials appear.");

		// ---------------- Mutations
		T(OPT_MU_ENABLE,     "mu_enable",     "Mutations", CAT_MUTATIONS, true, "Zombies can mutate randomly.");
		S(OPT_MU_CHANCE,     "mu_chance",     "Mutation chance %", CAT_MUTATIONS, 0.0f, 100.0f, 1.0f, 8.0f, "Chance each zombie mutates.");
		I(OPT_MU_MAX,        "mu_max",        "Max mutations per zombie", CAT_MUTATIONS, 1, 4, 1, 2, "Zombies can stack several mutations.");
		T(OPT_MU_COMBOS,     "mu_combos",     "Special mutation combos", CAT_MUTATIONS, true, "Compatible pairs become special mutations.");
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
		{
			ModOptionDef& on = sDefs[OPT_MUT_ON_0 + i];
			on.mKey = std::format("mut_on_{}", i);
			on.mLabel = std::format("Mutation: {}", gModMutations[i].mName);
			on.mDesc = gModMutations[i].mDesc;
			on.mCategory = CAT_MUTATIONS; on.mType = ModOptType::Toggle; on.mDefault = 1;
			ModOptionDef& w = sDefs[OPT_MUT_W_0 + i];
			w.mKey = std::format("mut_w_{}", i);
			w.mLabel = std::format("{} probability", gModMutations[i].mName);
			w.mDesc = "Relative weight when a mutation is rolled (rare = low).";
			w.mCategory = CAT_MUTATIONS; w.mType = ModOptType::Slider; w.mMin = 0; w.mMax = 200; w.mStep = 5;
			w.mDefault = (float)gModMutations[i].mDefaultWeight; w.mIsFunction = false;
		}

		// ---------------- Classes
		T(OPT_CL_ENABLE,     "cl_enable",     "Zombie classes", CAT_CLASSES, true, "Zombies can spawn with a class role.");
		S(OPT_CL_CHANCE,     "cl_chance",     "Class chance %", CAT_CLASSES, 0.0f, 100.0f, 1.0f, 10.0f, "Chance a zombie gets a class.");
		T(OPT_CL_SYNERGY,    "cl_synergy",    "Class cooperation", CAT_CLASSES, true, "Classes boost each other (Tank+Healer, Support+Assassin...).");
		for (int i = 0; i < NUM_MOD_CLASSES; i++)
		{
			ModOptionDef& on = sDefs[OPT_CL_ON_0 + i];
			on.mKey = std::format("cl_on_{}", i);
			on.mLabel = std::format("Class: {}", gModClasses[i].mName);
			on.mDesc = gModClasses[i].mDesc;
			on.mCategory = CAT_CLASSES; on.mType = ModOptType::Toggle; on.mDefault = 1;
			ModOptionDef& p = sDefs[OPT_CL_POWER_0 + i];
			p.mKey = std::format("cl_pow_{}", i);
			p.mLabel = std::format("{} power x", gModClasses[i].mName);
			p.mDesc = "Strength of this class's bonuses.";
			p.mCategory = CAT_CLASSES; p.mType = ModOptType::Slider; p.mMin = 0.25f; p.mMax = 3.0f; p.mStep = 0.25f;
			p.mDefault = 1.0f; p.mIsFunction = false;
		}

		// ---------------- Weather
		T(OPT_W_ENABLE,      "w_enable",      "Dynamic weather", CAT_WEATHER, true, "Weather changes during levels.");
		C(OPT_W_MODE,        "w_mode",        "Weather mode", CAT_WEATHER, {"Random","Fixed"}, 0, "Random weather or the type chosen below.");
		{
			std::vector<std::string> v;
			for (int i = 0; i < NUM_MOD_WEATHERS; i++) v.push_back(gModWeathers[i].mName);
			C(OPT_W_TYPE, "w_type", "Fixed weather", CAT_WEATHER, v, 1, "Weather used in Fixed mode.", false);
		}
		S(OPT_W_INTENSITY,   "w_intensity",   "Weather intensity x", CAT_WEATHER, 0.25f, 2.0f, 0.25f, 1.0f, "Strength of weather effects.");
		I(OPT_W_INTERVAL,    "w_interval",    "Weather change (seconds)", CAT_WEATHER, 20, 300, 10, 75, "Seconds between weather changes.");
		T(OPT_W_RARE,        "w_rare",        "Rare weather events", CAT_WEATHER, true, "Blood Moon, Meteor Shower, Aurora, Eclipse.");
		A(OPT_W_NEXT,        "w_next",        "Change weather now", CAT_WEATHER, "Rolls a new weather immediately.");
		A(OPT_W_TRIGGER_RARE,"w_trigger",     "Trigger rare event", CAT_WEATHER, "Starts a random rare event.");

		// ---------------- Bosses
		{
			std::vector<std::string> v;
			for (int i = 0; i < NUM_MOD_BOSSES; i++) v.push_back(gModBosses[i].mName);
			C(OPT_B_SELECT, "b_sel", "Boss", CAT_BOSSES, v, 0, "Boss used by 'Spawn boss now'.", false);
		}
		A(OPT_B_SPAWN,       "b_spawn",       "Spawn boss now", CAT_BOSSES, "Spawns the selected boss.");
		S(OPT_B_HP,          "b_hp",          "Boss health x", CAT_BOSSES, 0.25f, 5.0f, 0.25f, 1.0f, "Health multiplier for bosses.");
		S(OPT_B_FINAL_CHANCE,"b_final",       "Boss in final wave %", CAT_BOSSES, 0.0f, 100.0f, 5.0f, 0.0f, "Chance a random boss joins the final wave.");

		// ---------------- Special abilities
		A(OPT_S_LIGHTNING,   "s_lightning",   "Lightning strike", CAT_ABILITIES, "Lightning hits 5 zombies for 600 damage.");
		A(OPT_S_METEOR,      "s_meteor",      "Meteor shower", CAT_ABILITIES, "8 meteors crash into the zombies.");
		A(OPT_S_FREEZE,      "s_freeze",      "Freeze wave", CAT_ABILITIES, "Freezes every zombie solid.");
		A(OPT_S_SUN_RAIN,    "s_sunrain",     "Sun rain", CAT_ABILITIES, "Ten suns fall from the sky.");
		A(OPT_S_SHIELD,      "s_shield",      "Plant shield", CAT_ABILITIES, "All plants are invulnerable for 10 seconds.");
		A(OPT_S_QUAKE,       "s_quake",       "Earthquake", CAT_ABILITIES, "Every zombie takes 300 damage.");
		A(OPT_S_MOWERS,      "s_mowers",      "Mower charge", CAT_ABILITIES, "Starts every lawn mower.");
		A(OPT_S_PF_ALL,      "s_pfall",       "Plant Food on all plants", CAT_ABILITIES, "Boosts every plant at once.");
		A(OPT_S_COINS,       "s_coins",       "Coin shower", CAT_ABILITIES, "Coins rain down.");
		A(OPT_S_BLIZZARD,    "s_blizzard",    "Blizzard", CAT_ABILITIES, "Snow storm: zombies chilled, snow weather.");
		A(OPT_S_FIRESTORM,   "s_firestorm",   "Firestorm", CAT_ABILITIES, "Burns the lane with the most zombies.");
		A(OPT_S_GRAVITY,     "s_gravity",     "Gravity well", CAT_ABILITIES, "Pulls flying zombies to the ground.");

		// ---------------- Experimental
		T(OPT_X_LANE_SWITCH, "x_lanes",       "Zombies switch lanes", CAT_EXPERIMENTAL, false, "Zombies randomly change lanes.");
		T(OPT_X_BACKFIRE,    "x_backfire",    "Shooters fire backwards too", CAT_EXPERIMENTAL, false, "Every pea also flies backwards.");
		T(OPT_X_CHAIN_EXPLODE,"x_chain",      "Chain reaction", CAT_EXPERIMENTAL, false, "Defeated zombies damage zombies around them.");
		T(OPT_X_CHAOS,       "x_chaos",       "Chaos mode", CAT_EXPERIMENTAL, false, "A random event happens every 20 seconds.");
		S(OPT_X_ALLY_CHANCE, "x_ally",        "Ally zombie chance %", CAT_EXPERIMENTAL, 0.0f, 50.0f, 1.0f, 0.0f, "Some zombies arrive already on your side.");
		T(OPT_X_RICOCHET,    "x_ricochet",    "Ricochet peas", CAT_EXPERIMENTAL, false, "Peas bounce into a neighbouring lane.");
		T(OPT_X_LIFESTEAL,   "x_lifesteal",   "Lifesteal plants", CAT_EXPERIMENTAL, false, "Shooters heal when they hit.");

		// ---------------- Misc
		A(OPT_MI_RESET,      "mi_reset",      "Reset all settings", CAT_MISC, "Restores every option to its default.");
		A(OPT_MI_SAVE,       "mi_save",       "Save settings now", CAT_MISC, "Settings are also saved automatically.");
		A(OPT_MI_RESET_STATS,"mi_resetstats", "Reset statistics", CAT_MISC, "Clears records, kills and unlocks.");
		C(OPT_MI_BUTTON_POS, "mi_btnpos",     "MOD button position", CAT_MISC, {"Top right","Bottom left","Bottom right"}, 0, "Where the in-game MOD button is drawn.");
		T(OPT_MI_AUTOPAUSE,  "mi_autopause",  "Pause while menu is open", CAT_MISC, true, "The game pauses while the mod menu is open.");

		// ---------------- Plant ability toggles and upgrade branches
		for (int i = 0; i < MOD_PLANT_ABILITY_COUNT; i++)
		{
			const ModPlantAbilityDef& pa = gModPlantAbilities[i];
			ModOptionDef& on = sDefs[OPT_PAB_0 + i];
			on.mKey = std::format("pab_{}", static_cast<int>(pa.mSeed));
			on.mLabel = std::format("{}: ability", pa.mPlant);
			on.mDesc = pa.mAbility;
			on.mCategory = CAT_PLANT_ABILITIES; on.mType = ModOptType::Toggle; on.mDefault = 1;
			ModOptionDef& br = sDefs[OPT_PBR_0 + i];
			br.mKey = std::format("pbr_{}", static_cast<int>(pa.mSeed));
			br.mLabel = std::format("{}: upgrade", pa.mPlant);
			br.mDesc = std::format("A = {} | B = {}", pa.mBranchA, pa.mBranchB);
			br.mCategory = CAT_PLANT_ABILITIES; br.mType = ModOptType::Select;
			br.mChoices = { "None", "A", "B" };
			br.mMin = 0; br.mMax = 2; br.mStep = 1; br.mDefault = 0; br.mIsFunction = false;
		}
	}

	std::string Trim(const std::string& s)
	{
		size_t a = s.find_first_not_of(" \t\r\n");
		if (a == std::string::npos) return "";
		size_t b = s.find_last_not_of(" \t\r\n");
		return s.substr(a, b - a + 1);
	}
}

namespace ModConfig
{
	void Init()
	{
		if (sInit)
			return;
		sInit = true;
		BuildDefs();
		sValues.assign(NUM_MOD_OPTS, 0.0f);
		for (int i = 0; i < NUM_MOD_OPTS; i++)
			sValues[i] = sDefs[i].mDefault;
		Load();
		sDirty = false;
	}

	const ModOptionDef& Def(int theOpt)
	{
		if (!sInit) Init();
		return sDefs[std::clamp(theOpt, 0, NUM_MOD_OPTS - 1)];
	}

	float Get(int theOpt)
	{
		if (!sInit) Init();
		if (theOpt < 0 || theOpt >= NUM_MOD_OPTS) return 0.0f;
		return sValues[theOpt];
	}

	void Set(int theOpt, float theValue)
	{
		if (!sInit) Init();
		if (theOpt < 0 || theOpt >= NUM_MOD_OPTS) return;
		const ModOptionDef& d = sDefs[theOpt];
		if (d.mType == ModOptType::Action) return;
		float v = std::clamp(theValue, d.mMin, d.mMax);
		if (d.mType != ModOptType::Slider)
			v = std::round(v);
		else if (d.mStep > 0.0f)
			v = d.mMin + std::round((v - d.mMin) / d.mStep) * d.mStep;
		v = std::clamp(v, d.mMin, d.mMax);
		if (v == sValues[theOpt]) return;
		sValues[theOpt] = v;
		sDirty = true;
		ModSystem::OnOptionChanged(theOpt);
	}

	void ResetAll()
	{
		if (!sInit) Init();
		for (int i = 0; i < NUM_MOD_OPTS; i++)
			sValues[i] = sDefs[i].mDefault;
		sDirty = true;
		Save();
	}

	std::string ConfigPath()
	{
		return Sexy::GetAppDataPath("living_nightmare.cfg");
	}

	void Load()
	{
		std::ifstream f(PathFromU8(ConfigPath()));
		if (!f.is_open())
			return;
		std::string line;
		while (std::getline(f, line))
		{
			line = Trim(line);
			if (line.empty() || line[0] == '#') continue;
			size_t eq = line.find('=');
			if (eq == std::string::npos) continue;
			std::string k = Trim(line.substr(0, eq));
			std::string v = Trim(line.substr(eq + 1));
			for (int i = 0; i < NUM_MOD_OPTS; i++)
			{
				if (sDefs[i].mKey == k && sDefs[i].mType != ModOptType::Action)
				{
					float fv = static_cast<float>(std::atof(v.c_str()));
					sValues[i] = std::clamp(fv, sDefs[i].mMin, sDefs[i].mMax);
					break;
				}
			}
		}
	}

	void Save()
	{
		if (!sInit) return;
		std::string aPath = ConfigPath();
		std::string aTmp = aPath + ".tmp";
		{
			std::ofstream f(PathFromU8(aTmp), std::ios::trunc);
			if (!f.is_open())
				return;
			f << "# PvZ Living Nightmare configuration (auto-saved)\n";
			for (int i = 0; i < NUM_MOD_OPTS; i++)
			{
				if (sDefs[i].mType == ModOptType::Action) continue;
				f << sDefs[i].mKey << '=' << std::format("{:g}", sValues[i]) << '\n';
			}
		}
		std::error_code ec;
		std::filesystem::rename(PathFromU8(aTmp), PathFromU8(aPath), ec);
		if (ec)
		{
			std::filesystem::remove(PathFromU8(aPath), ec);
			std::filesystem::rename(PathFromU8(aTmp), PathFromU8(aPath), ec);
		}
		sDirty = false;
	}

	void SaveIfDirty()
	{
		if (sDirty) Save();
	}

	bool IsDirty() { return sDirty; }

	int CountFunctions()
	{
		if (!sInit) Init();
		int n = 0;
		for (int i = 0; i < NUM_MOD_OPTS; i++)
			if (sDefs[i].mIsFunction) n++;
		// every game mode is its own function, the selector itself counts once already
		n += NUM_MOD_GAME_MODES - 2;
		return n;
	}

	std::string FormatValue(int theOpt)
	{
		const ModOptionDef& d = Def(theOpt);
		float v = Get(theOpt);
		switch (d.mType)
		{
		case ModOptType::Toggle: return v > 0.5f ? "ON" : "OFF";
		case ModOptType::Select:
		{
			int i = std::clamp(GetInt(theOpt), 0, static_cast<int>(d.mChoices.size()) - 1);
			return d.mChoices.empty() ? "" : d.mChoices[i];
		}
		case ModOptType::Int: return std::format("{}", GetInt(theOpt));
		case ModOptType::Slider:
			if (d.mStep >= 1.0f) return std::format("{:.0f}", v);
			if (d.mStep >= 0.1f && std::fmod(d.mStep * 10.0f, 1.0f) < 0.01f) return std::format("{:.1f}", v);
			return std::format("{:.2f}", v);
		case ModOptType::Action: return "RUN";
		}
		return "";
	}
}
