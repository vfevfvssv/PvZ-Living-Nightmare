// PvZ Living Nightmare - seven multi-phase bosses built on existing zombie bodies.
#include "ModInternal.h"

using namespace ModInt;

namespace
{
	void PhaseBanner(Zombie* z, int thePhase)
	{
		const ModBossDef& d = gModBosses[z->mMod.mBoss];
		AddFloatingText(400.0f, 200.0f, std::format("{} - PHASE {}", d.mName, thePhase + 1), d.mR, d.mG, d.mB, 1.5f);
		Flash(d.mR, d.mG, d.mB, 25);
		ShakeIfAllowed(3, -4);
		gApp->PlayFoley(FOLEY_LOW_GROAN);
	}

	Plant* RandomPlant(Board* b, int theRow = -1, float theMaxX = 2000.0f)
	{
		std::vector<Plant*> v;
		for (Plant* p : b->mPlants)
			if (!p->mDead && !p->NotOnGround() && (theRow < 0 || p->mRow == theRow) && p->mX < theMaxX)
				v.push_back(p);
		return v.empty() ? nullptr : v[Rand(static_cast<int>(v.size()))];
	}

	void SpawnImp(Zombie* z, int theRow, float theX)
	{
		Zombie* imp = ModSystem::SpawnZombie(ZOMBIE_IMP, theRow, -1, -1, -1, 0);
		if (imp)
		{
			imp->mPosX = std::clamp(theX, 100.0f, 780.0f);
			imp->mX = static_cast<int>(imp->mPosX);
		}
	}

	void GainMutation(Zombie* z)
	{
		ZombieModState& m = z->mMod;
		std::vector<int> v;
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++)
			if (!(m.mMutations & (1 << i)) && i != MUT_GIANT && i != MUT_MULTIPLIER) v.push_back(i);
		if (v.empty()) return;
		int mu = v[Rand(static_cast<int>(v.size()))];
		m.mMutations |= 1 << mu;
		m.mAbilities |= gModMutations[mu].mGrants;
		AddFloatingText(z->mPosX + 40, z->mPosY - 30, std::format("MUTATION: {}", gModMutations[mu].mName), gModMutations[mu].mR, gModMutations[mu].mG, gModMutations[mu].mB, 1.1f);
	}
}

namespace ModInt
{
	void BossInit(Zombie* z, int theBoss)
	{
		ZombieModState& m = z->mMod;
		const ModBossDef& d = gModBosses[theBoss];
		m.mBoss = static_cast<int8_t>(theBoss);
		m.mAbilities |= d.mAbilities;
		m.mBossPhase = 0;
		m.mBossTimerA = 200; m.mBossTimerB = 400; m.mBossTimerC = 600;
		int hp = std::max(100, static_cast<int>(d.mHealth * Opt(OPT_B_HP) * (IsMode(MODE_HARDCORE) ? 1.3f : 1.0f)));
		z->mBodyHealth = hp;
		z->mBodyMaxHealth = hp;
		z->mScaleZombie *= d.mScale;
		m.mBaseScale *= d.mScale;
		if (theBoss == BOSS_MECHANIC || theBoss == BOSS_ARMORED_GIANT)
		{
			m.mShieldMax = hp / 6;
			m.mShieldHP = m.mShieldMax;
		}
		gP.mBossSeen[theBoss]++;
		MarkProgressDirty();
		AddFloatingText(400.0f, 170.0f, std::format("BOSS: {}", d.mName), d.mR, d.mG, d.mB, 1.6f);
		Flash(d.mR, d.mG, d.mB, 30);
		gApp->PlaySample(SOUND_HUGE_WAVE);
	}

	int BossDamage(Zombie* z, int theDamage, bool theExplosive)
	{
		ZombieModState& m = z->mMod;
		int cap = theExplosive ? 600 : 400;
		if (m.mBoss == BOSS_ARMORED_GIANT && m.mBossPhase == 0) theDamage = static_cast<int>(theDamage * (theExplosive ? 0.5f : 0.2f));
		if (m.mBoss == BOSS_ICE && (z->mIceTrapCounter > 0)) theDamage = static_cast<int>(theDamage * 0.5f);
		if (m.mBoss == BOSS_FIRE && WeatherIs(WEATHER_RAIN)) theDamage = static_cast<int>(theDamage * 1.3f);
		return std::clamp(theDamage, 1, cap);
	}

	void BossUpdate(Zombie* z)
	{
		ZombieModState& m = z->mMod;
		Board* b = z->mBoard;
		if (z->mMindControlled || z->IsDeadOrDying()) return;
		if (z->mZombieType == ZOMBIE_YETI && z->mZombiePhase == PHASE_ZOMBIE_NORMAL) z->mPhaseCounter = std::max(z->mPhaseCounter, 300);
		float fr = z->mBodyMaxHealth > 0 ? static_cast<float>(z->mBodyHealth) / z->mBodyMaxHealth : 0.0f;
		int phase = fr <= 0.33f ? 2 : fr <= 0.66f ? 1 : 0;
		if (phase > m.mBossPhase)
		{
			m.mBossPhase = static_cast<int8_t>(phase);
			PhaseBanner(z, phase);
			if (m.mBoss == BOSS_MUTANT) { GainMutation(z); GainMutation(z); }
			if (m.mBoss == BOSS_ARMORED_GIANT && phase == 1)
			{
				m.mShieldHP = 0; m.mShieldMax = 0;
				AddFloatingText(z->mPosX + 40, z->mPosY, "ARMOR BROKEN!", 255, 255, 255, 1.2f);
			}
			if (m.mBoss == BOSS_ICE && phase == 1) { gW.mWeather = WEATHER_SNOW; gW.mBlend = 0.0f; gW.mWeatherTimer = 3000; }
			if (m.mBoss == BOSS_ELECTRIC && phase == 2) { gW.mWeather = WEATHER_STORM; gW.mBlend = 0.0f; gW.mWeatherTimer = 3000; }
		}
		if (z->mPosX > 790.0f) return;
		int A = --m.mBossTimerA, B = --m.mBossTimerB, C = --m.mBossTimerC;
		float zx = z->mPosX + 40.0f, zy = z->mPosY + 60.0f;
		switch (m.mBoss)
		{
		case BOSS_ARMORED_GIANT:
			if (A <= 0)
			{
				m.mBossTimerA = phase == 0 ? 600 : 420;
				for (Plant* p : b->mPlants)
					if (!p->mDead && std::abs(p->mRow - z->mRow) <= (phase >= 1 ? 1 : 0) && p->mX < zx && p->mX > zx - 200) DamagePlant(p, 150);
				gApp->PlayFoley(FOLEY_THUMP);
				ShakeIfAllowed(4, 3);
				gApp->AddPvzpParticle(zx, zy + 50, z->mRenderOrder + 1, PARTICLE_DUST_SQUASH);
			}
			if (phase == 2 && B <= 0)
			{
				m.mBossTimerB = 360;
				SpawnImp(z, z->mRow, z->mPosX - 160);
				gApp->PlayFoley(FOLEY_SWING);
			}
			break;
		case BOSS_MECHANIC:
			if (A <= 0)
			{
				m.mBossTimerA = phase == 2 ? 150 : 240;
				for (int r = z->mRow - (phase == 2 ? 1 : 0); r <= z->mRow + (phase == 2 ? 1 : 0); r++)
				{
					Plant* p = RandomPlant(b, r, zx);
					if (p) LobAtPlant(z, p, PROJECTILE_BASKETBALL);
				}
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 600;
				for (int i = 0; i < 2; i++) SpawnImp(z, Rand(b->StageHas6Rows() ? 6 : 5), z->mPosX - 40);
				gApp->PlayFoley(FOLEY_HYDRAULIC_SHORT);
			}
			if (phase == 2 && C <= 0)
			{
				m.mBossTimerC = 700;
				m.mRageStacks = 25;
				AddFloatingText(zx, z->mPosY - 20, "OVERDRIVE!", 255, 230, 80, 1.1f);
			}
			if (phase == 2 && C == 500) m.mRageStacks = 0;
			break;
		case BOSS_NECROMANCER:
			if (A <= 0)
			{
				m.mBossTimerA = 600;
				for (int i = 0; i < 2; i++)
				{
					int r = std::clamp(z->mRow + RandRangeInt(-1, 1), 0, b->StageHas6Rows() ? 5 : 4);
					int col = RandRangeInt(4, 8);
					if (b->mPlantRow[r] == PLANTROW_POOL || b->GetTopPlantAt(col, r, TOPPLANT_ANY)) continue;
					Zombie* n = ModSystem::SpawnZombie(Rand(2) ? ZOMBIE_NORMAL : ZOMBIE_TRAFFIC_CONE, r, -1, -1, -1, 0);
					if (n) n->RiseFromGrave(col, r);
				}
				gApp->PlayFoley(FOLEY_GRAVESTONE_RUMBLE);
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 900;
				for (int i = 0; i < 2; i++)
				{
					int col = RandRangeInt(4, 8), r = Rand(b->StageHas6Rows() ? 6 : 5);
					if (b->mPlantRow[r] == PLANTROW_POOL || b->GetTopPlantAt(col, r, TOPPLANT_ANY) || b->GetGridItemAt(GRIDITEM_GRAVESTONE, col, r) || b->GetGridItemAt(GRIDITEM_CRATER, col, r)) continue;
					b->AddAGraveStone(col, r);
				}
				gApp->PlayFoley(FOLEY_GRAVESTONE_RUMBLE);
			}
			if (phase == 2 && C <= 0)
			{
				m.mBossTimerC = 300;
				int drained = 0;
				for (Plant* p : b->mPlants)
					if (!p->mDead && p->mRow == z->mRow && p->mX < zx && p->mX > zx - 260) { DamagePlant(p, 30); drained += 30; AddBolt(zx, zy, p->mX + 40.0f, p->mY + 40.0f, 170, 80, 255); }
				z->mBodyHealth = std::min(z->mBodyMaxHealth, z->mBodyHealth + drained * 3);
			}
			break;
		case BOSS_MUTANT:
			if (A <= 0)
			{
				m.mBossTimerA = 500;
				DamagePlantsInRadius(zx, zy, 130.0f, 0, true, false);
				gApp->AddPvzpParticle(zx, zy, z->mRenderOrder + 1, PARTICLE_GLOOMCLOUD);
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 800;
				ModSystem::SpawnZombie(ZOMBIE_NORMAL, z->mRow, -1, -1, -1, 1 << Rand(NUM_MOD_MUTATIONS));
			}
			break;
		case BOSS_FIRE:
			if (A <= 0)
			{
				m.mBossTimerA = 540;
				b->DoFwoosh(z->mRow);
				gApp->PlayFoley(FOLEY_JALAPENO_IGNITE);
				for (Plant* p : b->mPlants)
					if (!p->mDead && p->mRow == z->mRow && p->mX < zx) DamagePlant(p, 120);
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 420;
				for (int i = 0; i < 4; i++)
				{
					Plant* p = RandomPlant(b);
					if (!p) break;
					DamagePlant(p, 100);
					gApp->AddPvzpParticle(p->mX + 40, p->mY + 40, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_FIREBALL_DEATH);
				}
				gApp->PlayFoley(FOLEY_IGNITE);
			}
			if (phase == 2 && C <= 0)
			{
				m.mBossTimerC = 60;
				DamagePlantsInRadius(zx, zy, 120.0f, 15, false, false);
			}
			break;
		case BOSS_ICE:
			if (A <= 0)
			{
				m.mBossTimerA = 360;
				Plant* p = FindPlantAhead(z, 500.0f);
				if (p)
				{
					FreezePlant(p, 240);
					AddBolt(zx, zy - 30, p->mX + 40.0f, p->mY + 40.0f, 180, 230, 255);
					gApp->AddPvzpParticle(p->mX + 40, p->mY + 40, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_ICEBALL_DEATH);
					gApp->PlayFoley(FOLEY_FROZEN);
				}
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 900;
				for (Plant* p : b->mPlants) if (!p->mDead) p->mMod.mSlowed = std::max(p->mMod.mSlowed, 400);
				AddFloatingText(400.0f, 220.0f, "BLIZZARD!", 180, 230, 255, 1.3f);
			}
			if (phase == 2 && C <= 0)
			{
				m.mBossTimerC = 1200;
				for (Plant* p : b->mPlants) if (!p->mDead && std::abs(p->mRow - z->mRow) <= 1) FreezePlant(p, 180);
				Flash(180, 230, 255, 30);
				AddFloatingText(400.0f, 240.0f, "ABSOLUTE ZERO!", 180, 230, 255, 1.4f);
			}
			break;
		case BOSS_ELECTRIC:
			if (A <= 0)
			{
				m.mBossTimerA = 420;
				Plant* first = FindPlantAhead(z, 600.0f);
				if (first)
				{
					float lx = zx, ly = zy - 30;
					int n = 0;
					for (Plant* p : b->mPlants)
					{
						if (p->mDead || std::abs(p->mRow - z->mRow) > 1 || p->mX > zx) continue;
						AddBolt(lx, ly, p->mX + 40.0f, p->mY + 40.0f, 140, 210, 255);
						lx = p->mX + 40.0f; ly = p->mY + 40.0f;
						DamagePlant(p, 60);
						if (++n >= 4) break;
					}
					gApp->PlayFoley(FOLEY_THUNDER);
				}
			}
			if (phase >= 1 && B <= 0)
			{
				m.mBossTimerB = 600;
				int col = RandRangeInt(1, 7);
				for (Plant* p : b->mPlants) if (!p->mDead && p->mPlantCol == col) DisablePlant(p, 300);
				AddBolt(b->GridToPixelX(col, 0) + 40.0f, 60.0f, b->GridToPixelX(col, 4) + 40.0f, 560.0f, 200, 230, 255);
				AddFloatingText(b->GridToPixelX(col, 0) + 40.0f, 100.0f, "EMP!", 200, 230, 255, 1.2f);
			}
			if (phase == 2 && C <= 0)
			{
				m.mBossTimerC = 240;
				Plant* p = RandomPlant(b);
				if (p)
				{
					AddBolt(p->mX + 40.0f, 0.0f, p->mX + 40.0f, p->mY + 40.0f, 255, 255, 200);
					DamagePlant(p, 100);
					Flash(255, 255, 230, 8);
					gApp->PlayFoley(FOLEY_THUNDER);
				}
			}
			break;
		default:
			break;
		}
	}

	void BossDeath(Zombie* z)
	{
		ZombieModState& m = z->mMod;
		const ModBossDef& d = gModBosses[m.mBoss];
		Board* b = z->mBoard;
		gP.mBossKills[m.mBoss]++;
		MarkProgressDirty();
		AddFloatingText(400.0f, 200.0f, std::format("{} DEFEATED!", d.mName), 255, 230, 120, 1.6f);
		Flash(255, 255, 255, 30);
		ShakeIfAllowed(5, -5);
		gApp->PlayFoley(FOLEY_BOSS_EXPLOSION_SMALL);
		gApp->AddPvzpParticle(z->mPosX + 60, z->mPosY + 60, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_BOSS_EXPLOSION);
		if (b->CanDropLoot())
		{
			for (int i = 0; i < 5; i++)
				b->AddCoin(static_cast<int>(z->mPosX) + i * 12, static_cast<int>(z->mPosY) + 20, i == 0 ? COIN_DIAMOND : COIN_GOLD, COIN_MOTION_COIN);
		}
		ModSystem::AddPlantFood(2);
		if (m.mBoss == BOSS_MUTANT)
			for (int i = 0; i < 2; i++)
			{
				Zombie* s = ModSystem::SpawnZombie(ZOMBIE_NORMAL, z->mRow, -1, -1, -1, (1 << Rand(NUM_MOD_MUTATIONS)) | (1 << MUT_FAST));
				if (s) { s->mPosX = z->mPosX + i * 30.0f; s->mX = static_cast<int>(s->mPosX); }
			}
	}
}
