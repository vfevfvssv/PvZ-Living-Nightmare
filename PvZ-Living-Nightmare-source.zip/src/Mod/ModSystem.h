// PvZ Living Nightmare - gameplay hooks called from the original engine code.
// Every hook is cheap and returns the vanilla behavior when the related option is off.
#ifndef __MOD_SYSTEM_H__
#define __MOD_SYSTEM_H__

#include <cstdint>
#include <string>
#include "../ConstEnums.h"

class LawnApp;
class Board;
class Zombie;
class Plant;
class Projectile;
class Coin;
namespace Sexy { class Graphics; class Color; }

namespace ModSystem
{
	// ---- lifecycle / app
	void        Init(LawnApp* theApp);
	void        Shutdown();
	void        OnOptionChanged(int theOpt);
	void        ExecuteAction(int theOpt);
	int         UpdateCountForFrame(int theBaseCount);   // game speed / slow motion
	void        AppUpdate();                              // once per app frame (autosave etc.)

	// ---- zombies
	void        ZombieInit(Zombie* theZombie);           // end of ZombieInitialize (before max health)
	void        ZombieUpdate(Zombie* theZombie);         // every tick while on board
	bool        ZombieFrozen(Zombie* theZombie);         // global freeze
	float       ZombieAnimFactor(Zombie* theZombie);     // multiplies the body animation rate
	float       ZombieWalkFactor(Zombie* theZombie);     // multiplies velocity-based movement
	int         ZombieTakeDamage(Zombie* theZombie, int theDamage, unsigned int theFlags);
	bool        ZombieUntargetable(Zombie* theZombie);
	bool        ZombieIgnoresPlants(Zombie* theZombie);
	int         ZombieBite(Zombie* theZombie, Plant* thePlant, int theDamage);
	bool        ZombieBlockChill(Zombie* theZombie);
	bool        ZombieBurnOverride(Zombie* theZombie);   // true = burn handled (fire immunity)
	void        ZombieTint(Zombie* theZombie, Sexy::Color& theColor, Sexy::Color& theAdditive, bool& theUseAdditive);
	void        ZombieDraw(Zombie* theZombie, Sexy::Graphics* g);
	bool        ZombieReachedHouse(Zombie* theZombie);   // true = handled, do not lose
	void        ZombieDropLoot(Zombie* theZombie);

	// ---- plants
	void        PlantInit(Plant* thePlant);
	bool        PlantUpdate(Plant* thePlant);            // true = plant is disabled this tick
	int         PlantShooterUpdates(Plant* thePlant);    // how many UpdateShooter calls this tick
	int         PlantProducerUpdates(Plant* thePlant);
	void        PlantFired(Plant* thePlant, Projectile* theProjectile, Zombie* theTarget, int theWeapon);
	void        PlantProducedSun(Plant* thePlant);
	bool        PlantSquishBlocked(Plant* thePlant);
	bool        PlantNoSleep();
	void        PlantReanimAdjust(Plant* thePlant, float& theOffsetX, float& theOffsetY, float& theScaleX, float& theScaleY);
	bool        PlantColor(Plant* thePlant, Sexy::Color& theColor);
	void        PlantDraw(Plant* thePlant, Sexy::Graphics* g);
	void        PlantSpecial(Plant* thePlant);           // after DoSpecial (bombs etc.)
	void        PlantDigested(Plant* thePlant);          // chomper started digesting
	void        PlantShoveled(Plant* thePlant);
	int         PlantDamageOut(Plant* thePlant, Zombie* theZombie, int theDamage);
	int         PlantHitDamage(Plant* thePlant, int theDamage);       // zombie projectiles hitting plants
	int         KernelButterOdds(Plant* thePlant);
	void        ZombieHypnotized(Zombie* theZombie);
	int         AdjustCost(SeedType theSeedType, int theCost);
	int         AdjustRefresh(SeedType theSeedType, int theTime);

	// ---- projectiles
	void        ProjectileInit(Projectile* theProjectile);
	int         ProjectileDamage(Projectile* theProjectile, Zombie* theZombie, int theDamage);
	void        ProjectileHit(Projectile* theProjectile, Zombie* theZombie);
	bool        ProjectileSkipZombie(Projectile* theProjectile, Zombie* theZombie);
	bool        ProjectileKeepAlive(Projectile* theProjectile, Zombie* theZombie);

	// ---- board
	void        BoardInitLevel(Board* theBoard);              // end of Board::InitLevel
	void        BoardLevelStart(Board* theBoard);             // Board::StartLevel (after seed selection)
	void        BoardUpdate(Board* theBoard);
	bool        BoardMouseDown(Board* theBoard, int x, int y, int theClickCount);
	bool        BoardMouseUp(Board* theBoard, int x, int y);
	bool        BoardKeyDown(Board* theBoard, int theKey);
	void        DrawOverlay(Board* theBoard, Sexy::Graphics* g);   // weather layer above the lawn
	void        DrawHUD(Board* theBoard, Sexy::Graphics* g);       // top layer: buttons, bars, numbers
	int         AdjustNumWaves(Board* theBoard, int theWaves);
	int         AdjustZombiePoints(Board* theBoard, int theWave, int thePoints);
	void        AdjustAllowedZombies(Board* theBoard);
	int         AdjustPickWeight(Board* theBoard, ZombieType theType, int theWeight);
	int         AdjustFirstAllowedWave(Board* theBoard, ZombieType theType, int theWave);
	void        OnWavesPicked(Board* theBoard);
	void        OnWaveSpawned(Board* theBoard, int theWave);
	void        AdjustWaveCountdown(Board* theBoard);
	bool        PauseSpawning(Board* theBoard);
	bool        BlockSkySun(Board* theBoard);
	void        AdjustSkySunCountdown(Board* theBoard);
	int         AdjustSunGain(int theAmount);
	bool        InfiniteSun();
	int         OverrideRow(Board* theBoard, ZombieType theType);
	bool        BlockPlanting(Board* theBoard, int theGridX, int theGridY);
	BackgroundType OverrideBackground(Board* theBoard, BackgroundType theBackground);
	bool        ShakeAllowed();
	bool        NoCooldown();
	int         CoinValueMult();
	bool        UnlockAllPlants();
	bool        MaxSeedSlots();
	bool        UnlockAllModes();
	bool        BoardBusyWithMod();                    // board should ignore input (menu open)

	// ---- menu
	void        OpenMenu();
	void        CloseMenu();
	bool        IsMenuOpen();
	void        DrawMenuButton(Sexy::Graphics* g, bool theInGame);
	bool        MenuButtonHit(int x, int y, bool theInGame);

	// ---- helpers shared by the mod modules
	void        MarkShot();
	Zombie*     SpawnZombie(ZombieType theType, int theRow, int theVariant, int theClass, int theBoss, int theMutations);
	void        AddFloatingText(float x, float y, const std::string& theText, int theR, int theG, int theB, float theScale = 1.0f);
	void        AddPlantFood(int theAmount);
	int         GetPlantFood();
	void        ApplyPlantFood(Plant* thePlant);
}

#endif
