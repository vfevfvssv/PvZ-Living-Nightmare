// PvZ Living Nightmare - board level systems: weather, events, game modes, waves, economy, actions and HUD.
#include "ModInternal.h"
#include "../Lawn/Widget/GameButton.h"

using namespace ModInt;

namespace ModInt
{
	LawnApp*    gApp = nullptr;
	WorldState  gW;
	std::string gActionMsg;

	bool InPlay()
	{
		Board* b = GetBoard();
		return b && gApp->mGameScene == SCENE_PLAYING;
	}

	bool EventIs(int theEvent) { return gW.mEvent == theEvent && On(OPT_W_RARE); }

	float WeatherAmount(int theWeather)
	{
		if (!gW.mBoard) return 0.0f;
		float a = 0.0f;
		if (theWeather == WEATHER_DARK && EventIs(EVENT_ECLIPSE)) a = 1.0f;
		if (!On(OPT_W_ENABLE) || gW.mWeatherClearTimer > 0) return a;
		if (gW.mWeather == theWeather) a = std::max(a, gW.mBlend);
		if (gW.mPrevWeather == theWeather) a = std::max(a, 1.0f - gW.mBlend);
		return a * Opt(OPT_W_INTENSITY);
	}

	bool CustomWaveSpec(int theType, int& theVariant, int& theClass, int& theMutations)
	{
		int vMode = OptI(OPT_CW_VARIANTS);
		theVariant = -1;
		if (vMode > 0)
		{
			std::vector<int> v;
			for (int k = 0; k < NUM_MOD_VARIANTS; k++) if (gModVariants[k].mBase == theType) v.push_back(k);
			if (!v.empty() && (vMode == 2 || Rand(2) == 0)) theVariant = v[Rand(static_cast<int>(v.size()))];
		}
		int cl = OptI(OPT_CW_CLASS);
		theClass = cl == 0 ? (Chance(40.0f) ? Rand(NUM_MOD_CLASSES) : -1) : cl == 1 ? -1 : cl - 2;
		int mu = OptI(OPT_CW_MUTATION);
		theMutations = mu == 0 ? (Chance(30.0f) ? (1 << Rand(NUM_MOD_MUTATIONS)) : 0) : mu == 1 ? 0 : (1 << (mu - 2));
		return true;
	}

	void AddBolt(float x1, float y1, float x2, float y2, int r, int g, int b)
	{
		if (!On(OPT_V_ABILITY_FX) || gW.mBolts.size() > 40) return;
		gW.mBolts.push_back({ x1, y1, x2, y2, 14, static_cast<uint8_t>(r), static_cast<uint8_t>(g), static_cast<uint8_t>(b) });
	}

	void Flash(int r, int g, int b, int theTicks)
	{
		if (!On(OPT_V_FLASH)) return;
		gW.mFlash = std::max(gW.mFlash, theTicks);
		gW.mFlashR = static_cast<uint8_t>(r); gW.mFlashG = static_cast<uint8_t>(g); gW.mFlashB = static_cast<uint8_t>(b);
	}

	void ShakeIfAllowed(int x, int y)
	{
		Board* b = GetBoard();
		if (b && On(OPT_V_SHAKE)) b->ShakeBoard(x, y);
	}
}

namespace
{
	const int kNumRows(Board* b) { return b->StageHas6Rows() ? 6 : 5; }

	bool WavesModdable(Board* b)
	{
		LawnApp* a = gApp;
		return !(a->IsIZombieLevel() || a->IsScaryPotterLevel() || a->IsWhackAZombieLevel() || a->IsSquirrelLevel() ||
			a->mGameMode == GAMEMODE_CHALLENGE_ZOMBIQUARIUM || a->mGameMode == GAMEMODE_CHALLENGE_ZEN_GARDEN ||
			a->mGameMode == GAMEMODE_TREE_OF_WISDOM || a->IsFinalBossLevel() || a->mGameMode == GAMEMODE_UPSELL ||
			a->mGameMode == GAMEMODE_INTRO || b->mNumWaves <= 0);
	}

	std::vector<ZombieType> LandTypes(Board* b)
	{
		std::vector<ZombieType> v = { ZOMBIE_NORMAL, ZOMBIE_TRAFFIC_CONE, ZOMBIE_POLEVAULTER, ZOMBIE_PAIL, ZOMBIE_NEWSPAPER, ZOMBIE_DOOR,
			ZOMBIE_FOOTBALL, ZOMBIE_DANCER, ZOMBIE_JACK_IN_THE_BOX, ZOMBIE_POGO, ZOMBIE_LADDER, ZOMBIE_BALLOON, ZOMBIE_CATAPULT,
			ZOMBIE_GARGANTUAR, ZOMBIE_BUNGEE, ZOMBIE_IMP };
		if (!b->StageHasRoof()) { v.push_back(ZOMBIE_DIGGER); v.push_back(ZOMBIE_ZAMBONI); }
		if (b->StageHasPool()) { v.push_back(ZOMBIE_SNORKEL); v.push_back(ZOMBIE_DOLPHIN_RIDER); }
		return v;
	}

	int CustomGroupType(int theIdx)
	{
		static const int t[4] = { OPT_CW_TYPE1, OPT_CW_TYPE2, OPT_CW_TYPE3, OPT_CW_TYPE4 };
		int v = OptI(t[theIdx]);
		return v <= 0 ? -1 : static_cast<int>(gModSpawnableZombieTypes[std::min(v - 1, NUM_MOD_SPAWNABLE_ZOMBIES - 1)]);
	}
	int CustomGroupCount(int theIdx)
	{
		static const int c[4] = { OPT_CW_COUNT1, OPT_CW_COUNT2, OPT_CW_COUNT3, OPT_CW_COUNT4 };
		return OptI(c[theIdx]);
	}

	void SpawnCustomWave(Board* b)
	{
		int n = 0;
		for (int g = 0; g < 4; g++)
		{
			int t = CustomGroupType(g);
			if (t < 0) continue;
			for (int i = 0; i < CustomGroupCount(g); i++)
			{
				int variant, cls, mut;
				CustomWaveSpec(t, variant, cls, mut);
				Zombie* z = ModSystem::SpawnZombie(static_cast<ZombieType>(t), -1, variant, cls, -1, mut);
				if (z && t != ZOMBIE_BUNGEE) { z->mPosX += (n % 6) * 18.0f; z->mX = static_cast<int>(z->mPosX); }
				n++;
			}
		}
		gActionMsg = n > 0 ? std::format("Spawned {} zombies", n) : "Custom wave is empty";
	}

	void RestoreMowers(Board* b)
	{
		if (b->StageHasRoof() && !gApp->mPlayerInfo->mPurchases[STORE_ITEM_ROOF_CLEANER]) return;
		for (int r = 0; r < kNumRows(b); r++)
		{
			if (b->mPlantRow[r] == PLANTROW_DIRT) continue;
			bool has = false;
			for (LawnMower* m : b->mLawnMowers)
				if (!m->mDead && m->mRow == r && m->mMowerState != MOWER_TRIGGERED && m->mMowerState != MOWER_SQUISHED) has = true;
			if (has) continue;
			LawnMower* m = b->mLawnMowers.DataArrayAlloc();
			m->LawnMowerInitialize(r);
			m->mVisible = true;
		}
	}

	void StrikeLightning(Board* b, bool theFromWeather)
	{
		int col = RandRangeInt(theFromWeather ? 0 : 3, 8);
		int row = Rand(kNumRows(b));
		int x = b->GridToPixelX(col, row) + 40, y = b->GridToPixelY(col, row) + 40;
		AddBolt(static_cast<float>(x + RandRangeInt(-60, 60)), -10.0f, static_cast<float>(x), static_cast<float>(y), 230, 240, 255);
		Flash(230, 235, 255, 6);
		gApp->PlayFoley(FOLEY_THUNDER);
		gP.mLightningStrikes++;
		bool hitZ = false;
		for (Zombie* z : b->mZombies)
			if (IsLiveEnemy(z) && z->mRow == row && std::fabs(z->mPosX + 40 - x) < 60) { z->TakeDamage(200, 0U); hitZ = true; }
		if (!hitZ && Rand(2) == 0)
			if (Plant* p = b->GetTopPlantAt(col, row, TOPPLANT_EATING_ORDER))
				if (!(p->mSeedType == SEED_TORCHWOOD)) DamagePlant(p, 60);
		gApp->AddPvzpParticle(static_cast<float>(x), static_cast<float>(y), Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_POW);
	}

	void StartEvent(int theEvent)
	{
		gW.mEvent = theEvent;
		gW.mEventTimer = 3000;
		gP.mEventsSeen[theEvent]++;
		AddFloatingText(400.0f, 150.0f, std::format("RARE EVENT: {}", gModEvents[theEvent].mName), 255, 120, 255, 1.5f);
		Flash(theEvent == EVENT_BLOOD_MOON ? 255 : 200, theEvent == EVENT_AURORA ? 255 : 80, 200, 20);
	}

	void PickWeather(bool theAnnounce)
	{
		int w;
		if (OptI(OPT_W_MODE) == 1) w = OptI(OPT_W_TYPE);
		else
		{
			static const int kW[NUM_MOD_WEATHERS] = { 30, 15, 8, 10, 10, 8, 12, 10 };
			int total = 0;
			for (int i = 0; i < NUM_MOD_WEATHERS; i++) total += kW[i];
			int r = Rand(total);
			w = 0;
			for (int i = 0; i < NUM_MOD_WEATHERS; i++) { if (r < kW[i]) { w = i; break; } r -= kW[i]; }
		}
		gW.mPrevWeather = gW.mWeather;
		gW.mWeather = w;
		gW.mBlend = (gW.mPrevWeather == w) ? 1.0f : 0.0f;
		int interval = std::max(20, OptI(OPT_W_INTERVAL)) * 100;
		gW.mWeatherTimer = interval + RandRangeInt(-interval / 5, interval / 5);
		gW.mWindDir = Rand(2) ? 1 : -1;
		gW.mLightningTimer = 300;
		gP.mWeatherSeen[w]++;
		if (theAnnounce && w != gW.mPrevWeather)
			AddFloatingText(400.0f, 110.0f, std::format("Weather: {}", gModWeathers[w].mName), 220, 240, 255, 1.2f);
		if (On(OPT_W_RARE) && gW.mEvent == EVENT_NONE && Chance(8.0f))
			StartEvent(1 + Rand(NUM_MOD_EVENTS - 1));
	}

	void UpdateWeather(Board* b)
	{
		if (gW.mBlend < 1.0f) gW.mBlend = std::min(1.0f, gW.mBlend + 1.0f / 300.0f);
		if (gW.mWeatherClearTimer > 0) gW.mWeatherClearTimer--;
		if (gW.mEventTimer > 0 && --gW.mEventTimer == 0) gW.mEvent = EVENT_NONE;
		if (!On(OPT_W_ENABLE))
		{
			gW.mWeather = gW.mPrevWeather = WEATHER_CLEAR;
		}
		else if (--gW.mWeatherTimer <= 0)
			PickWeather(true);

		float storm = WeatherAmount(WEATHER_STORM);
		if (storm > 0.3f && --gW.mLightningTimer <= 0)
		{
			gW.mLightningTimer = static_cast<int>(RandRangeInt(450, 900) / std::max(0.5f, storm));
			StrikeLightning(b, true);
		}
		if (WeatherIs(WEATHER_WIND) && b->StageHasFog())
			b->mFogBlownCountDown = std::max(b->mFogBlownCountDown, 200);
		if (WeatherIs(WEATHER_HEAT) && gW.mTick % 600 == 0)
		{
			for (Plant* p : b->mPlants)
			{
				if (p->mDead) continue;
				SeedType s = p->mSeedType;
				if (s == SEED_SNOWPEA || s == SEED_WINTERMELON || s == SEED_ICESHROOM)
					DamagePlant(p, std::max(1, p->mPlantMaxHealth / 50));
			}
		}
		if (EventIs(EVENT_METEOR_SHOWER) && gW.mTick % 150 == 0)
		{
			std::vector<Zombie*> v;
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mPosX < 760) v.push_back(z);
			Meteor m;
			if (!v.empty()) { Zombie* z = v[Rand(static_cast<int>(v.size()))]; m.tx = z->mPosX + 40; m.ty = z->mPosY + 80; }
			else { m.tx = static_cast<float>(RandRangeInt(300, 750)); m.ty = static_cast<float>(RandRangeInt(120, 520)); }
			m.x = m.tx + 200; m.y = -40; m.life = 45; m.hitsPlants = Rand(10) == 0;
			gW.mMeteors.push_back(m);
		}
		if (EventIs(EVENT_AURORA) && gW.mTick % 900 == 0)
			b->AddCoin(RandRangeInt(100, 650), 60, COIN_SUN, COIN_MOTION_FROM_SKY);
	}

	void UpdateMeteors(Board* b)
	{
		for (Meteor& m : gW.mMeteors)
		{
			if (m.life <= 0) continue;
			m.x += (m.tx - m.x) / std::max(1, m.life);
			m.y += (m.ty - m.y) / std::max(1, m.life);
			if (--m.life == 0)
			{
				gApp->PlayFoley(FOLEY_EXPLOSION);
				gApp->AddPvzpParticle(m.tx, m.ty - 40, Board::MakeRenderOrder(RENDER_LAYER_TOP, 0, 0), PARTICLE_POWIE);
				ShakeIfAllowed(2, 2);
				for (Zombie* z : b->mZombies)
					if (IsLiveEnemy(z) && std::fabs(z->mPosX + 40 - m.tx) < 75 && std::fabs(z->mPosY + 80 - m.ty) < 60) z->TakeDamage(300, 0U);
				if (m.hitsPlants) DamagePlantsInRadius(m.tx, m.ty - 40, 60.0f, 100, false, false);
			}
		}
		gW.mMeteors.erase(std::remove_if(gW.mMeteors.begin(), gW.mMeteors.end(), [](const Meteor& m) { return m.life <= 0; }), gW.mMeteors.end());
	}

	void ChaosEvent(Board* b)
	{
		switch (Rand(8))
		{
		case 0: ModSystem::ExecuteAction(OPT_S_LIGHTNING); break;
		case 1: ModSystem::ExecuteAction(OPT_S_SUN_RAIN); break;
		case 2: for (int i = 0; i < 3; i++) ModSystem::SpawnZombie(ZOMBIE_NORMAL, -1, -1, -1, -1, 1 << Rand(NUM_MOD_MUTATIONS)); AddFloatingText(400, 160, "CHAOS: MUTANT TRIO", 255, 120, 255, 1.2f); break;
		case 3: PickWeather(true); break;
		case 4: ModSystem::ExecuteAction(OPT_S_FREEZE); break;
		case 5: StartEvent(1 + Rand(NUM_MOD_EVENTS - 1)); break;
		case 6: ModSystem::AddPlantFood(1); AddFloatingText(400, 160, "CHAOS: FREE PLANT FOOD", 120, 255, 120, 1.2f); break;
		default: ModSystem::SpawnZombie(ZOMBIE_NORMAL, -1, RandRangeInt(0, NUM_MOD_VARIANTS - 1) , Rand(NUM_MOD_CLASSES), -1, 0); AddFloatingText(400, 160, "CHAOS: SURPRISE ZOMBIE", 255, 120, 255, 1.2f); break;
		}
	}

	struct ButtonRects { Rect mMod, mPF; };
	ButtonRects GetButtons()
	{
		switch (OptI(OPT_MI_BUTTON_POS))
		{
		case 1:  return { Rect(8, 560, 74, 32), Rect(88, 560, 92, 32) };
		case 2:  return { Rect(410, 562, 74, 32), Rect(490, 562, 92, 32) };
		default: return { Rect(718, 52, 74, 30), Rect(700, 86, 92, 30) };
		}
	}

	void DrawButton(Graphics* g, const Rect& r, const std::string& theText, Color theFill, Color theText2, bool theActive)
	{
		g->SetColor(Color(0, 0, 0, 160));
		g->FillRect(r.mX + 2, r.mY + 3, r.mWidth, r.mHeight);
		g->SetColor(theFill);
		g->FillRect(r.mX, r.mY, r.mWidth, r.mHeight);
		g->SetColor(theActive ? Color(255, 255, 160) : Color(30, 20, 10));
		g->DrawRect(r.mX, r.mY, r.mWidth - 1, r.mHeight - 1);
		_Font* f = FONT_DWARVENTODCRAFT15 ? FONT_DWARVENTODCRAFT15 : FONT_PICO129;
		if (!f) return;
		g->SetFont(f);
		g->SetColor(theText2);
		int w = f->StringWidth(theText);
		g->DrawString(theText, r.mX + (r.mWidth - w) / 2, r.mY + r.mHeight / 2 + f->GetAscent() / 2 - 1);
	}

	void DrawText(Graphics* g, _Font* f, const std::string& s, int x, int y, Color c, bool theCenter = false)
	{
		if (!f) return;
		g->SetFont(f);
		int w = theCenter ? f->StringWidth(s) / 2 : 0;
		g->SetColor(Color(0, 0, 0, std::min(200, c.mAlpha)));
		g->DrawString(s, x - w + 1, y + 1);
		g->SetColor(c);
		g->DrawString(s, x - w, y);
	}

	void InitWorld(Board* b)
	{
		gW = WorldState();
		gW.mBoard = b;
		gW.mInit = true;
		gW.mWeatherTimer = 1500;
		if (On(OPT_W_ENABLE)) PickWeather(false);
		if (OptI(OPT_W_MODE) == 0 && Rand(2) == 0) { gW.mWeather = gW.mPrevWeather = WEATHER_CLEAR; }
		gW.mBlend = 1.0f;
		gW.mPlantFood = On(OPT_G_PLANT_FOOD) ? 1 : 0;
	}
}

namespace ModSystem
{
	void Init(LawnApp* theApp)
	{
		gApp = theApp;
		ModConfig::Init();
		ModConfig::Load();   // re-read in case an early query initialised the table before the data path was ready
		ProgressLoad();
	}

	void Shutdown()
	{
		ModConfig::Save();
		ProgressSave();
	}

	void AppUpdate()
	{
		static int sCounter = 0;
		if (++sCounter >= 3000)
		{
			sCounter = 0;
			ModConfig::SaveIfDirty();
			ProgressSaveIfDirty();
		}
	}

	int UpdateCountForFrame(int theBase)
	{
		if (!gApp || !gApp->mBoard || gApp->mGameScene != SCENE_PLAYING || IsMenuOpen() || theBase != 1) return theBase;
		float sp = Opt(OPT_G_SPEED) * (On(OPT_G_SLOWMO) ? 0.5f : 1.0f);
		if (std::fabs(sp - 1.0f) < 0.001f) return theBase;
		gW.mSpeedAccum += sp;
		int n = static_cast<int>(gW.mSpeedAccum);
		gW.mSpeedAccum -= n;
		return std::clamp(n, 0, 6);
	}

	void OnOptionChanged(int theOpt)
	{
		Board* b = GetBoard();
		switch (theOpt)
		{
		case OPT_Z_FREEZE:
		case OPT_Z_SPEED:
			if (b) for (Zombie* z : b->mZombies) if (!z->mDead) z->UpdateAnimSpeed();
			break;
		case OPT_E_INF_SUN:
			if (b && On(OPT_E_INF_SUN)) b->mSunMoney = 9990;
			break;
		case OPT_W_ENABLE:
		case OPT_W_MODE:
		case OPT_W_TYPE:
			if (b && gW.mInit && On(OPT_W_ENABLE)) PickWeather(true);
			break;
		case OPT_D_PRESET:
		{
			static const float kP[6][7] = {
				// hp, speed, bite, variant%, mutation%, class%, max mutations
				{ 1.0f, 1.0f, 1.0f, 15, 8, 10, 2 },
				{ 0.75f, 0.9f, 0.75f, 5, 2, 3, 1 },
				{ 1.0f, 1.0f, 1.0f, 15, 8, 10, 2 },
				{ 1.3f, 1.1f, 1.25f, 30, 15, 20, 2 },
				{ 1.75f, 1.25f, 1.5f, 50, 30, 35, 3 },
				{ 2.5f, 1.4f, 2.0f, 80, 50, 50, 4 } };
			int p = OptI(OPT_D_PRESET);
			if (p <= 0) break;
			ModConfig::Set(OPT_Z_HP, kP[p][0]); ModConfig::Set(OPT_Z_SPEED, kP[p][1]); ModConfig::Set(OPT_Z_BITE, kP[p][2]);
			ModConfig::Set(OPT_D_VARIANT_CHANCE, kP[p][3]); ModConfig::Set(OPT_MU_CHANCE, kP[p][4]); ModConfig::Set(OPT_CL_CHANCE, kP[p][5]);
			ModConfig::Set(OPT_MU_MAX, kP[p][6]);
			break;
		}
		default:
			break;
		}
	}

	void AddFloatingText(float x, float y, const std::string& theText, int r, int g, int b, float theScale)
	{
		if (gW.mTexts.size() > 60) gW.mTexts.erase(gW.mTexts.begin());
		FloatText t;
		t.x = x; t.y = y; t.vy = -0.6f; t.life = t.maxLife = 90; t.text = theText;
		t.r = static_cast<uint8_t>(r); t.g = static_cast<uint8_t>(g); t.b = static_cast<uint8_t>(b); t.scale = theScale;
		gW.mTexts.push_back(std::move(t));
	}

	void AddPlantFood(int theAmount)
	{
		gW.mPlantFood = std::clamp(gW.mPlantFood + theAmount, 0, 9);
	}

	int GetPlantFood() { return On(OPT_G_INF_PF) ? 9 : gW.mPlantFood; }

	bool InfiniteSun() { return On(OPT_E_INF_SUN) || IsMode(MODE_SANDBOX); }
	bool NoCooldown() { return On(OPT_P_NO_COOLDOWN) || IsMode(MODE_SANDBOX); }
	int  CoinValueMult() { return std::max(1, OptI(OPT_E_COIN_MULT)); }
	bool UnlockAllPlants() { return On(OPT_P_UNLOCK_ALL); }
	bool MaxSeedSlots() { return On(OPT_P_MAX_SLOTS); }
	bool UnlockAllModes() { return On(OPT_L_UNLOCK_MODES); }
	bool ShakeAllowed() { return On(OPT_V_SHAKE); }

	int AdjustSunGain(int theAmount)
	{
		if (!InPlay()) return theAmount;
		return std::max(1, static_cast<int>(theAmount * Opt(OPT_E_SUN_MULT)));
	}

	bool BlockSkySun(Board* b)
	{
		return On(OPT_G_NO_SKY_SUN) || IsMode(MODE_NO_SUN) || WeatherAmount(WEATHER_DARK) > 0.5f;
	}

	void AdjustSkySunCountdown(Board* b)
	{
		float r = Opt(OPT_G_SKY_SUN_RATE);
		if (std::fabs(r - 1.0f) > 0.001f) b->mSunCountDown = std::max(30, static_cast<int>(b->mSunCountDown / r));
	}

	BackgroundType OverrideBackground(Board* b, BackgroundType theBg)
	{
		// Only regular adventure / survival levels may change environment; mini-games and special adventure levels depend on their stage.
		if (!gApp || !(gApp->IsAdventureMode() || gApp->IsSurvivalMode())) return theBg;
		if (gApp->IsWallnutBowlingLevel() || gApp->IsWhackAZombieLevel() || gApp->IsLittleTroubleLevel() || gApp->IsScaryPotterLevel() ||
			gApp->IsBungeeBlitzLevel() || gApp->IsFinalBossLevel() || gApp->IsShovelLevel() || gApp->IsStormyNightLevel() ||
			gApp->IsSquirrelLevel() || gApp->IsIZombieLevel() || (gApp->IsAdventureMode() && gApp->IsFirstTimeAdventureMode() && b->mLevel <= 4))
			return theBg;
		BackgroundType target = theBg;
		switch (OptI(OPT_L_ENVIRONMENT))
		{
		case 1: target = BACKGROUND_1_DAY; break;
		case 2: target = BACKGROUND_2_NIGHT; break;
		case 3: target = BACKGROUND_3_POOL; break;
		case 4: target = BACKGROUND_4_FOG; break;
		case 5: target = BACKGROUND_5_ROOF; break;
		default: return theBg;
		}
		// Pool levels contain pool-only zombies (snorkel, dolphin) that need water rows: keep them on a pool stage.
		bool srcPool = theBg == BACKGROUND_3_POOL || theBg == BACKGROUND_4_FOG;
		bool dstPool = target == BACKGROUND_3_POOL || target == BACKGROUND_4_FOG;
		if (srcPool && !dstPool) return theBg;
		if (theBg != BACKGROUND_1_DAY && theBg != BACKGROUND_2_NIGHT && theBg != BACKGROUND_3_POOL && theBg != BACKGROUND_4_FOG && theBg != BACKGROUND_5_ROOF)
			return theBg;
		return target;
	}

	int OverrideRow(Board* b, ZombieType theType)
	{
		if (!IsMode(MODE_SINGLE_LANE) || !WavesModdable(b)) return -1;
		int lane = std::clamp(OptI(OPT_M_LANE), 0, kNumRows(b) - 1);
		if (b->RowCanHaveZombieType(lane, theType)) return lane;
		return -1;
	}

	bool BlockPlanting(Board* b, int theGridX, int theGridY)
	{
		if (!IsMode(MODE_SINGLE_LANE) || !WavesModdable(b)) return false;
		return theGridY != std::clamp(OptI(OPT_M_LANE), 0, kNumRows(b) - 1);
	}

	int AdjustNumWaves(Board* b, int theWaves)
	{
		if (!WavesModdable(b)) return theWaves;
		int w = OptI(OPT_L_WAVES);
		if (w > 0) theWaves = w;
		if (IsMode(MODE_ENDLESS)) theWaves = std::max(theWaves, 20);
		return std::clamp(theWaves, 1, MAX_ZOMBIE_WAVES);
	}

	int AdjustZombiePoints(Board* b, int theWave, int thePoints)
	{
		if (!WavesModdable(b)) return thePoints;
		float f = Opt(OPT_L_POINTS);
		if (IsMode(MODE_INVASION)) f *= 3.0f;
		if (IsMode(MODE_ENDLESS)) f *= 1.0f + 0.5f * gW.mEndlessCycle;
		if (On(OPT_D_ADAPTIVE)) f *= 1.0f + 0.5f * gW.mAdaptive;
		return std::max(1, static_cast<int>(thePoints * f));
	}

	// Zombie types the "all zombies on all levels" rule added on top of the level's own list.
	static bool sModAddedZombie[NUM_ZOMBIE_TYPES] = {};

	bool AllZombiesActive(Board* b)
	{
		return On(OPT_L_ALL_ZOMBIES) && WavesModdable(b) && !gApp->IsFinalBossLevel();
	}

	// Every type that can take part in normal waves on this lawn. Terrain limits are kept so nothing gets stuck:
	// snorkel/dolphin need water, digger/zomboni (and the ice-bound bobsled team) cannot work on the roof.
	std::vector<ZombieType> AllLevelTypes(Board* b)
	{
		std::vector<ZombieType> v = LandTypes(b);
		const ZombieType extra[] = { ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_JALAPENO_HEAD, ZOMBIE_GATLING_HEAD,
			ZOMBIE_SQUASH_HEAD, ZOMBIE_TALLNUT_HEAD, ZOMBIE_REDEYE_GARGANTUAR, ZOMBIE_YETI };
		for (ZombieType t : extra) v.push_back(t);
		if (!b->StageHasRoof()) v.push_back(ZOMBIE_BOBSLED);   // without ice the engine swaps the team for 4 normal zombies
		// Balloon zombies can only be stopped by Cactus/Blover/Cattail: add them only if the player can pick one.
		bool antiAir = !b->HasConveyorBeltSeedBank() &&
			(gApp->HasSeedType(SEED_CACTUS) || gApp->HasSeedType(SEED_BLOVER) || gApp->HasSeedType(SEED_CATTAIL));
		if (!antiAir) std::erase(v, ZOMBIE_BALLOON);
		return v;
	}

	void AdjustAllowedZombies(Board* b)
	{
		for (bool& f : sModAddedZombie) f = false;
		if (!WavesModdable(b)) return;
		if (AllZombiesActive(b))
		{
			for (ZombieType t : AllLevelTypes(b))
			{
				if (b->mZombieAllowed[t]) continue;
				b->mZombieAllowed[t] = true;
				sModAddedZombie[t] = true;
				Zombie::PreloadZombieResources(t);
			}
		}
		if (!(On(OPT_L_RANDOM_TYPES) || IsMode(MODE_RANDOM_ZOMBIES))) return;
		for (bool& f : sModAddedZombie) f = false;
		std::vector<ZombieType> v = LandTypes(b);
		for (int i = 0; i < NUM_ZOMBIE_TYPES; i++)
			if (i != ZOMBIE_NORMAL && i != ZOMBIE_FLAG && i != ZOMBIE_DUCKY_TUBE) b->mZombieAllowed[i] = false;
		b->mZombieAllowed[ZOMBIE_NORMAL] = true;
		for (int n = 0; n < 6 && !v.empty(); n++)
		{
			int k = Rand(static_cast<int>(v.size()));
			b->mZombieAllowed[v[k]] = true;
			v.erase(v.begin() + k);
		}
		if (b->StageHasPool()) b->mZombieAllowed[ZOMBIE_DUCKY_TUBE] = true;
	}

	int AdjustPickWeight(Board* b, ZombieType t, int theWeight)
	{
		if (t < 0 || t >= NUM_ZOMBIE_TYPES || !sModAddedZombie[t] || !AllZombiesActive(b)) return theWeight;
		// Extra types join the mix without drowning out the level's own zombies.
		if (t == ZOMBIE_IMP) return 800;
		if (t == ZOMBIE_YETI) return 400;
		if (t == ZOMBIE_REDEYE_GARGANTUAR) return 500;
		return std::clamp(theWeight / 2, 300, 1500);
	}

	int AdjustFirstAllowedWave(Board* b, ZombieType t, int theWave)
	{
		if (t < 0 || t >= NUM_ZOMBIE_TYPES || !sModAddedZombie[t] || !AllZombiesActive(b)) return theWave;
		// Short levels compress the "first wave" gate so late zombies still get a chance to show up.
		int scaled = std::max(1, theWave * std::max(1, b->mNumWaves) / 20);
		return std::min(theWave, scaled);
	}

	// ---------------- Gravestones that grow while the level progresses
	bool LivingGravesActive(Board* b)
	{
		return WavesModdable(b) && !gApp->IsFinalBossLevel() && gApp->mGameMode != GAMEMODE_CHALLENGE_WAR_AND_PEAS &&
			gApp->mGameMode != GAMEMODE_CHALLENGE_WAR_AND_PEAS_2;
	}

	// Places one gravestone on a free lawn tile (never on a plant, water or an existing grave). Returns false if none fit.
	bool SpawnProgressGrave(Board* b)
	{
		std::vector<std::pair<int, int>> cells;
		for (int c = 4; c < MAX_GRID_SIZE_X; c++)
			for (int r = 0; r < MAX_GRID_SIZE_Y; r++)
				if (b->RowCanHaveZombies(r) && b->CanAddGraveStoneAt(c, r) && !b->GetTopPlantAt(c, r, TOPPLANT_ANY))
					cells.emplace_back(c, r);
		if (cells.empty()) return false;
		auto [c, r] = cells[Rand(static_cast<int>(cells.size()))];
		b->mEnableGraveStones = true;   // lets the grave play its "push out of the ground" animation
		GridItem* g = b->AddAGraveStone(c, r);
		if (g) g->AddGraveStoneParticles();
		return g != nullptr;
	}

	ZombieType PickGraveRiser(Board* b)
	{
		std::vector<std::pair<ZombieType, int>> w = { { ZOMBIE_NORMAL, 40 }, { ZOMBIE_TRAFFIC_CONE, 30 }, { ZOMBIE_PAIL, 20 } };
		if (AllZombiesActive(b))
			for (ZombieType t : { ZOMBIE_PEA_HEAD, ZOMBIE_WALLNUT_HEAD, ZOMBIE_GATLING_HEAD, ZOMBIE_SQUASH_HEAD, ZOMBIE_JALAPENO_HEAD, ZOMBIE_TALLNUT_HEAD })
				w.emplace_back(t, 8);
		int total = 0;
		for (auto& e : w) total += e.second;
		int k = Rand(total);
		for (auto& e : w) { if (k < e.second) return e.first; k -= e.second; }
		return ZOMBIE_NORMAL;
	}

	// Zombies climb out of every fully grown gravestone (each grave has theChance % to produce one).
	int RiseFromAllGraves(Board* b, float theChance)
	{
		std::vector<GridItem*> graves;
		for (GridItem* gi : b->mGridItems)
			if (!gi->mDead && gi->mGridItemType == GRIDITEM_GRAVESTONE && gi->mGridItemCounter >= 100) graves.push_back(gi);
		int n = 0;
		for (GridItem* gi : graves)
		{
			if (!Chance(theChance)) continue;
			Zombie* z = b->AddZombie(PickGraveRiser(b), b->mCurrentWave);
			if (!z) break;
			z->RiseFromGrave(gi->mGridX, gi->mGridY);
			n++;
		}
		return n;
	}

	void UpdateProgressGraves(Board* b, int theWave, bool theFlag, bool theFinal)
	{
		if (!LivingGravesActive(b)) return;
		if (On(OPT_L_LIVING_GRAVES) && !theFinal && theWave >= 1)
		{
			float progress = b->mNumWaves > 1 ? static_cast<float>(theWave) / (b->mNumWaves - 1) : 1.0f;
			int want = theFlag ? 2 : (Chance(25.0f + 50.0f * progress) ? 1 : 0);
			for (int i = 0; i < want && gW.mProgressGraves < OptI(OPT_L_GRAVE_MAX); i++)
			{
				if (!SpawnProgressGrave(b)) break;
				gW.mProgressGraves++;
			}
		}
		if (On(OPT_L_GRAVE_RISE))
		{
			// The engine already raises grave zombies on the final wave of day/night/roof lawns and on Grave Danger flag waves.
			bool engineRises = theFinal ? !b->StageHasPool() : gApp->mGameMode == GAMEMODE_CHALLENGE_GRAVE_DANGER;
			if ((theFlag || theFinal) && !engineRises) RiseFromAllGraves(b, theFinal ? 100.0f : 60.0f);
		}
	}

	void OnWavesPicked(Board* b)
	{
		if (!WavesModdable(b)) return;
		if (IsMode(MODE_CUSTOM_WAVES))
		{
			int N = b->mNumWaves;
			for (int w = 0; w < N; w++)
			{
				int n = 0;
				float scale = 0.4f + 0.6f * (N > 1 ? static_cast<float>(w) / (N - 1) : 1.0f);
				if (b->IsFlagWave(w)) scale *= 2.0f;
				for (int g = 0; g < 4 && n < MAX_ZOMBIES_IN_WAVE - 1; g++)
				{
					int t = CustomGroupType(g);
					if (t < 0) continue;
					int cnt = std::max(CustomGroupCount(g) > 0 ? 1 : 0, static_cast<int>(std::ceil(CustomGroupCount(g) * scale)));
					for (int i = 0; i < cnt && n < MAX_ZOMBIES_IN_WAVE - 1; i++) b->mZombiesInWave[w][n++] = static_cast<ZombieType>(t);
				}
				if (b->IsFlagWave(w) && n < MAX_ZOMBIES_IN_WAVE - 1) b->mZombiesInWave[w][n++] = ZOMBIE_FLAG;
				if (n == 0) b->mZombiesInWave[w][n++] = ZOMBIE_NORMAL;
				b->mZombiesInWave[w][n] = ZOMBIE_INVALID;
			}
		}
		else if (IsMode(MODE_RANDOM_WAVES))
		{
			std::vector<ZombieType> v = LandTypes(b);
			for (int w = 0; w < b->mNumWaves; w++)
				for (int i = 0; i < MAX_ZOMBIES_IN_WAVE && b->mZombiesInWave[w][i] != ZOMBIE_INVALID; i++)
					if (b->mZombiesInWave[w][i] != ZOMBIE_FLAG && Rand(3) != 0)
						b->mZombiesInWave[w][i] = v[Rand(static_cast<int>(v.size()))];
		}
	}

	void OnWaveSpawned(Board* b, int theWave)
	{
		if (!WavesModdable(b)) return;
		RecordWave(b, theWave);
		bool flag = b->IsFlagWave(theWave);
		bool final = theWave == b->mNumWaves - 1;
		UpdateProgressGraves(b, theWave, flag, final);
		if (IsMode(MODE_BOSS_RUSH) && (flag || final))
		{
			int boss = (theWave / 10 + Rand(NUM_MOD_BOSSES)) % NUM_MOD_BOSSES;
			SpawnZombie(gModBosses[boss].mBase, -1, -1, -1, boss, 0);
		}
		if (final && Chance(Opt(OPT_B_FINAL_CHANCE)))
		{
			int boss = Rand(NUM_MOD_BOSSES);
			SpawnZombie(gModBosses[boss].mBase, -1, -1, -1, boss, 0);
		}
		if (On(OPT_CW_REPLACE) && flag && !IsMode(MODE_CUSTOM_WAVES))
			SpawnCustomWave(b);
		if (IsMode(MODE_ENDLESS) && b->mCurrentWave >= b->mNumWaves)
		{
			gW.mEndlessCycle++;
			gP.mMaxEndlessCycle = std::max(gP.mMaxEndlessCycle, gW.mEndlessCycle);
			MarkProgressDirty();
			b->PickZombieWaves();
			b->mCurrentWave = 0;
			AddFloatingText(400.0f, 140.0f, std::format("ENDLESS - CYCLE {}", gW.mEndlessCycle + 1), 255, 200, 80, 1.5f);
		}
	}

	void AdjustWaveCountdown(Board* b)
	{
		if (!WavesModdable(b)) return;
		float f = Opt(OPT_L_COUNTDOWN);
		if (IsMode(MODE_RUSH)) f /= 3.0f;
		if (std::fabs(f - 1.0f) < 0.001f) return;
		b->mZombieCountDown = std::max(8, static_cast<int>(b->mZombieCountDown * f));
		b->mZombieHealthToNextWave = static_cast<int>(b->mZombieHealthToNextWave * std::min(1.0f, 1.0f / std::max(0.2f, f)));
	}

	bool PauseSpawning(Board* b)
	{
		return InPlay() && (On(OPT_G_PAUSE_SPAWN) || IsMode(MODE_SANDBOX)) && WavesModdable(b);
	}

	void BoardInitLevel(Board* b)
	{
		InitWorld(b);
		if (!WavesModdable(b)) return;
		if (OptI(OPT_E_START_SUN) > 0) b->mSunMoney = OptI(OPT_E_START_SUN);
		if (IsMode(MODE_NO_SUN)) b->mSunMoney = std::max(b->mSunMoney, 1500);
		if (InfiniteSun()) b->mSunMoney = 9990;
	}

	void BoardLevelStart(Board* b)
	{
		if (!gW.mInit || gW.mBoard != b) InitWorld(b);
		if (!WavesModdable(b)) return;
		if (On(OPT_G_NO_MOWERS) || IsMode(MODE_HARDCORE))
			for (LawnMower* m : b->mLawnMowers) if (!m->mDead) m->Die();
		if (OptI(OPT_L_ENVIRONMENT) == 5 && b->StageHasRoof())
		{
			for (int r = 0; r < kNumRows(b); r++)
				for (int c = 0; c < 3; c++)
					if (!b->GetTopPlantAt(c, r, TOPPLANT_ANY)) b->AddPlant(c, r, SEED_FLOWERPOT, SEED_NONE);
		}
		if (IsMode(MODE_RANDOM_PLANTS) && !b->HasConveyorBeltSeedBank() && !gApp->IsChallengeWithoutSeedBank())
		{
			std::vector<SeedType> v;
			for (int s = 0; s < NUM_SEEDS_IN_CHOOSER; s++)
			{
				SeedType st = static_cast<SeedType>(s);
				if (st == SEED_IMITATER || Plant::IsUpgrade(st)) continue;
				if (!b->StageHasPool() && Plant::IsAquatic(st)) continue;
				if (!b->StageHasRoof() && st == SEED_FLOWERPOT) continue;
				v.push_back(st);
			}
			for (int i = 0; i < b->mSeedBank->mNumPackets && !v.empty(); i++)
			{
				int k = Rand(static_cast<int>(v.size()));
				b->mSeedBank->mSeedPackets[i].SetPacketType(v[k]);
				v.erase(v.begin() + k);
			}
			AddFloatingText(400.0f, 140.0f, "RANDOM PLANTS!", 255, 230, 120, 1.4f);
		}
		if (Mode() != MODE_NONE)
			AddFloatingText(400.0f, 180.0f, std::format("MODE: {}", gModGameModes[Mode()].mName), 255, 200, 80, 1.4f);
	}

	void BoardUpdate(Board* b)
	{
		if (!gW.mInit || gW.mBoard != b) InitWorld(b);
		if (!gW.mResultCounted && WavesModdable(b))
		{
			if (b->mLevelAwardSpawned) { gP.mLevelsWon++; gW.mResultCounted = true; MarkProgressDirty(); ProgressSaveIfDirty(); }
			else if (gApp->mGameScene == SCENE_ZOMBIES_WON) { gP.mLevelsLost++; gW.mResultCounted = true; MarkProgressDirty(); ProgressSaveIfDirty(); }
		}
		if (gApp->mGameScene != SCENE_PLAYING) return;
		gW.mTick++;
		UpdateWeather(b);
		UpdateMeteors(b);
		if (gW.mTick % 30 == 0) UpdateAuras(b);
		if (gW.mTick % 60 == 0) UpdatePlantCombos(b);
		if (gW.mFlash > 0) gW.mFlash--;
		if (gW.mPlantShieldTimer > 0) gW.mPlantShieldTimer--;
		if (gW.mShatterTimer > 0) gW.mShatterTimer--;
		for (FloatText& t : gW.mTexts) { t.y += t.vy; t.life--; }
		gW.mTexts.erase(std::remove_if(gW.mTexts.begin(), gW.mTexts.end(), [](const FloatText& t) { return t.life <= 0; }), gW.mTexts.end());
		for (Bolt& bo : gW.mBolts) bo.life--;
		gW.mBolts.erase(std::remove_if(gW.mBolts.begin(), gW.mBolts.end(), [](const Bolt& x) { return x.life <= 0; }), gW.mBolts.end());

		if (InfiniteSun()) b->mSunMoney = 9990;
		if (On(OPT_G_INF_MOWERS) && gW.mTick % 300 == 0 && WavesModdable(b)) RestoreMowers(b);
		if (On(OPT_G_AUTO_COLLECT))
			for (Coin* c : b->mCoins)
				if (!c->mDead && !c->mIsBeingCollected && (c->IsSun() || c->IsMoney()) && c->mCoinAge > 60) c->Collect();
		if (gW.mEmberTimer > 0)
		{
			gW.mEmberTimer--;
			if (gW.mEmberTimer % 30 == 0)
				for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mRow == gW.mEmberRow) z->TakeDamage(20, 0U);
		}
		if (On(OPT_X_CHAOS) && ++gW.mChaosTimer >= 2000) { gW.mChaosTimer = 0; ChaosEvent(b); }
		if (On(OPT_D_ADAPTIVE) && gW.mTick % 1000 == 0)
		{
			if (gW.mPlantsLost == 0) gW.mAdaptive = std::min(1.5f, gW.mAdaptive + 0.1f);
			else gW.mAdaptive = std::max(0.0f, gW.mAdaptive - 0.05f * gW.mPlantsLost);
			gW.mPlantsLost = 0;
		}
		else if (!On(OPT_D_ADAPTIVE)) gW.mAdaptive = 0.0f;
		int cap = OptI(OPT_Z_MAX_ON_SCREEN);
		if (cap > 0 && gW.mTick % 10 == 0)
		{
			int n = 0;
			for (Zombie* z : b->mZombies) if (!z->mDead && !z->IsDeadOrDying()) n++;
			if (n > cap)
				for (Zombie* z : b->mZombies)
					if (n > cap && !z->mDead && !z->IsDeadOrDying() && z->mPosX > 800 && z->mMod.mBoss < 0) { z->DieNoLoot(); n--; }
		}
		if (gW.mPFArmed && GetPlantFood() <= 0) gW.mPFArmed = false;
	}

	bool BoardBusyWithMod() { return IsMenuOpen(); }

	bool BoardMouseDown(Board* b, int x, int y, int theClickCount)
	{
		gW.mConsumedMouse = false;
		if (gApp->mGameScene != SCENE_PLAYING && gApp->mGameScene != SCENE_LEVEL_INTRO) return false;
		ButtonRects r = GetButtons();
		if (r.mMod.Contains(x, y))
		{
			gApp->PlaySample(SOUND_BUTTONCLICK);
			OpenMenu();
			gW.mConsumedMouse = true;
			return true;
		}
		if (gApp->mGameScene != SCENE_PLAYING) return false;
		if (On(OPT_G_PLANT_FOOD) && r.mPF.Contains(x, y))
		{
			if (GetPlantFood() > 0) { gW.mPFArmed = !gW.mPFArmed; gApp->PlaySample(SOUND_BUTTONCLICK); }
			else gApp->PlaySample(SOUND_BUZZER);
			gW.mConsumedMouse = true;
			return true;
		}
		if (gW.mPFArmed)
		{
			gW.mPFArmed = false;
			int gx = b->PixelToGridX(x, y), gy = b->PixelToGridY(x, y);
			Plant* p = nullptr;
			if (gx >= 0 && gy >= 0)
			{
				p = b->GetTopPlantAt(gx, gy, TOPPLANT_ONLY_NORMAL_POSITION);
				if (!p) p = b->GetTopPlantAt(gx, gy, TOPPLANT_ANY);
			}
			if (p)
			{
				ApplyPlantFood(p);
				if (!On(OPT_G_INF_PF)) gW.mPlantFood = std::max(0, gW.mPlantFood - 1);
			}
			gW.mConsumedMouse = true;
			return true;
		}
		if (IsMode(MODE_SANDBOX) && b->mCursorObject && b->mCursorObject->mCursorType == CURSOR_TYPE_NORMAL && x > 560 && y > 80)
		{
			HitResult hr;
			b->MouseHitTest(x, y, &hr);
			if (hr.mObjectType == GameObjectType::OBJECT_TYPE_NONE)
			{
				int gy = b->PixelToGridYKeepOnBoard(x, y);
				int t = OptI(OPT_Z_SPAWN_TYPE);
				Zombie* z = SpawnZombie(gModSpawnableZombieTypes[std::clamp(t, 0, NUM_MOD_SPAWNABLE_ZOMBIES - 1)], gy, -1, -1, -1, 0);
				if (z && z->mZombieType != ZOMBIE_BUNGEE) { z->mPosX = std::max(static_cast<float>(x) - 40.0f, 500.0f); z->mX = static_cast<int>(z->mPosX); }
				gW.mConsumedMouse = true;
				return true;
			}
		}
		return false;
	}

	bool BoardMouseUp(Board* b, int x, int y)
	{
		bool c = gW.mConsumedMouse;
		gW.mConsumedMouse = false;
		return c;
	}

	bool BoardKeyDown(Board* b, int theKey)
	{
		if (theKey == KEYCODE_F2)
		{
			OpenMenu();
			return true;
		}
		return false;
	}

	void DrawOverlay(Board* b, Graphics* g)
	{
		if (!InPlay() || !On(OPT_V_WEATHER_FX)) return;
		bool low = On(OPT_V_LOW_FX);
		uint32_t t = gW.mTick;
		float rain = std::min(2.0f, WeatherAmount(WEATHER_RAIN) + WeatherAmount(WEATHER_STORM));
		float snow = std::min(2.0f, WeatherAmount(WEATHER_SNOW));
		float fog = std::min(2.0f, WeatherAmount(WEATHER_FOG));
		float dark = std::min(2.0f, WeatherAmount(WEATHER_DARK));
		float wind = std::min(2.0f, WeatherAmount(WEATHER_WIND));
		float heat = std::min(2.0f, WeatherAmount(WEATHER_HEAT));
		if (heat > 0.01f)
		{
			g->SetColor(Color(255, 150, 40, static_cast<int>(30 * heat)));
			g->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
			for (int i = 0; i < (low ? 6 : 14); i++)
			{
				int y = (i * 47 + static_cast<int>(t)) % 600;
				g->SetColor(Color(255, 220, 160, static_cast<int>(25 * heat)));
				g->FillRect(0, y, BOARD_WIDTH, 2);
			}
		}
		if (dark > 0.01f)
		{
			g->SetColor(Color(5, 5, 25, static_cast<int>(std::min(170.0f, 110 * dark))));
			g->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
		}
		if (EventIs(EVENT_BLOOD_MOON))
		{
			g->SetColor(Color(160, 0, 0, 45));
			g->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
		}
		if (EventIs(EVENT_AURORA))
		{
			for (int i = 0; i < 4; i++)
			{
				int a = 30 + static_cast<int>(20 * std::sin(t * 0.03f + i));
				g->SetColor(i % 2 ? Color(120, 255, 180, a) : Color(180, 120, 255, a));
				g->FillRect(0, i * 18, BOARD_WIDTH, 18);
			}
		}
		if (fog > 0.01f)
		{
			for (int i = 0; i < 6; i++)
			{
				int x = 380 + i * 70;
				g->SetColor(Color(200, 205, 215, static_cast<int>(std::min(200.0f, (20 + i * 18) * fog))));
				g->FillRect(x, 70, 70, 530);
			}
		}
		if (rain > 0.01f)
		{
			int n = static_cast<int>((low ? 40 : 90) * rain);
			g->SetColor(Color(170, 190, 255, 140));
			for (int i = 0; i < n; i++)
			{
				int x = static_cast<int>((i * 97 + t * 5) % 900) - 50;
				int y = static_cast<int>((i * 53 + t * 14) % 650) - 30;
				g->DrawLine(x, y, x - 4, y + 16);
			}
			if (WeatherIs(WEATHER_STORM))
			{
				g->SetColor(Color(0, 0, 20, static_cast<int>(50 * WeatherAmount(WEATHER_STORM))));
				g->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
			}
		}
		if (snow > 0.01f)
		{
			int n = static_cast<int>((low ? 35 : 80) * snow);
			g->SetColor(Color(255, 255, 255, 200));
			for (int i = 0; i < n; i++)
			{
				float x = static_cast<float>((i * 131) % 820) + 15.0f * std::sin((t + i * 37) * 0.03f) + gW.mWindDir * (t % 800) * 0.2f * (wind > 0 ? 1 : 0);
				int y = static_cast<int>((i * 71 + t * 2) % 640) - 20;
				int xi = (static_cast<int>(x) % 820 + 820) % 820;
				g->FillRect(xi, y, 3, 3);
			}
			g->SetColor(Color(220, 235, 255, static_cast<int>(25 * snow)));
			g->FillRect(0, 0, BOARD_WIDTH, BOARD_HEIGHT);
		}
		if (wind > 0.01f)
		{
			int n = static_cast<int>((low ? 8 : 18) * wind);
			g->SetColor(Color(255, 255, 255, 90));
			for (int i = 0; i < n; i++)
			{
				int y = (i * 61) % 560 + 40;
				int x = static_cast<int>((i * 173 + t * 9 * gW.mWindDir) % 1000 + 1000) % 1000 - 100;
				g->FillRect(x, y, 50, 1);
			}
		}
	}

	void DrawHUD(Board* b, Graphics* g)
	{
		if (gApp->mGameScene != SCENE_PLAYING && gApp->mGameScene != SCENE_LEVEL_INTRO) return;
		if (gApp->mGameScene == SCENE_PLAYING)
		{
			// lightning bolts
			for (const Bolt& bo : gW.mBolts)
			{
				int a = std::clamp(bo.life * 18, 0, 255);
				g->SetColor(Color(bo.r, bo.g, bo.b, a));
				float px = bo.x1, py = bo.y1;
				const int seg = 6;
				for (int i = 1; i <= seg; i++)
				{
					float f = static_cast<float>(i) / seg;
					float nx = bo.x1 + (bo.x2 - bo.x1) * f + (i < seg ? static_cast<float>(((i * 37 + bo.life * 11) % 21) - 10) : 0.0f);
					float ny = bo.y1 + (bo.y2 - bo.y1) * f;
					g->DrawLine(static_cast<int>(px), static_cast<int>(py), static_cast<int>(nx), static_cast<int>(ny));
					g->DrawLine(static_cast<int>(px) + 1, static_cast<int>(py), static_cast<int>(nx) + 1, static_cast<int>(ny));
					px = nx; py = ny;
				}
			}
			for (const Meteor& m : gW.mMeteors)
			{
				g->SetColor(Color(255, 140, 40, 200));
				g->FillRect(static_cast<int>(m.x) - 7, static_cast<int>(m.y) - 7, 14, 14);
				g->SetColor(Color(255, 230, 120, 230));
				g->FillRect(static_cast<int>(m.x) - 4, static_cast<int>(m.y) - 4, 8, 8);
				g->SetColor(Color(255, 120, 40, 90));
				g->FillRect(static_cast<int>(m.x) + 6, static_cast<int>(m.y) - 14, 10, 8);
			}
			// floating texts
			for (const FloatText& t : gW.mTexts)
			{
				_Font* f = t.scale >= 1.3f ? FONT_HOUSEOFTERROR20 : t.scale >= 1.05f ? FONT_DWARVENTODCRAFT18 : FONT_DWARVENTODCRAFT12;
				if (!f) f = FONT_PICO129;
				int a = std::clamp(t.life * 255 / 30, 0, 255);
				DrawText(g, f, t.text, static_cast<int>(t.x), static_cast<int>(t.y), Color(t.r, t.g, t.b, a), true);
			}
			// boss bars
			if (On(OPT_V_BOSS_BAR))
			{
				int n = 0;
				for (Zombie* z : b->mZombies)
				{
					if (z->mDead || z->IsDeadOrDying() || z->mMod.mBoss < 0 || n >= 2) continue;
					const ModBossDef& d = gModBosses[z->mMod.mBoss];
					int x = 210, y = 92 + n * 30, w = 380;
					float fr = z->mBodyMaxHealth > 0 ? std::clamp(static_cast<float>(z->mBodyHealth) / z->mBodyMaxHealth, 0.0f, 1.0f) : 0.0f;
					g->SetColor(Color(0, 0, 0, 170));
					g->FillRect(x - 3, y - 3, w + 6, 18);
					g->SetColor(Color(70, 10, 10, 220));
					g->FillRect(x, y, w, 12);
					g->SetColor(Color(d.mR, d.mG, d.mB, 240));
					g->FillRect(x, y, static_cast<int>(w * fr), 12);
					if (z->mMod.mShieldHP > 0 && z->mMod.mShieldMax > 0)
					{
						g->SetColor(Color(130, 200, 255, 230));
						g->FillRect(x, y + 10, static_cast<int>(w * static_cast<float>(z->mMod.mShieldHP) / z->mMod.mShieldMax), 3);
					}
					g->SetColor(Color(255, 255, 255, 120));
					g->FillRect(x + w / 3, y, 1, 12);
					g->FillRect(x + 2 * w / 3, y, 1, 12);
					DrawText(g, FONT_PICO129, std::format("{}  -  Phase {}  -  {}", d.mName, z->mMod.mBossPhase + 1, z->mBodyHealth), x + w / 2, y + 10, Color(255, 255, 255), true);
					n++;
				}
			}
			// info panel
			if (On(OPT_V_HUD))
			{
				std::vector<std::string> lines;
				if (Mode() != MODE_NONE) lines.push_back(std::format("Mode: {}", gModGameModes[Mode()].mName));
				if (IsMode(MODE_ENDLESS)) lines.push_back(std::format("Endless cycle {}", gW.mEndlessCycle + 1));
				if (On(OPT_W_ENABLE) && gW.mWeather != WEATHER_CLEAR)
					lines.push_back(gW.mWeatherClearTimer > 0 ? std::string("Weather: cleared") : std::format("Weather: {}", gModWeathers[gW.mWeather].mName));
				if (EventIs(gW.mEvent) && gW.mEvent != EVENT_NONE) lines.push_back(std::format("Event: {}", gModEvents[gW.mEvent].mName));
				if (b->mNumWaves > 0) lines.push_back(std::format("Wave {}/{}", std::min(b->mCurrentWave, b->mNumWaves), b->mNumWaves));
				if (On(OPT_D_ADAPTIVE)) lines.push_back(std::format("Threat +{}%", static_cast<int>(gW.mAdaptive * 100)));
				int y0 = OptI(OPT_MI_BUTTON_POS) == 0 ? 122 : 92;
				int x0 = 668;
				if (!lines.empty() && FONT_PICO129)
				{
					g->SetColor(Color(0, 0, 0, 110));
					g->FillRect(x0 - 4, y0 - 2, 132, static_cast<int>(lines.size()) * 11 + 4);
					for (size_t i = 0; i < lines.size(); i++)
						DrawText(g, FONT_PICO129, lines[i], x0, y0 + 9 + static_cast<int>(i) * 11, Color(230, 240, 255));
				}
			}
			if (gW.mFlash > 0)
			{
				g->SetColor(Color(gW.mFlashR, gW.mFlashG, gW.mFlashB, std::min(160, gW.mFlash * 10)));
				g->FillRect(-50, -50, BOARD_WIDTH + 100, BOARD_HEIGHT + 100);
			}
		}
		ButtonRects r = GetButtons();
		DrawButton(g, r.mMod, "MOD", Color(120, 70, 30, 230), Color(255, 230, 150), false);
		if (On(OPT_G_PLANT_FOOD) && gApp->mGameScene == SCENE_PLAYING)
		{
			std::string s = On(OPT_G_INF_PF) ? "PF: inf" : std::format("PF: {}", gW.mPlantFood);
			DrawButton(g, r.mPF, s, gW.mPFArmed ? Color(60, 170, 60, 240) : Color(40, 110, 40, 220), Color(220, 255, 200), gW.mPFArmed);
			if (gW.mPFArmed)
				DrawText(g, FONT_PICO129, "Tap a plant", r.mPF.mX + r.mPF.mWidth / 2, r.mPF.mY + r.mPF.mHeight + 10, Color(200, 255, 180), true);
		}
	}

	void ExecuteAction(int theOpt)
	{
		Board* b = GetBoard();
		gActionMsg.clear();
		switch (theOpt)
		{
		case OPT_MI_RESET: ModConfig::ResetAll(); gActionMsg = "All settings restored to default"; return;
		case OPT_MI_SAVE: ModConfig::Save(); ProgressSave(); gActionMsg = "Settings saved"; return;
		case OPT_MI_RESET_STATS: ProgressReset(); gActionMsg = "Statistics cleared"; return;
		case OPT_E_ADD_COINS: gApp->mPlayerInfo->AddCoins(1000); gActionMsg = "+$10,000"; return;
		case OPT_L_SET_ADV_LEVEL:
			gApp->mPlayerInfo->mLevel = std::clamp(OptI(OPT_L_ADV_LEVEL), 1, 50);
			gActionMsg = std::format("Adventure progress set to level {}-{}", (gApp->mPlayerInfo->mLevel - 1) / 10 + 1, (gApp->mPlayerInfo->mLevel - 1) % 10 + 1);
			return;
		default: break;
		}
		if (!b || !InPlay())
		{
			gActionMsg = "Start a level first";
			return;
		}
		int rows = kNumRows(b);
		switch (theOpt)
		{
		case OPT_Z_SPAWN_NOW:
		{
			int t = std::clamp(OptI(OPT_Z_SPAWN_TYPE), 0, NUM_MOD_SPAWNABLE_ZOMBIES - 1);
			int row = OptI(OPT_Z_SPAWN_ROW) - 1;
			int n = 0;
			for (int i = 0; i < OptI(OPT_Z_SPAWN_COUNT); i++)
				if (SpawnZombie(gModSpawnableZombieTypes[t], row >= rows ? -1 : row, -1, -1, -1, 0)) n++;
			gActionMsg = std::format("Spawned {} x {}", n, gModSpawnableZombieNames[t]);
			break;
		}
		case OPT_Z_VARIANT_SPAWN:
		{
			int v = std::clamp(OptI(OPT_Z_VARIANT_SEL), 0, NUM_MOD_VARIANTS - 1);
			int row = OptI(OPT_Z_SPAWN_ROW) - 1;
			Zombie* z = SpawnZombie(gModVariants[v].mBase, row >= rows ? -1 : row, v, -1, -1, 0);
			gActionMsg = z ? std::format("Spawned {}", gModVariants[v].mName) : "This zombie cannot appear on this lawn";
			break;
		}
		case OPT_Z_KILL_ALL:
		{
			int n = 0;
			for (Zombie* z : b->mZombies)
				if (IsLiveEnemy(z) || (!z->mDead && !z->IsDeadOrDying() && !z->mMindControlled)) { z->TakeDamage(100000, 0U); n++; }
			gActionMsg = std::format("Defeated {} zombies", n);
			break;
		}
		case OPT_Z_HYPNO_ALL:
			for (Zombie* z : b->mZombies)
				if (!z->mDead && !z->IsDeadOrDying() && !z->mMindControlled && z->mZombieType != ZOMBIE_BOSS && z->mMod.mBoss < 0 && z->mHasHead) z->StartMindControlled();
			gActionMsg = "Zombies hypnotized";
			break;
		case OPT_Z_PUSH_BACK:
			for (Zombie* z : b->mZombies)
				if (IsLiveEnemy(z) && z->mZombieType != ZOMBIE_BOSS && z->mZombieType != ZOMBIE_BUNGEE) { z->mPosX = std::min(820.0f, z->mPosX + 160.0f); z->mX = static_cast<int>(z->mPosX); }
			gActionMsg = "Zombies pushed back";
			break;
		case OPT_Z_STRIP_ARMOR:
			for (Zombie* z : b->mZombies)
			{
				if (!IsLiveEnemy(z)) continue;
				if (z->mHelmType != HELMTYPE_NONE && z->mHelmHealth > 0) z->TakeHelmDamage(z->mHelmHealth, 0U);
				if (z->mShieldType != SHIELDTYPE_NONE && z->mShieldHealth > 0) z->TakeShieldDamage(z->mShieldHealth, 0U);
				z->mMod.mShieldHP = 0;
			}
			gActionMsg = "Armor removed";
			break;
		case OPT_Z_BUTTER_ALL:
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mZombieType != ZOMBIE_BOSS) z->ApplyButter();
			gActionMsg = "Zombies buttered";
			break;
		case OPT_Z_CHILL_ALL:
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z)) z->ApplyChill(false);
			gActionMsg = "Zombies chilled";
			break;
		case OPT_P_HEAL_ALL:
			for (Plant* p : b->mPlants) if (!p->mDead) { p->mPlantHealth = p->mPlantMaxHealth; p->mMod.mPoison = p->mMod.mFrozen = p->mMod.mDisabled = 0; }
			gActionMsg = "Plants healed";
			break;
		case OPT_PA_EVOLVE_ALL:
			for (Plant* p : b->mPlants) if (!p->mDead) AddPlantXP(p, 100000);
			gActionMsg = "Plants evolved";
			break;
		case OPT_G_NEXT_WAVE:
			if (b->mHugeWaveCountDown > 0) b->mHugeWaveCountDown = 1;
			else if (b->mCurrentWave < b->mNumWaves) b->mZombieCountDown = 6;
			gActionMsg = "Next wave incoming";
			break;
		case OPT_G_WIN:
			if (gApp->IsContinuousChallenge() || gApp->IsScaryPotterLevel() || gApp->IsIZombieLevel() || gApp->IsSurvivalMode())
			{
				gActionMsg = "Not available in this mode";
				break;
			}
			if (IsMode(MODE_ENDLESS)) ModConfig::Set(OPT_M_MODE, MODE_NONE);
			b->mCurrentWave = b->mNumWaves;
			{
				bool any = false;
				for (Zombie* z : b->mZombies) if (!z->mDead && !z->mMindControlled) any = true;
				if (!any) SpawnZombie(ZOMBIE_NORMAL, -1, -1, -1, -1, 0);
				for (Zombie* z : b->mZombies)
					if (!z->mDead && !z->mMindControlled) z->DieWithLoot();
			}
			gActionMsg = "Level won!";
			break;
		case OPT_G_RESTORE_MOWERS: RestoreMowers(b); gActionMsg = "Lawn mowers restored"; break;
		case OPT_G_ADD_PF: AddPlantFood(3); gActionMsg = "+3 Plant Food"; break;
		case OPT_E_ADD_SUN: b->AddSunMoney(1000); gActionMsg = "+1000 sun"; break;
		case OPT_E_SET_SUN: b->mSunMoney = std::clamp(OptI(OPT_E_SUN_VALUE), 0, 9990); gActionMsg = "Sun set"; break;
		case OPT_L_ADD_GRAVES:
		{
			int n = 0;
			while (n < 5 && SpawnProgressGrave(b)) n++;
			gActionMsg = std::format("{} graves added", n);
			break;
		}
		case OPT_L_REMOVE_GRAVES:
		{
			int n = 0;
			for (GridItem* gi : b->mGridItems)
				if (!gi->mDead && (gi->mGridItemType == GRIDITEM_GRAVESTONE || gi->mGridItemType == GRIDITEM_CRATER)) { gi->GridItemDie(); n++; }
			gActionMsg = std::format("{} graves/craters removed", n);
			break;
		}
		case OPT_CW_SPAWN: SpawnCustomWave(b); break;
		case OPT_W_NEXT: PickWeather(true); gActionMsg = std::format("Weather: {}", gModWeathers[gW.mWeather].mName); break;
		case OPT_W_TRIGGER_RARE: StartEvent(1 + Rand(NUM_MOD_EVENTS - 1)); gActionMsg = std::format("Event: {}", gModEvents[gW.mEvent].mName); break;
		case OPT_B_SPAWN:
		{
			int bi = std::clamp(OptI(OPT_B_SELECT), 0, NUM_MOD_BOSSES - 1);
			Zombie* z = SpawnZombie(gModBosses[bi].mBase, -1, -1, -1, bi, 0);
			gActionMsg = z ? std::format("{} has arrived!", gModBosses[bi].mName) : "The boss cannot appear on this lawn";
			break;
		}
		case OPT_S_LIGHTNING:
		{
			std::vector<Zombie*> v;
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mPosX < 800) v.push_back(z);
			for (int i = 0; i < 5 && !v.empty(); i++)
			{
				int k = Rand(static_cast<int>(v.size()));
				Zombie* z = v[k];
				AddBolt(z->mPosX + 40 + RandRangeInt(-50, 50), -10.0f, z->mPosX + 40, z->mPosY + 60, 230, 240, 255);
				z->TakeDamage(600, 0U);
				v.erase(v.begin() + k);
			}
			Flash(230, 235, 255, 10);
			gApp->PlayFoley(FOLEY_THUNDER);
			gActionMsg = "Lightning strike!";
			break;
		}
		case OPT_S_METEOR:
			for (int i = 0; i < 8; i++)
			{
				Meteor m;
				m.tx = static_cast<float>(RandRangeInt(300, 760)); m.ty = static_cast<float>(b->GridToPixelY(0, Rand(rows)) + 80);
				for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && Rand(3) == 0 && z->mPosX < 780) { m.tx = z->mPosX + 40; m.ty = z->mPosY + 80; break; }
				m.x = m.tx + 200; m.y = -40.0f - i * 30; m.life = 40 + i * 8; m.hitsPlants = false;
				gW.mMeteors.push_back(m);
			}
			gActionMsg = "Meteor shower!";
			break;
		case OPT_S_FREEZE:
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z)) FreezeZombie(z, 400);
			gApp->PlayFoley(FOLEY_FROZEN);
			Flash(180, 230, 255, 15);
			gActionMsg = "Freeze wave!";
			break;
		case OPT_S_SUN_RAIN:
			for (int i = 0; i < 10; i++) b->AddCoin(RandRangeInt(100, 650), 60 - i * 10, COIN_SUN, COIN_MOTION_FROM_SKY);
			gActionMsg = "Sun rain!";
			break;
		case OPT_S_SHIELD: gW.mPlantShieldTimer = 1000; gActionMsg = "Plants shielded for 10 seconds"; break;
		case OPT_S_QUAKE:
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && !z->IsFlying()) z->TakeDamage(300, 0U);
			if (b) b->ShakeBoard(6, 6);
			Flash(140, 100, 60, 12);
			gApp->PlayFoley(FOLEY_THUMP);
			gActionMsg = "Earthquake!";
			break;
		case OPT_S_MOWERS:
			for (LawnMower* m : b->mLawnMowers) if (!m->mDead && m->mMowerState == MOWER_READY) m->StartMower();
			gActionMsg = "Lawn mowers charging!";
			break;
		case OPT_S_PF_ALL:
			for (Plant* p : b->mPlants) if (!p->mDead && p->mSeedType != SEED_LILYPAD && p->mSeedType != SEED_FLOWERPOT) ApplyPlantFood(p);
			gActionMsg = "Plant Food for everyone!";
			break;
		case OPT_S_COINS:
			for (int i = 0; i < 15; i++) b->AddCoin(RandRangeInt(150, 700), RandRangeInt(150, 450), Rand(5) == 0 ? COIN_GOLD : COIN_SILVER, COIN_MOTION_COIN);
			gActionMsg = "Coin shower!";
			break;
		case OPT_S_BLIZZARD:
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z)) { z->ApplyChill(false); FreezeZombie(z, 120); }
			gW.mPrevWeather = gW.mWeather; gW.mWeather = WEATHER_SNOW; gW.mBlend = 0.0f; gW.mWeatherTimer = 3000;
			gActionMsg = "Blizzard!";
			break;
		case OPT_S_FIRESTORM:
		{
			int best = 0, bestN = -1;
			for (int r = 0; r < rows; r++)
			{
				int n = 0;
				for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mRow == r) n++;
				if (n > bestN) { bestN = n; best = r; }
			}
			b->DoFwoosh(best);
			gApp->PlayFoley(FOLEY_JALAPENO_IGNITE);
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->mRow == best && z->mPosX < 800) z->ApplyBurn();
			gActionMsg = std::format("Lane {} burned", best + 1);
			break;
		}
		case OPT_S_GRAVITY:
		{
			int n = 0;
			for (Zombie* z : b->mZombies) if (IsLiveEnemy(z) && z->IsFlying()) { z->LandFlyer(0U); n++; }
			gActionMsg = std::format("{} flying zombies grounded", n);
			break;
		}
		default:
			break;
		}
	}
}
