// PvZ Living Nightmare - persistent statistics, records, unlocks and plant experience.
#include "ModInternal.h"

#include <fstream>
#include <sstream>

using namespace ModInt;

namespace
{
	bool sDirty = false;

	std::string ProgressPath() { return Sexy::GetAppDataPath("living_nightmare_progress.cfg"); }

	template <size_t N>
	std::string Join(const int (&a)[N])
	{
		std::string s;
		for (size_t i = 0; i < N; i++) { if (i) s += ','; s += std::to_string(a[i]); }
		return s;
	}

	template <size_t N>
	void Split(const std::string& s, int (&a)[N])
	{
		std::stringstream ss(s);
		std::string item;
		size_t i = 0;
		while (i < N && std::getline(ss, item, ','))
			a[i++] = std::max(0, std::atoi(item.c_str()));
	}
}

namespace ModInt
{
	Progress gP;

	void MarkProgressDirty() { sDirty = true; }

	void ProgressReset()
	{
		gP = Progress();
		sDirty = true;
		ProgressSave();
	}

	void ProgressLoad()
	{
		std::ifstream f(PathFromU8(ProgressPath()));
		if (!f.is_open()) return;
		std::string line;
		while (std::getline(f, line))
		{
			size_t eq = line.find('=');
			if (eq == std::string::npos || line[0] == '#') continue;
			std::string k = line.substr(0, eq), v = line.substr(eq + 1);
			if (!v.empty() && v.back() == '\r') v.pop_back();
			int iv = std::atoi(v.c_str());
			if (k == "total_kills") gP.mTotalKills = iv;
			else if (k == "variant_kills") Split(v, gP.mVariantKills);
			else if (k == "variant_seen") Split(v, gP.mVariantSeen);
			else if (k == "class_kills") Split(v, gP.mClassKills);
			else if (k == "mutation_kills") Split(v, gP.mMutationKills);
			else if (k == "combo_kills") Split(v, gP.mComboKills);
			else if (k == "boss_kills") Split(v, gP.mBossKills);
			else if (k == "boss_seen") Split(v, gP.mBossSeen);
			else if (k == "plant_xp") Split(v, gP.mPlantXP);
			else if (k == "weather_seen") Split(v, gP.mWeatherSeen);
			else if (k == "events_seen") Split(v, gP.mEventsSeen);
			else if (k == "max_endless") gP.mMaxEndlessCycle = iv;
			else if (k == "max_wave") gP.mMaxWave = iv;
			else if (k == "pf_used") gP.mPlantFoodUsed = iv;
			else if (k == "evolved") gP.mEvolvedPlants = iv;
			else if (k == "levels_won") gP.mLevelsWon = iv;
			else if (k == "levels_lost") gP.mLevelsLost = iv;
			else if (k == "lightning") gP.mLightningStrikes = iv;
			else if (k == "max_hit") gP.mMaxDamageHit = iv;
			else if (k == "wave")
			{
				WaveRecord r{};
				if (std::sscanf(v.c_str(), "%d,%d,%d,%d,%d,%d", &r.mScore, &r.mWave, &r.mLevel, &r.mMode, &r.mZombies, &r.mSpecials) == 6 && gP.mHardestWaves.size() < 10)
					gP.mHardestWaves.push_back(r);
			}
		}
		sDirty = false;
	}

	void ProgressSave()
	{
		std::string aPath = ProgressPath();
		std::string aTmp = aPath + ".tmp";
		{
			std::ofstream f(PathFromU8(aTmp), std::ios::trunc);
			if (!f.is_open()) return;
			f << "# PvZ Living Nightmare progress (auto-saved)\n";
			f << "total_kills=" << gP.mTotalKills << '\n';
			f << "variant_kills=" << Join(gP.mVariantKills) << '\n';
			f << "variant_seen=" << Join(gP.mVariantSeen) << '\n';
			f << "class_kills=" << Join(gP.mClassKills) << '\n';
			f << "mutation_kills=" << Join(gP.mMutationKills) << '\n';
			f << "combo_kills=" << Join(gP.mComboKills) << '\n';
			f << "boss_kills=" << Join(gP.mBossKills) << '\n';
			f << "boss_seen=" << Join(gP.mBossSeen) << '\n';
			f << "plant_xp=" << Join(gP.mPlantXP) << '\n';
			f << "weather_seen=" << Join(gP.mWeatherSeen) << '\n';
			f << "events_seen=" << Join(gP.mEventsSeen) << '\n';
			f << "max_endless=" << gP.mMaxEndlessCycle << '\n';
			f << "max_wave=" << gP.mMaxWave << '\n';
			f << "pf_used=" << gP.mPlantFoodUsed << '\n';
			f << "evolved=" << gP.mEvolvedPlants << '\n';
			f << "levels_won=" << gP.mLevelsWon << '\n';
			f << "levels_lost=" << gP.mLevelsLost << '\n';
			f << "lightning=" << gP.mLightningStrikes << '\n';
			f << "max_hit=" << gP.mMaxDamageHit << '\n';
			for (const WaveRecord& r : gP.mHardestWaves)
				f << "wave=" << r.mScore << ',' << r.mWave << ',' << r.mLevel << ',' << r.mMode << ',' << r.mZombies << ',' << r.mSpecials << '\n';
		}
		std::error_code ec;
		std::filesystem::rename(PathFromU8(aTmp), PathFromU8(aPath), ec);
		if (ec)
		{
			std::filesystem::remove(PathFromU8(aPath), ec);
			std::filesystem::rename(PathFromU8(aTmp), PathFromU8(aPath), ec);
		}
		sDirty = false;
	}

	void ProgressSaveIfDirty() { if (sDirty) ProgressSave(); }

	void RecordKill(Zombie* z)
	{
		const ZombieModState& m = z->mMod;
		gP.mTotalKills++;
		if (m.mVariant >= 0 && m.mVariant < 128) gP.mVariantKills[m.mVariant]++;
		if (m.mClass >= 0) gP.mClassKills[m.mClass]++;
		for (int i = 0; i < NUM_MOD_MUTATIONS; i++) if (m.mMutations & (1 << i)) gP.mMutationKills[i]++;
		if (m.mCombo >= 0) gP.mComboKills[m.mCombo]++;
		sDirty = true;
	}

	void RecordWave(Board* b, int theWave)
	{
		int hp = 0, n = 0, specials = 0;
		for (Zombie* z : b->mZombies)
		{
			if (z->mDead || z->mFromWave != theWave) continue;
			n++;
			hp += z->mBodyHealth + z->mHelmHealth + z->mShieldHealth + z->mFlyingHealth;
			if (IsSpecial(z)) specials++;
		}
		gP.mMaxWave = std::max(gP.mMaxWave, b->mTotalSpawnedWaves);
		if (n == 0) return;
		WaveRecord r{ hp / 10 + specials * 50, theWave + 1, gApp->IsAdventureMode() ? b->mLevel : 1000 + static_cast<int>(gApp->mGameMode), Mode(), n, specials };
		gP.mHardestWaves.push_back(r);
		std::sort(gP.mHardestWaves.begin(), gP.mHardestWaves.end(), [](const WaveRecord& a, const WaveRecord& c) { return a.mScore > c.mScore; });
		if (gP.mHardestWaves.size() > 10) gP.mHardestWaves.resize(10);
		sDirty = true;
	}

	bool VariantUnlocked(int v)
	{
		if (v < 0 || v >= NUM_MOD_VARIANTS) return false;
		if (On(OPT_D_UNLOCK_VARIANTS)) return true;
		int tier = gModVariants[v].mTier;
		return tier == 0 || (tier == 1 && gP.mTotalKills >= 50) || (tier >= 2 && gP.mTotalKills >= 200);
	}

	bool VariantDiscovered(int v)
	{
		return v >= 0 && v < 128 && (gP.mVariantKills[v] > 0 || gP.mVariantSeen[v] > 0);
	}
}
