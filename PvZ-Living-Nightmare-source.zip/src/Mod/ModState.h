// PvZ Living Nightmare - per-object runtime state embedded into Zombie / Plant / Projectile.
// Kept as plain data so DataArray reset (construct_at) re-initializes everything.
#ifndef __MOD_STATE_H__
#define __MOD_STATE_H__

#include <cstdint>

constexpr int MOD_MAX_PIERCE_MEMORY = 4;

struct ZombieModState
{
	int16_t  mVariant = -1;        // index into gModVariants, -1 = vanilla
	int8_t   mClass = -1;          // ModZombieClass, -1 = none
	int8_t   mBoss = -1;           // ModBossType, -1 = not a mod boss
	uint16_t mMutations = 0;       // bitmask of ModMutation
	int8_t   mCombo = -1;          // ModMutationCombo, -1 = none
	int8_t   mBossPhase = 0;
	bool     mInitialized = false;
	bool     mElite = false;       // glowing zombie: drops Plant Food
	bool     mDeathHandled = false;
	bool     mInvisible = false;
	bool     mUnderground = false;
	bool     mHasJumped = false;
	bool     mStatsCounted = false;
	bool     mMini = false;        // spawned by split/summon (no further splitting)
	uint32_t mAbilities = 0;       // ModAbility bits (variant + class + mutations)
	uint32_t mTempAbilities = 0;   // abilities copied by Mimic
	int32_t  mPhase = 0;           // random phase offset for periodic abilities
	int32_t  mShieldHP = 0;
	int32_t  mShieldMax = 0;
	int32_t  mShieldRecharge = 0;
	int32_t  mJumpCounter = 0;
	float    mJumpFromX = 0.0f;
	int32_t  mSummonCount = 0;
	int32_t  mRageStacks = 0;
	int32_t  mStolenSun = 0;
	int32_t  mDamageAccum = 0;     // pending damage-number value
	int32_t  mDamageAccumTimer = 0;
	int32_t  mPoison = 0;          // poison ticks applied by plants
	float    mAuraSpeed = 1.0f;    // recomputed by auras
	float    mAuraDefense = 1.0f;
	float    mAuraHeal = 0.0f;
	float    mLastSpeedFactor = 1.0f;
	float    mBaseScale = 1.0f;
	float    mGrowth = 1.0f;
	int32_t  mBossTimerA = 0;
	int32_t  mBossTimerB = 0;
	int32_t  mBossTimerC = 0;
	int32_t  mStatusFlash = 0;
	int32_t  mLaneHopTarget = -1;
};

struct PlantModState
{
	bool     mInitialized = false;
	int8_t   mLevel = 0;           // 0..4  (display 1..5)
	int8_t   mTrait = -1;          // ModPlantTrait
	uint8_t  mCombos = 0;          // active combo bits
	int32_t  mXP = 0;
	int32_t  mPoison = 0;          // ticks of poison left
	int32_t  mFrozen = 0;          // ticks disabled by ice
	int32_t  mDisabled = 0;        // ticks disabled by sabotage / EMP
	int32_t  mSlowed = 0;          // ticks of 50% fire-rate slow
	int32_t  mShield = 0;          // ticks of invulnerability
	int32_t  mRapidFire = 0;       // ticks of rapid fire
	int32_t  mBoost = 0;           // ticks of Plant Food boost
	int32_t  mShotCount = 0;
	int32_t  mHealAccum = 0;
	float    mFireAccum = 0.0f;
	float    mProduceAccum = 0.0f;
	float    mComboFire = 1.0f;
	float    mComboDamage = 1.0f;
	int32_t  mLevelUpFlash = 0;
};

struct ProjectileModState
{
	bool     mInitialized = false;
	bool     mCrit = false;
	bool     mFreeze = false;      // freezes zombie solid on hit
	bool     mExplosive = false;   // explosive butter / heavy cabbage
	bool     mStun = false;
	bool     mHypno = false;
	bool     mChill = false;
	bool     mBackward = false;
	bool     mPoison = false;
	int8_t   mPierce = 0;          // number of extra zombies it can pass through
	uint32_t mSourcePlant = 0;     // PlantID of the shooter
	float    mDamageMult = 1.0f;
	uint32_t mHitZombies[MOD_MAX_PIERCE_MEMORY] = {0, 0, 0, 0};
};

#endif
