# PvZ Living Nightmare

An extended, highly customisable build of PvZ Portable 0.2.7. All original content and mechanics are kept; every
new system can be switched off from the in-game **Mod Menu**, which returns the game to vanilla behaviour.

> You still need your own `main.pak` and `properties/` folder from a legally purchased copy of
> Plants vs. Zombies GOTY. This repository contains no game assets.

## Quick facts

| | |
|---|---|
| Android package | `io.github.pvzlivingnightmare.game` (installs next to the original `io.github.wszqkzqk.pvzportable`) |
| App name | PvZ Living Nightmare |
| Desktop data folder | `<OS app data>/io.github.pvzlivingnightmare/PvZLivingNightmare/` (separate from upstream PvZ Portable) |
| Android data folder | `Android/data/io.github.pvzlivingnightmare.game/files/` |
| Mod settings file | `living_nightmare.cfg` in the data folder (saved automatically) |
| Mod progress file | `living_nightmare_progress.cfg` (kills, plant XP, records, unlocks) |

## Opening the Mod Menu

* **Main menu:** the **MOD** button in the bottom-left corner.
* **In a level:** the **MOD** button in the top-right corner (position selectable in *Miscellaneous*), or **F2** on a keyboard.
* The level is paused while the menu is open (can be turned off with *Pause game while menu is open*).

The menu has expandable categories with toggles, sliders, selection lists, number fields with an on-screen keypad,
action buttons, a **Reset all settings** button, and three extra pages: **Zombie Encyclopedia**, **Plant Encyclopedia**
and **Statistics & Records**. Every change is saved automatically (on menu close, periodically, and on exit).

## What is included

| Area | Content |
|---|---|
| Mod Menu | 17 categories, 287 settings. The menu header counts 218 functions: every toggle, slider, list, number field and button, with each game mode counted separately. Weight, power and upgrade-branch fields are not counted. |
| Zombie variants | 69 new variants; every original zombie type has at least 2 |
| Mutations | 10 mutations (some rare), stackable, with 6 special combinations |
| Zombie classes | 10 classes with distinct behaviour and class synergies |
| Bosses | 7 new multi-phase bosses with health bars |
| Plants | 40 plants with a new ability and 2 upgrade branches each, plant levels/evolution, 7 random traits, 7 placement combinations, Plant Food |
| Weather | 8 weather types with real gameplay effects, smooth transitions, intensity setting, 4 rare events |
| Game modes | 12 extra modes layered on top of any Adventure or Survival level |
| Progression | Encyclopedias with weak points, unlockable variants and plant upgrades, statistics, records, hardest-wave history |
| Effects | Damage numbers, health bars, status icons, ability tags, tints, screen flashes, lightning bolts; each can be toggled |

## Living Nightmare level rules (on by default)

* **Every zombie on every level.** All zombie types, Zombotany zombies included (Peashooter, Wall-nut, Jalapeno,
  Gatling, Squash and Tall-nut heads), Gargantuars, Red-eye Gargantuars, Imps and the Zombie Yeti can appear in every
  level that has normal waves: Adventure, Survival and mini-games. The Dr. Zomboss fight is excluded. Expensive zombies
  still need enough wave points, so they show up later in a level; short levels open them earlier. The terrain limits are:
  * Snorkel and Dolphin Rider zombies only appear on lawns with water.
  * Diggers, Zombonis and the Bobsled team don't appear on the roof.
  * A Bobsled team with no ice becomes 4 normal zombies (the original game does the same).
  * Balloon zombies only appear once you own Cactus, Blover or Cattail, and never on conveyor-belt levels, because
    without them they can't be stopped.
* **Graves on every level.** Gravestones push out of the lawn as the level progresses: sometimes after a normal wave
  (more often later in the level) and 2 on every flag wave. Up to 8 per level (*Max graves from progress*, 1-20). They
  never appear on a plant or in the water. On flag waves and on the final wave, zombies climb out of them
  (normal, conehead, buckethead or Zombotany zombies). Use Grave Buster to get rid of them.
* **In-game menu button** reads **LN** (Living Nightmare). It opens the usual pause menu.
* All of this can be switched off in *Level modification*: *All zombies on all levels*, *Graves grow during levels*,
  *Max graves from progress*, *Zombies rise from graves*.

## How the systems behave

* **Variants** replace a spawning zombie of the same base type (chance set by *Difficulty → Variant chance*). Tier-1
  and tier-2 variants unlock after 50 / 200 total zombie kills unless *Unlock all variants* is on.
* **Mutations** roll on any zombie (chance + per-mutation weight). Extra mutations are progressively rarer. Two
  matching mutations create a special combination with an extra power and a golden tag.
* **Classes** add a role on top of variants and mutations. Synergies: Support boosts Assassins, Healer doubles
  healing on Tanks, Saboteur in the same lane makes Destroyers tougher, Scouts speed up their whole lane.
* **Plant upgrades:** every plant earns XP while fighting. Branches unlock with global plant XP (or *Unlock all
  upgrades*). Individual plants also level up during a level (5 levels; level 5 = evolved form).
* **Plant Food:** earned from glowing zombies; tap the Plant Food button, then a plant.
* **Weather** is random or fixed (*Weather & Environment*). Blover clears weather for a while.
* **Game modes** are chosen in *Game Modes* and apply to the next level you start from Adventure or Survival.
* **Custom waves:** pick up to 4 zombie groups, counts, variant/class/mutation rules, then use them as a mode, on flag
  waves, or spawn them instantly.

## Limitations (honest list)

* **No new art or sound files.** Variants, mutations and bosses reuse the original zombie bodies and sounds. Their
  identity comes from colour tints, size, name/ability tags, particles and health bars.
* Bosses are built on existing bodies (Gargantuar, Zamboni, Yeti, basic zombie). Their phases, attacks and stats are new.
* The environment changer only works on regular Adventure/Survival levels, and pool levels keep a pool (they contain
  swimming zombies). Mini-games, puzzles and special levels keep their own stage.
* Variants, mutations and classes are not applied in I, Zombie, Vasebreaker, Whack a Zombie, Zombiquarium, Zen Garden
  or the Dr. Zomboss fight, because those modes depend on exact zombie behaviour.
* The mod could not be play-tested in the build environment because the game data files are not available there. It
  was compiled and linked with GCC 15 and Clang 21; the Android APK is produced by the GitHub workflow.

## Building

### APK with GitHub Actions (recommended)

1. Push this folder to a new GitHub repository (branch `main` or `master`).
2. Open **Actions → CI build**. It starts automatically on push; you can also press **Run workflow**.
3. When the **Build for Android** job finishes, download the **pvz-portable-android** artifact. It contains
   `pvz-living-nightmare-android-arm64-v8a.apk`.
4. Optional signing: add the secrets `PVZP_KEYSTORE_BASE64`, `PVZP_KEYSTORE_PASSWORD`, `PVZP_KEY_ALIAS`,
   `PVZP_KEY_PASSWORD`. Without them the APK is signed with a temporary debug key, so installing a newer build may
   require uninstalling the previous one first (your game data is kept only if you export it).

The other jobs in the workflow (Windows, macOS, iOS, Web, Linux) are independent of the Android job.

### Local Linux build

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

Dependencies are the same as upstream PvZ Portable (SDL2, libpng, libjpeg-turbo, zlib, libopenmpt, OpenGL/GLES).

### Mod self-check (no game data needed)

```sh
sh tests/mod/run.sh
```

Checks the option registry (≥100 functions, unique keys, valid ranges), settings save/reload/reset, the variant
count and per-zombie coverage, and the plant ability table.

## Source layout

| File | Purpose |
|---|---|
| `src/Mod/ModConfig.*` | Option registry, categories, auto-save/load, reset |
| `src/Mod/ModData.*` | Content tables: variants, classes, mutations, combos, bosses, weather, modes, plant abilities |
| `src/Mod/ModZombies.cpp` | Variant/class/mutation rolling, zombie abilities, damage, death effects, zombie overlays |
| `src/Mod/ModBosses.cpp` | Boss phases and attacks |
| `src/Mod/ModPlants.cpp` | Plant abilities, upgrade branches, levels, traits, combos, projectiles, Plant Food |
| `src/Mod/ModWorld.cpp` | Weather, events, game modes, waves, economy, actions, HUD |
| `src/Mod/ModProgress.cpp` | Persistent statistics, unlocks, plant XP, records |
| `src/Mod/ModMenu.cpp` | In-game Mod Menu and encyclopedias |
| `src/Mod/ModState.h` | Per-zombie / plant / projectile mod state (saved inside save games) |

The original engine files only gained small hook calls (`ModSystem::...`) at the relevant points, so vanilla logic is
unchanged when the mod features are off. Old save games still load; the mod state is stored in a new optional field.

## Mod Menu functions

#### Zombie Control

| Function | Control | What it does |
|---|---|---|
| Freeze all zombies | toggle | Zombies stop moving, eating and animating. |
| Zombie health x | slider | Health multiplier for newly spawned zombies. |
| Zombie speed x | slider | Movement speed multiplier (applies instantly). |
| Zombie bite damage x | slider | Damage zombies deal to plants. |
| Zombie size x | slider | Visual size of newly spawned zombies. |
| Invulnerable zombies | toggle | Zombies take no damage. |
| One-hit kill | toggle | Any hit destroys a zombie. |
| Zombies cannot eat | toggle | Zombies stop at plants but deal no damage. |
| Zombies immune to slow | toggle | Snow peas and ice no longer slow zombies. |
| Extra loot | toggle | Every defeated zombie drops a coin. |
| Hypno rounds chance % | slider | Chance a projectile hit hypnotizes the zombie. |
| Max zombies on lawn (0=off) | number | Extra spawns are skipped above this number. |
| All zombies regenerate | toggle | Every zombie slowly regenerates health. |
| Spawn: zombie type | list | Zombie type used by 'Spawn zombies now'. |
| Spawn: amount | number | How many zombies to spawn. |
| Spawn: lane | list | Lane for spawned zombies. |
| Spawn zombies now | button | Spawns the selected zombie type. |
| Spawn: variant | list | Variant used by 'Spawn variant now'. |
| Spawn variant now | button | Spawns the selected zombie variant. |
| Kill all zombies | button | Instantly defeats every zombie on the lawn. |
| Hypnotize all zombies | button | Every zombie joins your side. |
| Push zombies back | button | Knocks every zombie back two tiles. |
| Strip all armor | button | Removes helmets and shields. |
| Butter all zombies | button | Immobilizes every zombie for 4 seconds. |
| Chill all zombies | button | Slows every zombie. |

#### Plant Control

| Function | Control | What it does |
|---|---|---|
| Invulnerable plants | toggle | Plants cannot be eaten, crushed or damaged. |
| Plant damage x | slider | Damage of plant projectiles. |
| Plant fire rate x | slider | How often shooters fire. |
| Plant health x | slider | Health of newly planted plants. |
| Plant size x | slider | Visual size of plants. |
| Instant recharge | toggle | Seed packets recharge immediately. |
| Recharge time x | slider | Seed packet recharge time multiplier. |
| Plant cost x | slider | Sun cost multiplier. |
| Projectile speed x | slider | Speed of straight-flying projectiles. |
| All shots pierce | toggle | Straight projectiles pass through 3 zombies. |
| Critical hit chance % | slider | Critical hits deal double damage. |
| Mushrooms never sleep | toggle | Mushrooms work during the day. |
| Heal all plants | button | Restores every plant to full health. |
| Plants regenerate | toggle | Plants slowly recover health. |
| Unlock all plants | toggle | Every plant is available in the seed chooser. |
| 10 seed slots | toggle | Always use the maximum number of seed slots. |

#### Plant Abilities & Upgrades

| Function | Control | What it does |
|---|---|---|
| New plant abilities | toggle | Master switch for all new plant abilities. |
| Plant experience & levels | toggle | Plants level up (1-5) by dealing damage. |
| Experience gain x | slider | Speed of plant level-ups. |
| Random plant traits | toggle | 20% of plants get a random rare trait. |
| Plant combinations | toggle | Bonuses for specific plant arrangements. |
| Unlock all upgrade branches | toggle | Branches normally unlock with plant experience. |
| Evolve all plants now | button | Every plant on the lawn reaches level 5 (evolved form). |

#### Game Modifiers

| Function | Control | What it does |
|---|---|---|
| Game speed x | slider | Speeds up or slows down the whole game. |
| Slow motion | toggle | Halves the game speed. |
| Pause zombie waves | toggle | No new waves arrive. |
| Next wave now | button | The next wave arrives immediately. |
| Win level now | button | Ends the level with a victory. |
| Zombies cannot win | toggle | Zombies reaching the house are destroyed. |
| Infinite lawn mowers | toggle | Used lawn mowers come back. |
| No lawn mowers | toggle | Removes lawn mowers at level start. |
| Restore lawn mowers | button | Puts back every missing lawn mower. |
| Auto-collect sun & coins | toggle | Sun and coins are collected automatically. |
| No falling sun | toggle | Sun no longer falls from the sky. |
| Falling sun rate x | slider | How often sun falls from the sky. |
| Plant Food system | toggle | Glowing zombies drop Plant Food; tap PF then a plant. |
| Infinite Plant Food | toggle | Plant Food never runs out. |
| Glowing zombie chance % | slider | Chance a zombie glows and drops Plant Food. |
| Add 3 Plant Food | button | Adds three Plant Food charges. |

#### Economy & Resources

| Function | Control | What it does |
|---|---|---|
| Infinite sun | toggle | Planting costs nothing; sun stays at 9990. |
| Collected sun x | slider | Multiplies the value of collected sun. |
| Add 1000 sun | button | Adds 1000 sun. |
| Sun amount to set | number | Used by 'Set sun'. |
| Set sun | button | Sets your sun to the amount above. |
| Coin value x | slider | Multiplies silver, gold and diamond value. |
| Add $10,000 | button | Adds money for Crazy Dave's shop. |
| Diamond drop chance % | slider | Chance a defeated zombie drops a diamond. |
| Sun plant speed x | slider | How fast sunflowers produce sun. |
| Starting sun (0=default) | number | Sun at the start of every level. |
| Shovel refund 50% | toggle | Digging up a plant returns half its cost. |
| Sun for kills | toggle | Every defeated zombie gives 10 sun. |

#### Level Modification

| Function | Control | What it does |
|---|---|---|
| Number of waves (0=default) | number | Overrides the number of waves in a level. |
| Wave size x | slider | Multiplies how many zombies each wave has. |
| Time between waves x | slider | Lower = faster waves. |
| Random zombie types | toggle | Each level picks a random set of zombie types. |
| Environment | list | Forces the lawn type at level start. |
| Add 5 graves | button | Places gravestones on the lawn. |
| Remove all graves | button | Removes every gravestone and crater. |
| Unlock all mini-games & puzzles | toggle | Unlocks every mini-game, puzzle and survival level. |
| Adventure level (1-50) | number | Used by 'Jump to adventure level'. |
| Jump to adventure level | button | Sets your adventure progress to the level above. |
| All zombies on all levels | toggle | All zombie types, Zombotany included, can appear in any level except Dr. Zomboss. |
| Graves grow during levels | toggle | New gravestones push out of the lawn during every level (not Dr. Zomboss). |
| Max graves from progress | number | Limit for the gravestones created by level progress. |
| Zombies rise from graves | toggle | On flag waves and the final wave zombies climb out of the gravestones. |

#### Game Modes

| Function | Control | What it does |
|---|---|---|
| Game mode | list | Applied when the next level starts. |
| Single Lane: lane | list | Lane used by the Single Lane mode. |
| Endless: health growth %/cycle | slider | How much tougher zombies get each endless cycle. |

#### Custom Waves

| Function | Control | What it does |
|---|---|---|
| Variants | list | Whether custom wave zombies get variants. |
| Class | list | Class selection for custom waves. |
| Mutation | list | Mutation for custom waves. |
| Spawn custom wave now | button | Spawns the configured groups. |
| Add custom wave to flag waves | toggle | Every flag wave also spawns the custom groups. |

#### Visual Settings

| Function | Control | What it does |
|---|---|---|
| Health bars | toggle | Health bars for special zombies (or all, when damaged). |
| Damage numbers | toggle | Floating damage numbers. |
| Boss health bar | toggle | Large boss health bar at the top. |
| Class & mutation tags | toggle | Shows tags above special zombies. |
| Weather visuals | toggle | Rain, snow, fog and lightning drawing. |
| Screen shake | toggle | Shakes the screen on big explosions. |
| Ability effects | toggle | Particles for zombie and plant abilities. |
| Screen flashes | toggle | Flashes for lightning and bosses. |
| Mod info panel | toggle | Shows mode, weather and Plant Food. |
| Variant colors | toggle | Colors special zombies. |
| Plant level stars | toggle | Shows plant levels. |
| Status indicators | toggle | Shows poisoned, frozen, boosted states. |
| Low effects mode | toggle | Fewer particles for slower phones. |

#### Difficulty

| Function | Control | What it does |
|---|---|---|
| Difficulty preset | list | Sets several difficulty values at once. |
| Zombie variants | toggle | Allows the 69 new zombie variants to appear. |
| Variant chance % | slider | Chance a zombie becomes a variant. |
| Unlock all variants | toggle | Variants normally unlock with total kills. |
| Adaptive difficulty | toggle | The better you play, the more specials appear. |

#### Mutations

| Function | Control | What it does |
|---|---|---|
| Mutations | toggle | Zombies can mutate randomly. |
| Mutation chance % | slider | Chance each zombie mutates. |
| Max mutations per zombie | number | Zombies can stack several mutations. |
| Special mutation combos | toggle | Compatible pairs become special mutations. |

#### Zombie Classes

| Function | Control | What it does |
|---|---|---|
| Zombie classes | toggle | Zombies can spawn with a class role. |
| Class chance % | slider | Chance a zombie gets a class. |
| Class cooperation | toggle | Classes boost each other (Tank+Healer, Support+Assassin...). |

#### Weather & Environment

| Function | Control | What it does |
|---|---|---|
| Dynamic weather | toggle | Weather changes during levels. |
| Weather mode | list | Random weather or the type chosen below. |
| Fixed weather | list | Weather used in Fixed mode. |
| Weather intensity x | slider | Strength of weather effects. |
| Weather change (seconds) | number | Seconds between weather changes. |
| Rare weather events | toggle | Blood Moon, Meteor Shower, Aurora, Eclipse. |
| Change weather now | button | Rolls a new weather immediately. |
| Trigger rare event | button | Starts a random rare event. |

#### Bosses

| Function | Control | What it does |
|---|---|---|
| Boss | list | Boss used by 'Spawn boss now'. |
| Spawn boss now | button | Spawns the selected boss. |
| Boss health x | slider | Health multiplier for bosses. |
| Boss in final wave % | slider | Chance a random boss joins the final wave. |

#### Special Abilities

| Function | Control | What it does |
|---|---|---|
| Lightning strike | button | Lightning hits 5 zombies for 600 damage. |
| Meteor shower | button | 8 meteors crash into the zombies. |
| Freeze wave | button | Freezes every zombie solid. |
| Sun rain | button | Ten suns fall from the sky. |
| Plant shield | button | All plants are invulnerable for 10 seconds. |
| Earthquake | button | Every zombie takes 300 damage. |
| Mower charge | button | Starts every lawn mower. |
| Plant Food on all plants | button | Boosts every plant at once. |
| Coin shower | button | Coins rain down. |
| Blizzard | button | Snow storm: zombies chilled, snow weather. |
| Firestorm | button | Burns the lane with the most zombies. |
| Gravity well | button | Pulls flying zombies to the ground. |

#### Experimental

| Function | Control | What it does |
|---|---|---|
| Zombies switch lanes | toggle | Zombies randomly change lanes. |
| Shooters fire backwards too | toggle | Every pea also flies backwards. |
| Chain reaction | toggle | Defeated zombies damage zombies around them. |
| Chaos mode | toggle | A random event happens every 20 seconds. |
| Ally zombie chance % | slider | Some zombies arrive already on your side. |
| Ricochet peas | toggle | Peas bounce into a neighbouring lane. |
| Lifesteal plants | toggle | Shooters heal when they hit. |

#### Miscellaneous

| Function | Control | What it does |
|---|---|---|
| Reset all settings | button | Restores every option to its default. |
| Save settings now | button | Settings are also saved automatically. |
| Reset statistics | button | Clears records, kills and unlocks. |
| MOD button position | list | Where the in-game MOD button is drawn. |
| Pause while menu is open | toggle | The game pauses while the mod menu is open. |


## Content reference

### Zombie variants

| # | Base zombie | Variant | Ability | Weak point |
|---|---|---|---|---|
| 1 | Normal | Brute | Thick-skinned zombie that soaks up peas. | Explosions ignore its armor. |
| 2 | Normal | Sprinter | Runs in fast bursts. | Slow it with Snow Pea; low health. |
| 3 | Normal | Bomber | Explodes when defeated. | Kill it far from your plants (Cattail, Starfruit). |
| 4 | Normal | Vampire | Drinks plant sap to heal. | Burst damage: Cherry Bomb, Melon-pult. |
| 5 | Normal | Splitter | Splits into two minis when defeated. | Splash damage handles the minis. |
| 6 | Normal | Ghost | Fades out of sight and cannot be targeted. | Plantern reveals it; Spikeweed still hits. |
| 7 | Normal | Tunneler | Moves underground past your front line. | Back-row defense, Spikeweed, Potato Mine. |
| 8 | Flag | Warlord | Rallies the horde: allies move faster and resist damage. | Focus it first; its aura ends on death. |
| 9 | Flag | Necro Banner | Raises zombies from the ground. | Kill quickly before it raises an army. |
| 10 | Traffic Cone | Toxic Cone | Poisonous bite damages plants over time. | Keep it away with Wall-nuts in front of shooters. |
| 11 | Traffic Cone | Mimic Cone | Copies abilities of special zombies nearby. | Kill the special zombies around it first. |
| 12 | Polevaulter | Electro Vaulter | Shocks plants with chain lightning. | Spread plants out; Tall-nut stops the vault. |
| 13 | Polevaulter | Phantom Vaulter | Invisible sprinting vaulter. | Plantern and Spikeweed. |
| 14 | Pail | Iron Bucket | Armored bucket with an energy shield. | Magnet-shroom pulls the bucket; Fume-shroom. |
| 15 | Pail | Regenerator | Heals constantly and grows. | High burst damage before it regenerates. |
| 16 | Newspaper | Berserker Reader | Gets furious and faster with every hit. | Freeze it with Ice-shroom before it rages. |
| 17 | Newspaper | Frost Reader | Freezes plants, immune to cold. | Fire peas (Torchwood) and Jalapeno. |
| 18 | Door | Constructor | Digs craters where you want to plant. | Kill it before it reaches your back rows. |
| 19 | Door | Bastion | Shields its allies. | Lobbed shots (Cabbage, Melon) ignore its door. |
| 20 | Football | Linebacker | Stomps the ground to damage plants. | Squash and Chomper. |
| 21 | Football | Blitz | Sprints and leaps over the first plant. | Tall-nut blocks the leap. |
| 22 | Dancer | Necro Dancer | Raises extra zombies while dancing. | Kill it quickly with Jalapeno or Squash. |
| 23 | Dancer | Disco Inferno | Fire-proof dancer that explodes. | Ice and Snow Pea; fire does nothing. |
| 24 | Backup Dancer | Healer Backup | Heals the dance crew. | Splash damage hits the whole crew. |
| 25 | Backup Dancer | Shadow Backup | Fades from sight. | Plantern. |
| 26 | Ducky Tube | Toxic Tube | Poisonous swimmer. | Tangle Kelp. |
| 27 | Ducky Tube | Splitter Tube | Splits in two when defeated. | Splash damage. |
| 28 | Snorkel | Electro Diver | Electrocutes plants from the water. | Tangle Kelp drags it under. |
| 29 | Snorkel | Leech Diver | Heals by biting lily pads. | Burst damage. |
| 30 | Zamboni | Glacier Zamboni | Freezes plants in its path. | Spikeweed pops its tires. |
| 31 | Zamboni | Bomb Zamboni | Explodes when destroyed. | Spikeweed/Spikerock far from your lines. |
| 32 | Bobsled | Turbo Sled | Extremely fast sled team. | Spikeweed destroys the sled. |
| 33 | Bobsled | Frost Sled | Freezes plants when defeated. | Kill it far from your plants. |
| 34 | Dolphin Rider | Shark Rider | Gets vicious when hurt. | Tall-nut stops the jump. |
| 35 | Dolphin Rider | Storm Rider | Shocks plants and changes lanes. | Cover every pool lane. |
| 36 | Jack In The Box | Surprise Box | Explodes and leaves minis behind. | Magnet-shroom steals the box. |
| 37 | Jack In The Box | Shock Box | Dodges shots and zaps plants. | Splash damage cannot be dodged. |
| 38 | Balloon | Sky Artillery | Drops basketballs while flying. | Cactus and Blover. |
| 39 | Balloon | Stealth Balloon | Invisible and evasive. | Blover blows it away even when invisible. |
| 40 | Digger | Saboteur Miner | Disables plants around it. | Split Pea and Starfruit shoot backwards. |
| 41 | Digger | Gem Digger | Steals your sun. | Kill it to get the sun back. |
| 42 | Pogo | Hopper | Bounces between lanes. | Tall-nuts in every lane. |
| 43 | Pogo | Spring Bomber | Evasive and explosive. | Magnet-shroom removes the pogo. |
| 44 | Yeti | Frost Giant | Freezes everything around it. | Fire peas. |
| 45 | Yeti | Snow Summoner | Summons minis from the snow. | Kill it quickly; drops 4 diamonds. |
| 46 | Bungee | Armored Bungee | Shielded bungee. | Umbrella Leaf. |
| 47 | Bungee | Bomb Bungee | Explodes when shot down. | Umbrella Leaf blocks it completely. |
| 48 | Ladder | Engineer | Builds obstacles and shields allies. | Magnet-shroom takes the ladder. |
| 49 | Ladder | Climber | Leaps over your first plant. | Tall-nut. |
| 50 | Catapult | Siege Catapult | Heavily armored, fires extra shots. | Umbrella Leaf. |
| 51 | Catapult | Toxic Catapult | Poisons and disables plants. | Kill it quickly with Jalapeno. |
| 52 | Gargantuar | Titan | A growing armored giant. | Doom-shroom; Cob Cannon. |
| 53 | Gargantuar | Shaman | Summons and heals the horde. | Kill it before its summons pile up. |
| 54 | Imp | Speedy Imp | Very fast and evasive. | Spikeweed. |
| 55 | Imp | Explosive Imp | Explodes when it dies. | Kill it before it reaches your plants. |
| 56 | Pea Head | Toxic Pea Zombie | Poisonous head-shooter. | Wall-nuts absorb the peas. |
| 57 | Pea Head | Frost Pea Zombie | Freezes plants it reaches. | Fire peas. |
| 58 | Wallnut Head | Iron Nut Zombie | Very hard to crack. | Chomper eats it in one bite. |
| 59 | Wallnut Head | Thorn Nut Zombie | Protects zombies near it. | Focus fire. |
| 60 | Jalapeno Head | Inferno Zombie | Explodes in flames. | Kill it far away. |
| 61 | Jalapeno Head | Chain Pepper | Splits when defeated. | Splash damage. |
| 62 | Gatling Head | Electro Gatling | Shoots and shocks. | Spread out your plants. |
| 63 | Gatling Head | Siege Gatling | Adds lobbed shots. | Umbrella Leaf. |
| 64 | Squash Head | Quake Squash | Stomps plants. | Kill it at range. |
| 65 | Squash Head | Ghost Squash | Invisible squasher. | Plantern. |
| 66 | Tallnut Head | Fortress Zombie | A walking fortress. | Chomper; Squash. |
| 67 | Tallnut Head | Grower Zombie | Grows and heals. | Burst damage. |
| 68 | Redeye Gargantuar | Doom Gargantuar | Rages at low health and explodes. | Kill it far from your plants. |
| 69 | Redeye Gargantuar | Warlord Gargantuar | Commands the horde. | Doom-shroom. |

### Zombie classes

| Class | Role |
|---|---|
| Tank | Lots of health and damage resistance. |
| Assassin | Fast and deadly bites. |
| Support | Speeds up and buffs nearby zombies. |
| Healer | Regenerates allies nearby. |
| Summoner | Calls in extra zombies. |
| Destroyer | Huge damage to plants and walls. |
| Saboteur | Temporarily disables plants. |
| Scout | Fast; finds and buffs the weakest lane. |
| Controller | Slows and roots plants. |
| Artillery | Attacks plants from range. |

### Mutations

| Mutation | Effect |
|---|---|
| Fast | +45% speed. |
| Armored | Extra armor. |
| Regenerative | Regenerates health. |
| Explosive | Explodes on death. |
| Toxic | Toxic trail and bites. |
| Electric | Electrocutes plants. |
| Giant | Rare: huge size and health. |
| Multiplier | Rare: divides when defeated. |
| Frozen | Immune to ice attacks. |
| Berserker | Stronger as it takes damage. |

### Special mutation combinations

| Combination | Effect |
|---|---|
| Frenzy | Fast + Berserker: relentless charging rage. |
| Colossus | Giant + Armored: a living siege engine. |
| Plague Bomb | Explosive + Toxic: poisons every plant in the blast. |
| Dynamo | Electric + Regenerative: lightning heals it. |
| Glacier | Frozen + Giant: freezing aura. |
| Cluster Bomb | Multiplier + Explosive: splits into exploding minis. |

### Bosses

| Boss | Description | Phases |
|---|---|---|
| Armored Giant | Covered in steel plates. Phase 1 armor blocks 80% damage. | 1: Steel shell  2: Plates fall, ground slams  3: Rage + imp barrage |
| Mechanic | A souped-up machine that spits basketballs and imps. | 1: Basketball volleys  2: Deploys imps  3: Overdrive charge |
| Necromancer | Raises the dead and drains your plants. | 1: Raises zombies  2: Graveyard  3: Life drain |
| Mutant | Unstable mutant that changes mutation each phase. | 1-3: Gains new random mutations, splits at death |
| Fire Lord | Burns rows of plants. Immune to fire. | 1: Flame row  2: Fire rain  3: Inferno aura |
| Ice Queen | Freezes plants solid. Immune to cold. | 1: Frost bolt  2: Blizzard (all plants slowed)  3: Absolute zero |
| Storm Titan | Calls lightning and EMP blasts. | 1: Chain lightning  2: EMP column  3: Thunderstorm |

### Weather

| Weather | Effect |
|---|---|
| Clear | No weather effects. |
| Rain | Zombies -10% speed, sun production -20%, fire weaker. |
| Storm | Rain plus lightning strikes that hit random tiles. |
| Fog | Low visibility: zombies far right take 20% less damage. |
| Snow | Zombies -20% speed (not ice-immune), plants fire 10% slower. |
| Darkness | No sky sun, sun production -30%, mushrooms +20% damage. |
| Wind | Lobbed shots drift, balloons fly faster, fog is blown away. |
| Heatwave | Sun +25%, ice effects halved, ice-immune zombies take +50% damage. |

### Rare weather events

| Event | Effect |
|---|---|
| Blood Moon | Rare: zombies +30% speed, every zombie mutated. |
| Meteor Shower | Rare: meteors hit zombies (and sometimes plants). |
| Aurora | Rare: double sun, plants regenerate. |
| Eclipse | Rare: total darkness, invisible zombies everywhere. |

### Game modes

| Mode | Description |
|---|---|
| Off | Play the level normally. |
| Endless Survival | The level never ends; zombies get tougher every cycle. |
| Zombie Rush | Waves arrive three times faster. |
| Boss Rush | Every flag wave brings a boss. |
| Random Waves | Every zombie becomes a random type and variant. |
| Hardcore | +50% zombie health, faster zombies, no lawn mowers, pricier plants. |
| No-Sun Challenge | No sky sun and sun plants are useless. Start with 1500 sun. |
| Single Lane | Zombies and plants use only one lane. |
| Zombie Invasion | Triple-sized waves full of variants. |
| Random Plants | Your seed packets are replaced with random plants. |
| Random Zombies | The level uses random zombie types. |
| Custom Waves | Waves use the zombies you configured in Custom Waves. |
| Sandbox | Infinite sun, no cooldowns, zombies cannot win. Tap to spawn. |

### Plant traits (random, rare)

| Trait | Effect |
|---|---|
| Swift | +30% fire rate |
| Mighty | +35% damage |
| Sturdy | +75% health |
| Lucky | +20% critical chance |
| Frosty | Shots chill zombies |
| Vampiric | Heals when dealing damage |
| Thorny | Reflects 30% of bite damage |

### Plant abilities and upgrade branches

| Plant | Base ability | Branch 1 | Branch 2 | Plant XP to unlock branches |
|---|---|---|---|---|
| Peashooter | 12% chance to fire a piercing pea | Sniper: 30% pierce, +20% damage | Rapid: +30% fire rate | 300 |
| Sunflower | 10% chance to make an extra sun | Solar: 25% extra sun | Nurse: heals adjacent plants | 300 |
| Cherry Bomb | Bigger blast radius | Mega: even bigger blast | Napalm: burns the row behind | 150 |
| Wall-nut | Reflects 25% of bite damage | Thorns: reflects 60% | Regrowth: regenerates health | 300 |
| Potato Mine | Arms 35% faster | Big Bang: larger explosion | Instant: arms almost instantly | 150 |
| Snow Pea | 8% chance to freeze a zombie solid | Glacier: 18% freeze chance | Frostbite: +40% damage | 300 |
| Chomper | Swallows small zombies; digests 40% faster | Glutton: digests 70% faster | Shredder: chews big zombies (400 dmg) | 300 |
| Repeater | Every 12th volley triggers rapid fire | Overdrive: longer rapid fire | Heavy peas: +25% damage | 300 |
| Puff-shroom | +50% damage at night | Toxic spores: poisons zombies | Long puff: +40% damage | 200 |
| Sun-shroom | Grows up twice as fast | Moon sun: +25% sun | Spore heal: heals neighbours | 200 |
| Fume-shroom | +50% damage against shields | Corrosion: poisons | Pressure: +25% damage | 300 |
| Grave Buster | Gives 50 sun after eating a grave | Fast eater | Treasure: drops coins | 100 |
| Hypno-shroom | Hypnotized zombie gets +100% health | Champion: +200% health | Berserk: hypnotized zombie is much faster | 150 |
| Scaredy-shroom | +60% damage | Brave: +30% fire rate | Sniper: piercing spores | 200 |
| Ice-shroom | Freezes 50% longer and deals 40 damage | Permafrost: freezes twice as long | Shatter: frozen zombies take +25% | 150 |
| Doom-shroom | Crater disappears much sooner | Annihilation: bigger blast | Clean: no crater | 150 |
| Squash | Shockwave damages zombies in neighbouring tiles | Quake: bigger shockwave | Double: hits twice | 150 |
| Threepeater | 10% chance of piercing peas | Spread: +20% damage | Gatling: +25% fire rate | 300 |
| Jalapeno | Also scorches the neighbouring rows (200 dmg) | Inferno: full burn on 3 rows | Ember: leaves burning ground | 150 |
| Spikeweed | Spikes poison zombies | Razor: +50% damage | Caltrops: slows zombies | 200 |
| Torchwood | Fire peas deal +25% damage | Blaze: +50% fire damage | Warmth: protects plants from ice | 300 |
| Tall-nut | Reflects 15% of bite damage | Spiked: reflects 40% | Regrowth: regenerates | 300 |
| Plantern | Reveals invisible zombies nearby | Beacon: reveals the whole lawn | Sunlight: produces small sun | 150 |
| Cactus | Spikes pierce up to 3 zombies | Needles: pierce 5 | Barbs: +30% damage | 300 |
| Blover | Also clears weather for 30 seconds | Hurricane: pushes zombies back | Breeze: chills zombies | 150 |
| Split Pea | Backward peas deal double damage | Guard: +30% fire rate | Heavy: +25% damage | 300 |
| Starfruit | 15% chance of piercing stars | Nova: +25% damage | Comet: 35% pierce | 300 |
| Pumpkin | Reflects 20% of bite damage | Iron shell: +100% health | Spiked shell: reflects 50% | 200 |
| Magnet-shroom | Recharges 50% faster | Super magnet: recharges 80% faster | Shrapnel: damages the zombie | 200 |
| Cabbage-pult | 15% chance of a heavy cabbage that stuns | Heavy: 30% stun chance | Splash: hits nearby zombies | 300 |
| Kernel-pult | Butter chance x2; 5% explosive butter | Butter bomb: 12% explosive | Popcorn: +30% damage | 300 |
| Garlic | Lasts 50% longer | Stink: poisons biters | Fortress: +100% health | 150 |
| Melon-pult | +25% splash damage | Watermelon storm: +40% damage | Heavy: stuns on hit | 300 |
| Gatling Pea | Every 10th volley triggers rapid fire | Minigun: longer rapid fire | Piercing: 15% pierce | 300 |
| Twin Sunflower | 15% chance of an extra sun | Solar farm: 30% | Nurse: heals adjacent plants | 300 |
| Gloom-shroom | +30% damage | Miasma: poisons | Pressure: +30% more damage | 300 |
| Cattail | 15% chance of piercing spikes | Hunter: +25% damage | Quick: +25% fire rate | 300 |
| Winter Melon | 10% chance to freeze zombies solid | Absolute: 20% freeze | Avalanche: +25% damage | 300 |
| Spikerock | Reflects bites and poisons zombies | Obsidian: +100% health | Razor: +50% damage | 200 |
| Cob Cannon | Reloads 30% faster | Rapid: reloads 50% faster | Mega cob: bigger blast | 150 |

### Plant combinations

| Combination | Effect |
|---|---|
| Flame Line | Peashooters behind a Torchwood fire 15% faster. |
| Solar Grid | Sunflowers next to 2+ sun plants make 10% more sun. |
| Bulwark | Nuts in front of a shooter regenerate health. |
| Deep Freeze | Snow Pea + Winter Melon in a lane: +5% freeze chance. |
| Salad Bar | Kernel-pult next to Cabbage-pult: +50% butter chance. |
| Spore Cloud | Fume/Gloom-shroom next to another shroom: +20% damage. |
| Star Fort | Starfruit next to Pumpkin-protected plants: +15% damage. |

